#pragma once

#include "Eigen/Dense"
#include <vector>

Eigen::MatrixXd vectorOfVectorsToEigenMatrix(const std::vector<std::vector<double>> &data);
Eigen::MatrixXd pinv_eigen_based(Eigen::MatrixXd & origin, const float er=1e-7);
Eigen::MatrixXd pseudo_inverse(const std::vector<std::vector<double>> &data);

