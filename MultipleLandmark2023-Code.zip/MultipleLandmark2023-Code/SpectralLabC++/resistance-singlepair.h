#pragma once

#include "Eigen/Dense"
#include "EdgeGraph.h"

double er_AbWalk(EdgeGraph &G, int s, int t, int v, int T);
double er_Push(EdgeGraph &G, int s, int t, int v, double rmax);
double er_Bipush(EdgeGraph &G, int s, int t, int v, double rmax, int T);
double er_LocalTree(EdgeGraph &G, int s, int t, int v, std::vector<int> &bfs_v, int T);
double er_p_trun(EdgeGraph &G, int s, int t, int p, int omega);
std::vector<std::vector<double>> precompute_Pr(EdgeGraph &G, std::vector<int> &vl,std::vector<int> &index_vl, int omega);
std::vector<std::vector<double>> precompute_Pf(EdgeGraph &G, std::vector<int> &vl,std::vector<int> &index_vl, int omega);
Eigen::MatrixXd precompute_SchurComplementInverse(EdgeGraph &G, std::vector<int> &vl,std::vector<int> &index_vl, std::vector<std::vector<double>> &P);
std::vector<std::vector<double>> combine_P_SCInverse(std::vector<std::vector<double>> &P,Eigen::MatrixXd SCInverse,vector<int> index_vl);
double er_vl_rw(EdgeGraph &G, int s, int t, int selectNum, vector<int> &index_vl,vector<std::vector<double>> &Index, Eigen::MatrixXd &SCInverse, int omega);
double er_vl_push(EdgeGraph &G, int s, int t, int selectNum, vector<int> &index_vl,vector<std::vector<double>> &Index, Eigen::MatrixXd &SCInverse, double rmax);
double er_vl_bipush(EdgeGraph &G, int s, int t, int selectNum, vector<int> &index_vl,vector<std::vector<double>> &Index, Eigen::MatrixXd &SCInverse, double rmax, int omega);