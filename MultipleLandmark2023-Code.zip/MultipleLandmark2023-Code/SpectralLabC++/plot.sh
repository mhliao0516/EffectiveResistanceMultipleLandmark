# use rerr
gnuplot exp_resistance/exp_singlepair_algorithms/figures/exp_singlepair_algorithm/plot.plt 
gnuplot exp_resistance/exp_singlepair_algorithms/figures/exp_singlepair_index_algorithm/plot.plt
gnuplot exp_resistance/exp_singlesource_algorithms/figures/exp_singlesource_algorithm/plot.plt
gnuplot exp_resistance/exp_singlesource_algorithms/figures/exp_singlesource_index_algorithm/plot.plt

gnuplot exp_resistance/parameter-analysis-cpp/figures/singlepair_index/plot.plt 
gnuplot exp_resistance/parameter-analysis-cpp/figures/singlepair_query/plot.plt 
gnuplot exp_resistance/parameter-analysis-cpp/figures/singlesource_index/plot.plt 
gnuplot exp_resistance/parameter-analysis-cpp/figures/singlesource_query/plot.plt 

gnuplot exp_resistance/index-analysis-cpp/figures/singlepair_index_analysis/plot.plt
gnuplot exp_resistance/index-analysis-cpp/figures/singlesource_index_analysis/plot.plt

gnuplot exp_resistance/index-space-analysis/figures/plot.plt

# use abserr
gnuplot exp_resistance/exp_singlepair_algorithms/figures/exp_singlepair_algorithm/new_plot.plt 
gnuplot exp_resistance/exp_singlepair_algorithms/figures/exp_singlepair_index_algorithm/new_plot.plt
gnuplot exp_resistance/exp_singlesource_algorithms/figures/exp_singlesource_algorithm/new_plot.plt
gnuplot exp_resistance/exp_singlesource_algorithms/figures/exp_singlesource_index_algorithm/new_plot.plt

gnuplot exp_resistance/parameter-analysis-cpp/figures/singlepair_index/new_plot.plt 
gnuplot exp_resistance/parameter-analysis-cpp/figures/singlepair_query/new_plot.plt 
gnuplot exp_resistance/parameter-analysis-cpp/figures/singlesource_index/new_plot.plt 
gnuplot exp_resistance/parameter-analysis-cpp/figures/singlesource_query/new_plot.plt 

gnuplot exp_resistance/index-analysis-cpp/figures/singlepair_index_analysis/new_plot.plt
gnuplot exp_resistance/index-analysis-cpp/figures/singlesource_index_analysis/new_plot.plt
