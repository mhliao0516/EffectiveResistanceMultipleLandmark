BASE_DIR=./exp_resistance
# compile all 
$BASE_DIR/exp_singlepair_algorithms/compile_to_bin.sh exp_singlepair_algorithm &
$BASE_DIR/exp_singlepair_algorithms/compile_to_bin.sh exp_singlepair_index_algorithm &
$BASE_DIR/exp_singlesource_algorithms/compile_to_bin.sh exp_singlesource_algorithm &
$BASE_DIR/exp_singlesource_algorithms/compile_to_bin.sh exp_singlesource_index_algorithm &
$BASE_DIR/index-analysis-cpp/compile_to_bin.sh singlepair_index_analysis &
$BASE_DIR/index-analysis-cpp/compile_to_bin.sh singlesource_index_analysis &
$BASE_DIR/parameter-analysis-cpp/compile_to_bin.sh singlepair_index_approx &
$BASE_DIR/parameter-analysis-cpp/compile_to_bin.sh singlepair_query_approx &
$BASE_DIR/parameter-analysis-cpp/compile_to_bin.sh singlesource_index_approx &
$BASE_DIR/parameter-analysis-cpp/compile_to_bin.sh singlesource_query_approx &
wait
# singlepair experiments
$BASE_DIR/exp_singlepair_algorithms/bash/exp_singlepair_algorithm.sh road-powergrid 100
$BASE_DIR/exp_singlepair_algorithms/bash/exp_singlepair_index_algorithm.sh road-powergrid 100
# singlesource experiements
$BASE_DIR/exp_singlesource_algorithms/bash/exp_singlesource_algorithm.sh road-powergrid 100
$BASE_DIR/exp_singlesource_algorithms/bash/exp_singlesource_algorithm.sh road-powergrid 100
# index analysis
$BASE_DIR/index-analysis-cpp/bash/singlepair_index_analysis.sh road-powergrid 100
$BASE_DIR/index-analysis-cpp/bash/singlesource_index_analysis.sh road-powergrid 100
# parameter-analysis
$BASE_DIR/parameter-analysis-cpp/bash/singlepair_index_approx.sh road-powergrid 100
$BASE_DIR/parameter-analysis-cpp/bash/singlepair_query_approx.sh road-powergrid 100
$BASE_DIR/parameter-analysis-cpp/bash/singlesource_index_approx.sh road-powergrid 100
$BASE_DIR/parameter-analysis-cpp/bash/singlesource_query_approx.sh road-powergrid 100

