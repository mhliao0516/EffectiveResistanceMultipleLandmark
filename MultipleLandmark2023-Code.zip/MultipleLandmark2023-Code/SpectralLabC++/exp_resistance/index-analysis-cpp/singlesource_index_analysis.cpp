#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <sys/time.h>
#include <numeric>
#include <vector>
#include <cmath>
#include <H5Cpp.h>
#include <queue>
#include <random>
#include <filesystem>
#include <map>
#include "Eigen/Dense"

#include "../../EdgeGraph.h"
#include "../../resistance-singlepair.h"
#include "../../resistance-singlesource.h"
#include "../../tools-matrix.h"

using namespace std;
namespace fs = std::filesystem;

string BASE_DIR = "exp_resistance/index-analysis-cpp";
string GROUNDTRUTH_DIR = "../SpectralLab/parameter-analysis-julia/groundTruth";
string VL_DIR = "../SpectralLab/parameter-analysis-julia/vl";

map<string,vector<int>> LeWalk_omegas_dict;
map<string,vector<int>> ST_omegas_dict;


int argmax(const std::vector<double>& arr){
    int maxIndex = 0; 
    for (int i = 1; i < arr.size(); ++i) {
        if (arr[i] > arr[maxIndex]) {
            maxIndex = i;
        }
    }
    return maxIndex;
}

vector<int> find_k_max_index(const vector<double> &arr,int k){
    struct ElementWithIndex {
        double value;
        int index;

        // 比较运算符，用于堆排序
        bool operator<(const ElementWithIndex& other) const {
            return value > other.value;
        }
    };
    priority_queue<ElementWithIndex> maxHeap;  // 最大堆
    vector<int> topkPositions;

    // 遍历数组，将元素值和索引存储到最大堆中
    for (int i = 0; i < arr.size(); ++i) {
        maxHeap.push({arr[i], i});

        // 如果堆的大小超过 10，弹出堆顶元素
        if (maxHeap.size() > k) {
            maxHeap.pop();
        }
    }

    // 从最大堆中获取前 10 大元素的位置
    while (!maxHeap.empty()) {
        topkPositions.push_back(maxHeap.top().index);
        maxHeap.pop();
    }

    // 对结果进行反转，使其按照原数组的顺序
    reverse(topkPositions.begin(), topkPositions.end());

    return topkPositions;
}

double l2norm(const std::vector<double>& arr){
    double norm = 0.0;
    for(const double &val:arr){
        norm += val * val;
    }
    return sqrt(norm);
}

vector<double> vector_minus(const vector<double> &vec1,const vector<double> &vec2){
    if(!vec1.size()==vec2.size()){
        throw runtime_error("vector dimension cannot match!!");
    }
    vector<double> temp = vec1;
    for(size_t i=0;i<vec1.size();i++){
        temp[i] -= vec2[i];
    }
    return temp;
}

vector<vector<double>> matrix_minus(const vector<vector<double>> &mat1, const vector<vector<double>> &mat2){
    if(!mat1.size()==mat2.size() || !mat1[0].size()==mat2[0].size()){
        throw runtime_error("matrix dimension cannot match!!");
    }
    vector<vector<double>> temp = mat1;
    for(size_t i=0;i<mat1.size();i++){
        for(size_t j=0;j<mat1[0].size();j++){
            temp[i][j] -= mat2[i][j];
        }
    }
    return temp;
}

vector<double> get_column(vector<vector<double>> &mat,int k){
    vector<double> temp = {};
    for(size_t i=0;i<mat.size();i++){
        temp.push_back(mat[i][k]);
    } 
    return temp;
}

vector<double> head_k(vector<double> &vec,int k){
    vector<double> temp = {};
    for(int i=0;i<k;i++){
        temp.push_back(vec[i]);
    }
    return temp;
}

vector<vector<double>> read_exact_p(string filename){
    // 打开 HDF5 文件
    H5::H5File file(filename, H5F_ACC_RDONLY);

    // 打开数据集
    H5::DataSet dataset = file.openDataSet("P");

    // 读取数据集
    H5::DataSpace dataspace = dataset.getSpace();
    hsize_t dims_out[2];
    dataspace.getSimpleExtentDims(dims_out, NULL);
    int rows = dims_out[1];
    int cols = dims_out[0];

    // cout << rows << "  " << cols << endl;

    double* data = new double[rows * cols];
    dataset.read(data, H5::PredType::NATIVE_DOUBLE);

    // 将数据存储为 vector<vector<double>>
    vector<vector<double>> matrix;
    matrix.resize(rows, vector<double>(cols));

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = data[j * rows + i];
        }
    }
    delete[] data;

    return matrix;
}

vector<int> read_vlseq_top_k(string filename,int k){
    vector<int> vl = {};
    ifstream file(filename);
    string line;
    for(int i=0;i<k;i++){
        getline(file,line);
        vl.push_back(stoi(line)-1);
    }
    file.close();
    return vl;
}

vector<int> generate_index_vl(int n,vector<int> vl){
    vector<int> index_vl(n,0);
    for(int i=1;i<=vl.size();i++){
        index_vl[vl[i-1]] = i;
    }
    int u_ind = 0;
    for(int i=0;i<n;i++){
        if(index_vl[i]==0){
            index_vl[i] = u_ind;
            u_ind -= 1;
        }
    }
    return index_vl;
}

pair<vector<int>,vector<vector<double>>> read_exact_singlesource(string exact_singlesource_dir){
    cout << "read from " << exact_singlesource_dir << endl;
    vector<int> vnodes= {};
    vector<vector<double>> vers = {};
    for(const auto &entry : fs::directory_iterator(exact_singlesource_dir)){
        if(fs::is_regular_file(entry.path())){
            string nodestr = entry.path().stem();
            int node = stoi(nodestr);
            vnodes.push_back(node);
            vector<double> ss_er = {};
            ifstream f(exact_singlesource_dir+"/"+nodestr+".txt");
            string line;
            while(getline(f,line)){
                ss_er.push_back(stod(line));
            }
            f.close();
            // cout << setprecision(16) << ss_er << endl;
            vers.push_back(ss_er);
        }
    }
    return make_pair(vnodes,vers);
}

double evaluate_p_l1norm(const vector<vector<double>> &estimate_p, const vector<vector<double>> &exact_p){
    double max_err = 0.0;
    int max_err_row = 0;
    int max_err_col = 0;
    for(size_t i=0;i<exact_p.size();i++){
        for(size_t j=0;j<exact_p[0].size();j++){
            if((exact_p[i][j] - estimate_p[i][j])/exact_p[i][j] > max_err){
                max_err = (exact_p[i][j] - estimate_p[i][j])/exact_p[i][j];
                max_err_row = i;
                max_err_col = j;
            }
        }
    }
    cout << "in row:" << max_err_row << ",col:" << max_err_col << ", exact_p:" << exact_p[max_err_row][max_err_col] << "...... , estimate_p:" << estimate_p[max_err_row][max_err_col] << "......" << endl; 
    return max_err;
}

vector<double> generate_Pu_SCI_Pu(vector<vector<double>> exact_p, Eigen::MatrixXd SCInverse){
    int nk = exact_p[0].size();
    int nu = exact_p.size();
    vector<double> Pu_SCI_Pu(nu,0.0);
    for(int u=0;u<nu;u++){
        for(int i=0;i<nk;i++){
            for(int j=0;j<nk;j++){
                Pu_SCI_Pu[u] += exact_p[u][i]*SCInverse(i,j)*exact_p[u][j];
            } 
        }
    }
    return Pu_SCI_Pu;
}

void singlesource_index_analysis(EdgeGraph &G,string dataset,int selectNum,string vl_strategy ,bool LeWalk,bool ST,bool v_LeWalk,bool v_ST){

    string exact_singlesource_dir = GROUNDTRUTH_DIR + "/exact_singlesource/" + dataset;
    cout << "exact_singlesource_dir: " << exact_singlesource_dir << endl;
    string exact_p_dir = GROUNDTRUTH_DIR + "/exact_p/" + vl_strategy + "/" + dataset;
    cout << "exact_p_dir: " << exact_p_dir << endl;
    string vlseq_path = VL_DIR + "/" + vl_strategy + "/" + dataset +"/vlseq.txt";
    cout << "vlseq_path: " << vlseq_path << endl; 
    string output_dir = BASE_DIR + "/results/singlesource_index_analysis/" + dataset;
    cout << "output_dir: " << output_dir << endl;

    if (!fs::is_directory(output_dir)) {
        if (fs::create_directory(output_dir)) {
            std::cout << "Directory created: " << output_dir << std::endl;
        }
    }

    vector<int> vl = read_vlseq_top_k(vlseq_path,selectNum);
    cout << "loaded vl, length: " << vl.size() << endl;
    vector<int> index_vl = generate_index_vl(G.n,vl);
    int v = vl[0];

    pair<vector<int>,vector<vector<double>>> EXT = read_exact_singlesource(exact_singlesource_dir);
    vector<int> vnodes = EXT.first;
    vector<vector<double>> vers = EXT.second;
    cout << "loaded exact singlesource, size:" << vnodes.size() << endl;

    vector<vector<double>> exact_p = read_exact_p(exact_p_dir+"/"+to_string(selectNum)+".jld2");
    cout << "loaded exact_p, row= " << exact_p.size() << ", cols= " << exact_p[0].size() <<endl;
    Eigen::MatrixXd SCInverse = precompute_SchurComplementInverse(G, vl,index_vl, exact_p);
    cout << "precomputed SCInverse, row= " << SCInverse.rows() << ", cols= " << SCInverse.cols() <<endl;
    vector<vector<double>> Index = combine_P_SCInverse(exact_p,SCInverse,index_vl);
    double starttime = get_current_time_sec_method();
    vector<double> Pu_SCI_Pu = generate_Pu_SCI_Pu(exact_p,SCInverse);
    cout << "time for computing Pu_SCI_Pu: " << get_current_time_sec_method() - starttime << "s." << endl;

    std::ostringstream buffer;

    if(LeWalk){
        vector<int> omegas = LeWalk_omegas_dict[dataset];

        string output_filename = output_dir + "/" + "LeWalk.txt";

        for(auto omega:omegas){

            double start_time = get_current_time_sec_method();
            vector<double> Luuinv = precompute_Luuinv(G,vl,index_vl,omega);
            double elapsed_time = get_current_time_sec_method()-start_time;

            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i];
                vector<double> er_true = vers[i];
                cout << s << endl;
                vector<double> er_hat = er_vl_rw_singlesource(G,s,vl,index_vl,Luuinv,exact_p,SCInverse,Pu_SCI_Pu,1000);

                vector<double> err = vector_minus(er_true,er_hat);
                cout << "er_true: " << head_k(er_true,10) << "......" << endl;
                cout << "er_hat: " << head_k(er_hat,10) << "......" << endl;
                cout << "err: " << head_k(err,10) << "......" << endl;
                double y1 = l2norm(err)/l2norm(er_true);
                double y2 = l2norm(err);
                y1s.push_back(y1);
                y2s.push_back(y2);
                cout << s << ","  << omega << " y1:" << y1 << endl;
            }

            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/y1s.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/y2s.size();
            cout << omega << " elapsed_time:" << elapsed_time << " y1:" << avg_y1 << endl ;

            buffer << setprecision(16) << elapsed_time << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << elapsed_time << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(ST){
        vector<int> omegas = ST_omegas_dict[dataset];

        string output_filename = output_dir + "/" + "ST.txt";

        for(auto omega:omegas){

            double start_time = get_current_time_sec_method();
            vector<double> Luuinv = precompute_Luuinv_ST(G,vl,index_vl,omega);
            double elapsed_time = get_current_time_sec_method()-start_time;

            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i];
                vector<double> er_true = vers[i];
                cout << s << endl;
                vector<double> er_hat = er_vl_rw_singlesource(G,s,vl,index_vl,Luuinv,exact_p,SCInverse,Pu_SCI_Pu,1000);

                vector<double> err = vector_minus(er_true,er_hat);
                cout << "er_true: " << head_k(er_true,10) << "......" << endl;
                cout << "er_hat: " << head_k(er_hat,10) << "......" << endl;
                cout << "err: " << head_k(err,10) << "......" << endl;
                double y1 = l2norm(err)/l2norm(er_true);
                double y2 = l2norm(err);
                y1s.push_back(y1);
                y2s.push_back(y2);
                cout << s << ","  << omega << " y1:" << y1 << endl;
            }

            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/y1s.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/y2s.size();
            cout << omega << " elapsed_time:" << elapsed_time << " y1:" << avg_y1 << endl ;

            buffer << setprecision(16) << elapsed_time << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << elapsed_time << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(v_LeWalk){
        vector<int> omegas = LeWalk_omegas_dict[dataset];

        string output_filename = output_dir + "/" + "v-LeWalk.txt";

        for(auto omega:omegas){

            double start_time = get_current_time_sec_method();
            vector<double> RV = er_LEwalk_singlesource(G,v,omega);
            double elapsed_time = get_current_time_sec_method()-start_time;

            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i];
                vector<double> er_true = vers[i];
                cout << s << endl;
                vector<double> er_hat = er_AbWalkstar_singlesource(G,s,v,1000,RV);
                vector<double> err = vector_minus(er_true,er_hat);
                cout << "er_true: " << head_k(er_true,10) << "......" << endl;
                cout << "er_hat: " << head_k(er_hat,10) << "......" << endl;
                cout << "err: " << head_k(err,10) << "......" << endl;
                double y1 = l2norm(err)/l2norm(er_true);
                double y2 = l2norm(err);
                y1s.push_back(y1);
                y2s.push_back(y2);
                cout << s << ","  << omega << " y1:" << y1 << endl;
            }

            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/y1s.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/y2s.size();
            cout << omega << " elapsed_time:" << elapsed_time << " y1:" << avg_y1 << endl ;

            buffer << setprecision(16) << elapsed_time << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << elapsed_time << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(v_ST){
        vector<int> omegas = ST_omegas_dict[dataset];

        string output_filename = output_dir + "/" + "v-ST.txt";

        for(auto omega:omegas){

            double start_time = get_current_time_sec_method();
            vector<double> RV = er_ST_singlesource(G,v,omega);
            double elapsed_time = get_current_time_sec_method()-start_time;

            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i];
                vector<double> er_true = vers[i];
                cout << s << endl;
                vector<double> er_hat = er_AbWalkstar_singlesource(G,s,v,1000,RV);
                vector<double> err = vector_minus(er_true,er_hat);
                cout << "er_true: " << head_k(er_true,10) << "......" << endl;
                cout << "er_hat: " << head_k(er_hat,10) << "......" << endl;
                cout << "err: " << head_k(err,10) << "......" << endl;
                double y1 = l2norm(err)/l2norm(er_true);
                double y2 = l2norm(err);
                y1s.push_back(y1);
                y2s.push_back(y2);
                cout << s << ","  << omega << " y1:" << y1 << endl;
            }

            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/y1s.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/y2s.size();
            cout << omega << " elapsed_time:" << elapsed_time << " y1:" << avg_y1 << endl ;

            buffer << setprecision(16) << elapsed_time << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << elapsed_time << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }
}


int main(int argc,char** argv){
    srand(time(0));

    string dataset = argv[1];
    int selectNum = atoi(argv[2]);
    string vl_strategy = argv[3];

    vector<bool> params = {};
    string param;
    for (int i = 4; i < argc; ++i) {
        param = argv[i];
        if(param == "true"){
            params.push_back(true);
        } else if (param == "false"){
            params.push_back(false);
        } else{
            cout << "invalid param:" << param << endl;
        }
    }

    int skipstart=0;
    int beginnode = 1;
    bool appear_twice=true;
    if(dataset == "astro-ph" || dataset == "email-enron"){
        skipstart=0;appear_twice=true;beginnode = 0;
    } else if(dataset == "youtube" || dataset == "pokec" || dataset == "orkut"){
        skipstart=1;appear_twice=false;beginnode = 0;
    } else if(dataset.back() == '1'){
        skipstart=0;appear_twice=true;beginnode = 1;
    } else if(dataset == "road-powergrid"){
        skipstart=0;appear_twice=false;beginnode = 1;
    } else{
        throw "unknown dataset!!";
    }
    
    string filename = "datasets/"+dataset+".txt";
    cout << filename << endl;
    EdgeGraph G = read_edgegraph(filename,'\t',skipstart,beginnode,appear_twice);

    LeWalk_omegas_dict["email-enron"] = {80,400,2000,10000};
    ST_omegas_dict["email-enron"] = {80,400,2000,10000};

    LeWalk_omegas_dict["road-powergrid"] = {80,400,2000,10000};
    ST_omegas_dict["road-powergrid"] = {80,400,2000,10000};
    
    singlesource_index_analysis(G,dataset,selectNum,vl_strategy, params[0],params[1],params[2],params[3]);

    return 0;
}


