BASE_DIR=./exp_resistance/index-analysis-cpp
BASE_BIN_DIR=$BASE_DIR/bin
BASE_LOG_DIR=$BASE_DIR/logs

if [ ! -d $BASE_LOG_DIR/singlepair_index_analysis/$1 ]; then
    mkdir -p $BASE_LOG_DIR/singlepair_index_analysis/$1
fi

nohup $BASE_BIN_DIR/singlepair_index_analysis $1 $2 degree+ true false > $BASE_LOG_DIR/singlepair_index_analysis/$1/Pr.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_index_analysis $1 $2 degree+ false true > $BASE_LOG_DIR/singlepair_index_analysis/$1/Pf.log 2>&1 &

