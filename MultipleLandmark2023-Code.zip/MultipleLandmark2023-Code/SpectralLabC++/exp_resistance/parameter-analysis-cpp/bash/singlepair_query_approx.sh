BASE_DIR=./exp_resistance/parameter-analysis-cpp
BASE_BIN_DIR=$BASE_DIR/bin
BASE_LOG_DIR=$BASE_DIR/logs

if [ ! -d $BASE_LOG_DIR/singlepair_query_approx/$1 ]; then
    mkdir -p $BASE_LOG_DIR/singlepair_query_approx/$1
fi

nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 degree true false false > $BASE_LOG_DIR/singlepair_query_approx/$1/degree_vl_rw.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 degree false true false > $BASE_LOG_DIR/singlepair_query_approx/$1/degree_vl_push.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 degree false false true > $BASE_LOG_DIR/singlepair_query_approx/$1/degree_vl_bipush.log 2>&1 &

nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 pagerank true false false > $BASE_LOG_DIR/singlepair_query_approx/$1/pagerank_vl_rw.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 pagerank false true false > $BASE_LOG_DIR/singlepair_query_approx/$1/pagerank_vl_push.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 pagerank false false true > $BASE_LOG_DIR/singlepair_query_approx/$1/pagerank_vl_bipush.log 2>&1 &

nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 random true false false > $BASE_LOG_DIR/singlepair_query_approx/$1/random_vl_rw.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 random false true false > $BASE_LOG_DIR/singlepair_query_approx/$1/random_vl_push.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 random false false true > $BASE_LOG_DIR/singlepair_query_approx/$1/random_vl_bipush.log 2>&1 &

nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 degree+ true false false > $BASE_LOG_DIR/singlepair_query_approx/$1/degree+_vl_rw.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 degree+ false true false > $BASE_LOG_DIR/singlepair_query_approx/$1/degree+_vl_push.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 degree+ false false true > $BASE_LOG_DIR/singlepair_query_approx/$1/degree+_vl_bipush.log 2>&1 &

nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 pagerank+ true false false > $BASE_LOG_DIR/singlepair_query_approx/$1/pagerank+_vl_rw.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 pagerank+ false true false > $BASE_LOG_DIR/singlepair_query_approx/$1/pagerank+_vl_push.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_query_approx $1 $2 pagerank+ false false true > $BASE_LOG_DIR/singlepair_query_approx/$1/pagerank+_vl_bipush.log 2>&1 &