BASE_DIR=./exp_resistance/parameter-analysis-cpp
BASE_BIN_DIR=$BASE_DIR/bin
BASE_LOG_DIR=$BASE_DIR/logs

if [ ! -d $BASE_LOG_DIR/singlesource_query_approx/$1 ]; then
    mkdir -p $BASE_LOG_DIR/singlesource_query_approx/$1
fi

nohup $BASE_BIN_DIR/singlesource_query_approx $1 $2 degree true false > $BASE_LOG_DIR/singlesource_query_approx/$1/degree_ss-rw.log 2>&1 &
nohup $BASE_BIN_DIR/singlesource_query_approx $1 $2 degree false true > $BASE_LOG_DIR/singlesource_query_approx/$1/degree_ss-push.log 2>&1 &

nohup $BASE_BIN_DIR/singlesource_query_approx $1 $2 pagerank true false > $BASE_LOG_DIR/singlesource_query_approx/$1/pagerank_ss-rw.log 2>&1 &
nohup $BASE_BIN_DIR/singlesource_query_approx $1 $2 pagerank false true > $BASE_LOG_DIR/singlesource_query_approx/$1/pagerank_ss-push.log 2>&1 &

nohup $BASE_BIN_DIR/singlesource_query_approx $1 $2 random true false > $BASE_LOG_DIR/singlesource_query_approx/$1/random_ss-rw.log 2>&1 &
nohup $BASE_BIN_DIR/singlesource_query_approx $1 $2 random false true > $BASE_LOG_DIR/singlesource_query_approx/$1/random_ss-push.log 2>&1 &

nohup $BASE_BIN_DIR/singlesource_query_approx $1 $2 degree+ true false > $BASE_LOG_DIR/singlesource_query_approx/$1/degree+_ss-rw.log 2>&1 &
nohup $BASE_BIN_DIR/singlesource_query_approx $1 $2 degree+ false true > $BASE_LOG_DIR/singlesource_query_approx/$1/degree+_ss-push.log 2>&1 &

nohup $BASE_BIN_DIR/singlesource_query_approx $1 $2 pagerank+ true false > $BASE_LOG_DIR/singlesource_query_approx/$1/pagerank+_ss-rw.log 2>&1 &
nohup $BASE_BIN_DIR/singlesource_query_approx $1 $2 pagerank+ false true > $BASE_LOG_DIR/singlesource_query_approx/$1/pagerank+_ss-push.log 2>&1 &