BASE_DIR=./exp_resistance/parameter-analysis-cpp
BASE_BIN_DIR=$BASE_DIR/bin
BASE_LOG_DIR=$BASE_DIR/logs

if [ ! -d $BASE_LOG_DIR/singlepair_index_approx/$1 ]; then
    mkdir -p $BASE_LOG_DIR/singlepair_index_approx/$1
fi

nohup $BASE_BIN_DIR/singlepair_index_approx $1 $2 degree true false  > $BASE_LOG_DIR/singlepair_index_approx/$1/degree_Pr.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_index_approx $1 $2 degree false true  > $BASE_LOG_DIR/singlepair_index_approx/$1/degree_Pf.log 2>&1 &

nohup $BASE_BIN_DIR/singlepair_index_approx $1 $2 pagerank true false  > $BASE_LOG_DIR/singlepair_index_approx/$1/pagerank_Pr.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_index_approx $1 $2 pagerank false true  > $BASE_LOG_DIR/singlepair_index_approx/$1/pagerank_Pf.log 2>&1 &

nohup $BASE_BIN_DIR/singlepair_index_approx $1 $2 random true false  > $BASE_LOG_DIR/singlepair_index_approx/$1/random_Pr.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_index_approx $1 $2 random false true  > $BASE_LOG_DIR/singlepair_index_approx/$1/random_Pf.log 2>&1 &

nohup $BASE_BIN_DIR/singlepair_index_approx $1 $2 degree+ true false  > $BASE_LOG_DIR/singlepair_index_approx/$1/degree+_Pr.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_index_approx $1 $2 degree+ false true  > $BASE_LOG_DIR/singlepair_index_approx/$1/degree+_Pf.log 2>&1 &

nohup $BASE_BIN_DIR/singlepair_index_approx $1 $2 pagerank+ true false  > $BASE_LOG_DIR/singlepair_index_approx/$1/pagerank+_Pr.log 2>&1 &
nohup $BASE_BIN_DIR/singlepair_index_approx $1 $2 pagerank+ false true  > $BASE_LOG_DIR/singlepair_index_approx/$1/pagerank+_Pf.log 2>&1 &

