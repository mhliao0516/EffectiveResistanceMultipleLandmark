#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <sys/time.h>
#include <numeric>
#include <vector>
#include <cmath>
#include <H5Cpp.h>
#include <queue>
#include <random>
#include <filesystem>
#include "Eigen/Dense"

#include "../../EdgeGraph.h"
#include "../../resistance-singlepair.h"

using namespace std;
namespace fs = std::filesystem;

string BASE_DIR = "exp_resistance/parameter-analysis-cpp";
string GROUNDTRUTH_DIR = "../SpectralLab/parameter-analysis-julia/groundTruth";
string VL_DIR = "../SpectralLab/parameter-analysis-julia/vl";

int argmax(const std::vector<double>& arr){
    int maxIndex = 0; 
    for (int i = 1; i < arr.size(); ++i) {
        if (arr[i] > arr[maxIndex]) {
            maxIndex = i;
        }
    }
    return maxIndex;
}

vector<int> find_k_max_index(const vector<double> &arr,int k){
    struct ElementWithIndex {
        double value;
        int index;

        // 比较运算符，用于堆排序
        bool operator<(const ElementWithIndex& other) const {
            return value > other.value;
        }
    };
    priority_queue<ElementWithIndex> maxHeap;  // 最大堆
    vector<int> topkPositions;

    // 遍历数组，将元素值和索引存储到最大堆中
    for (int i = 0; i < arr.size(); ++i) {
        maxHeap.push({arr[i], i});

        // 如果堆的大小超过 10，弹出堆顶元素
        if (maxHeap.size() > k) {
            maxHeap.pop();
        }
    }

    // 从最大堆中获取前 10 大元素的位置
    while (!maxHeap.empty()) {
        topkPositions.push_back(maxHeap.top().index);
        maxHeap.pop();
    }

    // 对结果进行反转，使其按照原数组的顺序
    reverse(topkPositions.begin(), topkPositions.end());

    return topkPositions;
}

double l2norm(const std::vector<double>& arr){
    double norm = 0.0;
    for(const double &val:arr){
        norm += val * val;
    }
    return sqrt(norm);
}

double Frobinius_norm(const std::vector<std::vector<double>>& mat){
    double norm = 0.0;
    for(const vector<double> &arr:mat){
        for(const double &val:arr){
            norm += val * val;
        }
    }
    return sqrt(norm);
}

vector<vector<double>> matrix_minus(const vector<vector<double>> &mat1, const vector<vector<double>> &mat2){
    if(!mat1.size()==mat2.size() || !mat1[0].size()==mat2[0].size()){
        throw runtime_error("matrix dimension cannot match!!");
    }
    vector<vector<double>> temp = mat1;
    double norm = 0.0;
    for(size_t i=0;i<mat1.size();i++){
        for(size_t j=0;j<mat1[0].size();j++){
            temp[i][j] -= mat2[i][j];
        }
    }
    return temp;
}

vector<double> get_column(vector<vector<double>> &mat,int k){
    vector<double> temp = {};
    for(size_t i=0;i<mat.size();i++){
        temp.push_back(mat[i][k]);
    } 
    return temp;
}

vector<vector<double>> read_exact_p(string filename){
    // 打开 HDF5 文件
    H5::H5File file(filename, H5F_ACC_RDONLY);

    // 打开数据集
    H5::DataSet dataset = file.openDataSet("P");

    // 读取数据集
    H5::DataSpace dataspace = dataset.getSpace();
    hsize_t dims_out[2];
    dataspace.getSimpleExtentDims(dims_out, NULL);
    int rows = dims_out[1];
    int cols = dims_out[0];

    // cout << rows << "  " << cols << endl;

    double* data = new double[rows * cols];
    dataset.read(data, H5::PredType::NATIVE_DOUBLE);

    // 将数据存储为 vector<vector<double>>
    vector<vector<double>> matrix;
    matrix.resize(rows, vector<double>(cols));

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = data[j * rows + i];
        }
    }
    delete[] data;

    return matrix;
}

vector<int> read_vlseq_top_k(string filename,int k){
    vector<int> vl = {};
    ifstream file(filename);
    string line;
    for(int i=0;i<k;i++){
        getline(file,line);
        vl.push_back(stoi(line)-1);
    }
    file.close();
    return vl;
}


void singlapair_index_approx(EdgeGraph &G,string dataset,int selectNumMax,string vl_strategy,bool index_Pr,bool index_Pf){
    string exact_p_dir = GROUNDTRUTH_DIR + "/exact_p/" + vl_strategy + "/" + dataset;
    cout << "exact_p_dir: " << exact_p_dir << endl;
    string vlseq_path = VL_DIR + "/" + vl_strategy + "/" + dataset +"/vlseq.txt";
    cout << "vlseq_path: " << vlseq_path << endl;
    string output_dir = BASE_DIR + "/results/singlepair_index/" + dataset;
    cout << "output_dir: " << output_dir << endl;

    if (!fs::is_directory(output_dir)) {
        if (fs::create_directory(output_dir)) {
            std::cout << "Directory created: " << output_dir << std::endl;
        }
    }

    std::ostringstream buffer;

    if(index_Pr){
        string output_filename = output_dir + "/" + vl_strategy + "_Pr.txt";
        int omega = 1000;

        for(int selectNum = 1; selectNum <= selectNumMax; selectNum++){


            vector<int> vl = read_vlseq_top_k(vlseq_path,selectNum);
            cout << "loaded vl, length: " << vl.size() << endl;

            // preprocessing
            vector<int> index_vl(G.n,0);
            for(int i=1;i<=selectNum;i++){
                index_vl[vl[i-1]] = i;
            }
            int u_ind = 0;
            for(int i=0;i<G.n;i++){
                if(index_vl[i]==0){
                    index_vl[i] = u_ind;
                    u_ind -= 1;
                }
            }
            // finish preprocessing

            vector<vector<double>> exact_p = read_exact_p(exact_p_dir+"/"+to_string(selectNum)+".jld2");
            cout << "loaded exact_p, row= " << exact_p.size() << ", cols= " << exact_p[0].size() <<endl;

            Eigen::MatrixXd SCInverse = precompute_SchurComplementInverse(G, vl,index_vl, exact_p);
            cout << "precomputed SCInverse, row= " << SCInverse.rows() << ", cols= " << SCInverse.cols() <<endl;


            double start_time = get_current_time_sec_method();
            vector<vector<double>> Pr = precompute_Pr(G,vl,index_vl,omega);
            Eigen::MatrixXd SCInverse_Pr = precompute_SchurComplementInverse(G, vl,index_vl, Pr);
            double elapsed_time = get_current_time_sec_method()-start_time;

            vector<vector<double>> exact_Index = combine_P_SCInverse(exact_p,SCInverse,index_vl);

            vector<vector<double>> err_p = matrix_minus(exact_p,Pr);
            double y1_p = Frobinius_norm(err_p)/Frobinius_norm(exact_p);
            double y2_p = Frobinius_norm(err_p);

            // cout << "Pr[:,0]: " << get_column(Pr,0) << endl;
            vector<vector<double>> Pr_Index = combine_P_SCInverse(Pr,SCInverse_Pr,index_vl);
            vector<vector<double>> err = matrix_minus(exact_Index,Pr_Index);

            // cout << "err[:,0]: " << get_column(err,0) << endl;
            double y1 = Frobinius_norm(err)/Frobinius_norm(exact_Index);
            double y2 = Frobinius_norm(err);
            cout << "Frobinius_norm(err): " << Frobinius_norm(err) << "\t" << "Frobinius_norm(exact_Index): " << Frobinius_norm(exact_Index) << endl;

            cout << selectNum << " elapsed_time:" << elapsed_time << " y1_p:" << y1_p << " y1:" << y1 << endl ;

            buffer << setprecision(16) << selectNum << "\t" << elapsed_time << "\t" << y1_p << "\t" << y2_p << "\t" << y1 << "\t" << y2 << endl;
            cout << setprecision(16) << selectNum << "\t" << elapsed_time << "\t" << y1_p << "\t" << y2_p << "\t" << y1 << "\t" << y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(index_Pf){
        string output_filename = output_dir + "/" + vl_strategy + "_Pf.txt";
        int omega = 1000;

        for(int selectNum = 1; selectNum <= selectNumMax; selectNum++){

            vector<int> vl = read_vlseq_top_k(vlseq_path,selectNum);
            cout << "loaded vl, length: " << vl.size() << endl;
            cout << "vl: " << vl << endl;

            // preprocessing
            vector<int> index_vl(G.n,0);
            for(int i=1;i<=selectNum;i++){
                index_vl[vl[i-1]] = i;
            }
            int u_ind = 0;
            for(int i=0;i<G.n;i++){
                if(index_vl[i]==0){
                    index_vl[i] = u_ind;
                    u_ind -= 1;
                }
            }
            // finish preprocessing

            vector<vector<double>> exact_p = read_exact_p(exact_p_dir+"/"+to_string(selectNum)+".jld2");
            cout << "loaded exact_p, row= " << exact_p.size() << ", cols= " << exact_p[0].size() <<endl;

            Eigen::MatrixXd SCInverse = precompute_SchurComplementInverse(G, vl,index_vl, exact_p);
            cout << "precomputed SCInverse, row= " << SCInverse.rows() << ", cols= " << SCInverse.cols() <<endl;

            vector<vector<double>> exact_Index = combine_P_SCInverse(exact_p,SCInverse,index_vl);
            

            double start_time = get_current_time_sec_method();
            vector<vector<double>> Pf = precompute_Pf(G,vl,index_vl,omega);
            Eigen::MatrixXd SCInverse_Pf = precompute_SchurComplementInverse(G, vl,index_vl, Pf);
            double elapsed_time = get_current_time_sec_method()-start_time;
            
            vector<vector<double>> err_p = matrix_minus(exact_p,Pf);
            double y1_p = Frobinius_norm(err_p)/Frobinius_norm(exact_p);
            double y2_p = Frobinius_norm(err_p);
            // cout << "Pf[:,0]: " << get_column(Pf,0) << endl;

            vector<vector<double>> Pf_Index = combine_P_SCInverse(Pf,SCInverse_Pf,index_vl);
            vector<vector<double>> err = matrix_minus(exact_Index,Pf_Index);
            // cout << "err[:,0]: " << get_column(err,0) << endl;
            double y1 = Frobinius_norm(err)/Frobinius_norm(exact_Index);
            double y2 = Frobinius_norm(err);
            cout << "Frobinius_norm(err): " << Frobinius_norm(err) << "\t" << "Frobinius_norm(exact_Index): " << Frobinius_norm(exact_Index) << endl;

            cout << selectNum << " elapsed_time:" << elapsed_time << " y1_p:" << y1_p << " y1:" << y1 << endl ;

            buffer << setprecision(16) << selectNum << "\t" << elapsed_time << "\t" << y1_p << "\t" << y2_p << "\t" << y1 << "\t" << y2 << endl;
            cout << setprecision(16) << selectNum << "\t" << elapsed_time << "\t" << y1_p << "\t" << y2_p << "\t" << y1 << "\t" << y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }


}


int main(int argc,char** argv){
    srand(time(0));

    string dataset = argv[1];
    int selectNumMax = atoi(argv[2]);
    string vl_strategy = argv[3];

    vector<bool> params = {};
    string param;
    for (int i = 4; i < argc; ++i) {
        param = argv[i];
        if(param == "true"){
            params.push_back(true);
        } else if (param == "false"){
            params.push_back(false);
        } else{
            cout << "invalid param:" << param << endl;
        }
    }

    int skipstart=0;
    int beginnode = 1;
    bool appear_twice=true;
    if(dataset == "astro-ph" || dataset == "email-enron"){
        skipstart=0;appear_twice=true;beginnode = 0;
    } else if(dataset == "youtube" || dataset == "pokec" || dataset == "orkut"){
        skipstart=1;appear_twice=false;beginnode = 0;
    } else if(dataset == "com-hep-th1" || dataset.back() == '1'){
        skipstart=0;appear_twice=true;beginnode = 1;
    } else if(dataset == "road-powergrid"){
        skipstart=0;appear_twice=false;beginnode = 1;
    } else{
        throw "unknown dataset!!";
    }
    
    string filename = "datasets/"+dataset+".txt";
    cout << filename << endl;
    EdgeGraph G = read_edgegraph(filename,'\t',skipstart,beginnode,appear_twice);
    
    singlapair_index_approx(G,dataset,selectNumMax,vl_strategy, params[0],params[1]);

    return 0;
}


