#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <sys/time.h>
#include <numeric>
#include <vector>
#include <cmath>
#include <H5Cpp.h>
#include <queue>
#include <random>
#include <filesystem>
#include "Eigen/Dense"

#include "../../EdgeGraph.h"
#include "../../resistance-singlepair.h"
#include "../../resistance-singlesource.h"
#include "../../tools-matrix.h"

using namespace std;
namespace fs = std::filesystem;

string BASE_DIR = "exp_resistance/parameter-analysis-cpp";
string GROUNDTRUTH_DIR = "../SpectralLab/parameter-analysis-julia/groundTruth";
string VL_DIR = "../SpectralLab/parameter-analysis-julia/vl";

int argmax(const std::vector<double>& arr){
    int maxIndex = 0; 
    for (int i = 1; i < arr.size(); ++i) {
        if (arr[i] > arr[maxIndex]) {
            maxIndex = i;
        }
    }
    return maxIndex;
}

vector<int> find_k_max_index(const vector<double> &arr,int k){
    struct ElementWithIndex {
        double value;
        int index;

        // 比较运算符，用于堆排序
        bool operator<(const ElementWithIndex& other) const {
            return value > other.value;
        }
    };
    priority_queue<ElementWithIndex> maxHeap;  // 最大堆
    vector<int> topkPositions;

    // 遍历数组，将元素值和索引存储到最大堆中
    for (int i = 0; i < arr.size(); ++i) {
        maxHeap.push({arr[i], i});

        // 如果堆的大小超过 10，弹出堆顶元素
        if (maxHeap.size() > k) {
            maxHeap.pop();
        }
    }

    // 从最大堆中获取前 10 大元素的位置
    while (!maxHeap.empty()) {
        topkPositions.push_back(maxHeap.top().index);
        maxHeap.pop();
    }

    // 对结果进行反转，使其按照原数组的顺序
    reverse(topkPositions.begin(), topkPositions.end());

    return topkPositions;
}

double l2norm(const std::vector<double>& arr){
    double norm = 0.0;
    for(const double &val:arr){
        norm += val * val;
    }
    return sqrt(norm);
}

double Frobinius_norm(const std::vector<std::vector<double>>& mat){
    double norm = 0.0;
    for(const vector<double> &arr:mat){
        for(const double &val:arr){
            norm += val * val;
        }
    }
    return sqrt(norm);
}

vector<vector<double>> matrix_minus(const vector<vector<double>> &mat1, const vector<vector<double>> &mat2){
    if(!mat1.size()==mat2.size() || !mat1[0].size()==mat2[0].size()){
        throw runtime_error("matrix dimension cannot match!!");
    }
    vector<vector<double>> temp = mat1;
    for(size_t i=0;i<mat1.size();i++){
        for(size_t j=0;j<mat1[0].size();j++){
            temp[i][j] -= mat2[i][j];
        }
    }
    return temp;
}

vector<double> vector_minus(const vector<double> &vec1,const vector<double> &vec2){
    if(!vec1.size()==vec2.size()){
        throw runtime_error("vector dimension cannot match!!");
    }
    vector<double> temp = vec1;
    for(size_t i=0;i<vec1.size();i++){
        temp[i] -= vec2[i];
    }
    return temp;
}

vector<double> get_column(vector<vector<double>> &mat,int k){
    vector<double> temp = {};
    for(size_t i=0;i<mat.size();i++){
        temp.push_back(mat[i][k]);
    } 
    return temp;
}

vector<double> head_k(vector<double> &vec,int k){
    vector<double> temp = {};
    for(int i=0;i<k;i++){
        temp.push_back(vec[i]);
    }
    return temp;
}

vector<vector<double>> read_exact_p(string filename){
    // 打开 HDF5 文件
    H5::H5File file(filename, H5F_ACC_RDONLY);

    // 打开数据集
    H5::DataSet dataset = file.openDataSet("P");

    // 读取数据集
    H5::DataSpace dataspace = dataset.getSpace();
    hsize_t dims_out[2];
    dataspace.getSimpleExtentDims(dims_out, NULL);
    int rows = dims_out[1];
    int cols = dims_out[0];

    // cout << rows << "  " << cols << endl;

    double* data = new double[rows * cols];
    dataset.read(data, H5::PredType::NATIVE_DOUBLE);

    // 将数据存储为 vector<vector<double>>
    vector<vector<double>> matrix;
    matrix.resize(rows, vector<double>(cols));

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = data[j * rows + i];
        }
    }
    delete[] data;

    return matrix;
}

vector<double> read_exact_Luuinv(string filename){
    // 打开 HDF5 文件
    H5::H5File file(filename, H5F_ACC_RDONLY);

    // 打开数据集
    H5::DataSet dataset = file.openDataSet("Luuinv");

    // 读取数据集
    H5::DataSpace dataspace = dataset.getSpace();
    hsize_t dims[1];
    dataspace.getSimpleExtentDims(dims, NULL);

    vector<double> data(dims[0]);
    dataset.read(&data[0], H5::PredType::NATIVE_DOUBLE);

    return data;
}

vector<int> read_vlseq_top_k(string filename,int k){
    vector<int> vl = {};
    ifstream file(filename);
    string line;
    for(int i=0;i<k;i++){
        getline(file,line);
        vl.push_back(stoi(line)-1);
    }
    file.close();
    return vl;
}

pair<vector<int>,vector<vector<double>>> read_exact_singlesource(string exact_singlesource_dir){
    cout << "read from " << exact_singlesource_dir << endl;
    vector<int> vnodes= {};
    vector<vector<double>> vers = {};
    for(const auto &entry : fs::directory_iterator(exact_singlesource_dir)){
        if(fs::is_regular_file(entry.path())){
            string nodestr = entry.path().stem();
            int node = stoi(nodestr);
            vnodes.push_back(node);
            vector<double> ss_er = {};
            ifstream f(exact_singlesource_dir+"/"+nodestr+".txt");
            string line;
            while(getline(f,line)){
                ss_er.push_back(stod(line));
            }
            f.close();
            // cout << setprecision(16) << ss_er << endl;
            vers.push_back(ss_er);
        }
    }
    return make_pair(vnodes,vers);
}

vector<double> generate_Pu_SCI_Pu(vector<vector<double>> exact_p, Eigen::MatrixXd SCInverse){
    int nk = exact_p[0].size();
    int nu = exact_p.size();
    vector<double> Pu_SCI_Pu(nu,0.0);
    for(int u=0;u<nu;u++){
        for(int i=0;i<nk;i++){
            for(int j=0;j<nk;j++){
                Pu_SCI_Pu[u] += exact_p[u][i]*SCInverse(i,j)*exact_p[u][j];
            } 
        }
    }
    return Pu_SCI_Pu;
}


void singlesource_query_approx(EdgeGraph &G,string dataset,int selectNumMax,string vl_strategy,bool ss_rw,bool ss_push){
    string exact_singlesource_dir = GROUNDTRUTH_DIR + "/exact_singlesource/" + dataset;
    cout << "exact_singlesource_dir: " << exact_singlesource_dir << endl;; 
    string exact_p_dir = GROUNDTRUTH_DIR + "/exact_p/" + vl_strategy + "/" + dataset;
    cout << "exact_p_dir: " << exact_p_dir << endl;
    string exact_Luuinv_dir = GROUNDTRUTH_DIR + "/exact_Luuinv/" + vl_strategy + "/" + dataset;
    cout << "exact_Luuinv_dir: " << exact_Luuinv_dir << endl;
    string vlseq_path = VL_DIR + "/" + vl_strategy + "/" + dataset +"/vlseq.txt";
    cout << "vlseq_path: " << vlseq_path << endl;
    string output_dir = BASE_DIR + "/results/singlesource_query/" + dataset;
    cout << "output_dir: " << output_dir << endl;

    if (!fs::is_directory(output_dir)) {
        if (fs::create_directory(output_dir)) {
            std::cout << "Directory created: " << output_dir << std::endl;
        }
    }

    pair<vector<int>,vector<vector<double>>> EXT = read_exact_singlesource(exact_singlesource_dir);
    vector<int> vnodes = EXT.first;
    vector<vector<double>> vers = EXT.second;
    cout << "loaded exact singlesource, size:" << vnodes.size() << endl;

    std::ostringstream buffer;

    if(ss_rw){
        string output_filename = output_dir + "/" + vl_strategy + "_ssrw.txt";
        int omega = 5000;

        for(int selectNum = 1; selectNum <= selectNumMax; selectNum++){

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            vector<int> vl = read_vlseq_top_k(vlseq_path,selectNum);
            cout << "loaded vl, length: " << vl.size() << endl;

            // preprocessing
            vector<int> index_vl(G.n,0);
            for(int i=1;i<=selectNum;i++){
                index_vl[vl[i-1]] = i;
            }
            int u_ind = 0;
            for(int i=0;i<G.n;i++){
                if(index_vl[i]==0){
                    index_vl[i] = u_ind;
                    u_ind -= 1;
                }
            }
            // finish preprocessing

            vector<vector<double>> exact_p = read_exact_p(exact_p_dir+"/"+to_string(selectNum)+".jld2");
            cout << "loaded exact_p, row= " << exact_p.size() << ", cols= " << exact_p[0].size() <<endl;

            Eigen::MatrixXd SCInverse = precompute_SchurComplementInverse(G, vl,index_vl, exact_p);
            cout << "precomputed SCInverse, row= " << SCInverse.rows() << ", cols= " << SCInverse.cols() <<endl;

            vector<double> Pu_SCI_Pu = generate_Pu_SCI_Pu(exact_p,SCInverse);

            vector<double> exact_Luuinv = read_exact_Luuinv(exact_Luuinv_dir+"/"+to_string(selectNum)+".jld2");
            cout << "loaded exact_Luuinv, row= " << exact_Luuinv.size() << endl;

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i];
                vector<double> er_true = vers[i];
                cout << s << endl;
                double start_time = get_current_time_sec_method();
                vector<double> er_hat = er_vl_rw_singlesource(G,s,vl,index_vl,exact_Luuinv,exact_p,SCInverse,Pu_SCI_Pu,omega);
                double elapsed_time = get_current_time_sec_method()-start_time;

                vector<double> err = vector_minus(er_true,er_hat);
                cout << "er_true: " << head_k(er_true,10) << "......" << endl;
                cout << "er_hat: " << head_k(er_hat,10) << "......" << endl;
                cout << "err: " << head_k(err,10) << "......" << endl;
                double y1 = l2norm(err)/l2norm(er_true);
                double y2 = l2norm(err);
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(y2);
                cout << s << ","  << omega << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << selectNum << "\t" << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(ss_push){
        string output_filename = output_dir + "/" + vl_strategy + "_sspush.txt";
        double rmax = 1e-4;

        for(int selectNum = 1; selectNum <= selectNumMax; selectNum++){

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            vector<int> vl = read_vlseq_top_k(vlseq_path,selectNum);
            cout << "loaded vl, length: " << vl.size() << endl;

            // preprocessing
            vector<int> index_vl(G.n,0);
            for(int i=1;i<=selectNum;i++){
                index_vl[vl[i-1]] = i;
            }
            int u_ind = 0;
            for(int i=0;i<G.n;i++){
                if(index_vl[i]==0){
                    index_vl[i] = u_ind;
                    u_ind -= 1;
                }
            }
            // finish preprocessing

            vector<vector<double>> exact_p = read_exact_p(exact_p_dir+"/"+to_string(selectNum)+".jld2");
            cout << "loaded exact_p, row= " << exact_p.size() << ", cols= " << exact_p[0].size() <<endl;

            Eigen::MatrixXd SCInverse = precompute_SchurComplementInverse(G, vl,index_vl, exact_p);
            cout << "precomputed SCInverse, row= " << SCInverse.rows() << ", cols= " << SCInverse.cols() <<endl;

            vector<double> Pu_SCI_Pu = generate_Pu_SCI_Pu(exact_p,SCInverse);

            vector<double> exact_Luuinv = read_exact_Luuinv(exact_Luuinv_dir+"/"+to_string(selectNum)+".jld2");
            cout << "loaded exact_Luuinv, row= " << exact_Luuinv.size() << endl;

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i];
                vector<double> er_true = vers[i];
                cout << s << endl;
                double start_time = get_current_time_sec_method();
                vector<double> er_hat = er_vl_push_singlesource(G,s,vl,index_vl,exact_Luuinv,exact_p,SCInverse,Pu_SCI_Pu,rmax);
                double elapsed_time = get_current_time_sec_method()-start_time;

                vector<double> err = vector_minus(er_true,er_hat);
                cout << "er_true: " << head_k(er_true,10) << "......" << endl;
                cout << "er_hat: " << head_k(er_hat,10) << "......" << endl;
                cout << "err: " << head_k(err,10) << "......" << endl;
                double y1 = l2norm(err)/l2norm(er_true);
                double y2 = l2norm(err);
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(y2);
                cout << s << ","  << rmax << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << selectNum << "\t" << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }
}


int main(int argc,char** argv){
    srand(time(0));

    string dataset = argv[1];
    int selectNumMax = atoi(argv[2]);
    string vl_strategy = argv[3];

    vector<bool> params = {};
    string param;
    for (int i = 4; i < argc; ++i) {
        param = argv[i];
        if(param == "true"){
            params.push_back(true);
        } else if (param == "false"){
            params.push_back(false);
        } else{
            cout << "invalid param:" << param << endl;
        }
    }

    int skipstart=0;
    int beginnode = 1;
    bool appear_twice=true;
    if(dataset == "astro-ph" || dataset == "email-enron"){
        skipstart=0;appear_twice=true;beginnode = 0;
    } else if(dataset == "youtube" || dataset == "pokec" || dataset == "orkut"){
        skipstart=1;appear_twice=false;beginnode = 0;
    } else if(dataset == "com-hep-th1" || dataset.back() == '1'){
        skipstart=0;appear_twice=true;beginnode = 1;
    } else if(dataset == "road-powergrid"){
        skipstart=0;appear_twice=false;beginnode = 1;
    } else{
        throw "unknown dataset!!";
    }
    
    string filename = "datasets/"+dataset+".txt";
    cout << filename << endl;
    EdgeGraph G = read_edgegraph(filename,'\t',skipstart,beginnode,appear_twice);
    
    singlesource_query_approx(G,dataset,selectNumMax,vl_strategy, params[0], params[1]);

    return 0;
}


