#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <sys/time.h>
#include <numeric>
#include <vector>
#include <cmath>
#include <H5Cpp.h>
#include <queue>
#include <random>
#include <filesystem>
#include "Eigen/Dense"

#include "../../EdgeGraph.h"
#include "../../resistance-singlepair.h"

using namespace std;
namespace fs = std::filesystem;

string BASE_DIR = "exp_resistance/parameter-analysis-cpp";
string GROUNDTRUTH_DIR = "../SpectralLab/parameter-analysis-julia/groundTruth";
string VL_DIR = "../SpectralLab/parameter-analysis-julia/vl";

int argmax(const std::vector<double>& arr){
    int maxIndex = 0; 
    for (int i = 1; i < arr.size(); ++i) {
        if (arr[i] > arr[maxIndex]) {
            maxIndex = i;
        }
    }
    return maxIndex;
}

vector<int> find_k_max_index(const vector<double> &arr,int k){
    struct ElementWithIndex {
        double value;
        int index;

        // 比较运算符，用于堆排序
        bool operator<(const ElementWithIndex& other) const {
            return value > other.value;
        }
    };
    priority_queue<ElementWithIndex> maxHeap;  // 最大堆
    vector<int> topkPositions;

    // 遍历数组，将元素值和索引存储到最大堆中
    for (int i = 0; i < arr.size(); ++i) {
        maxHeap.push({arr[i], i});

        // 如果堆的大小超过 10，弹出堆顶元素
        if (maxHeap.size() > k) {
            maxHeap.pop();
        }
    }

    // 从最大堆中获取前 10 大元素的位置
    while (!maxHeap.empty()) {
        topkPositions.push_back(maxHeap.top().index);
        maxHeap.pop();
    }

    // 对结果进行反转，使其按照原数组的顺序
    reverse(topkPositions.begin(), topkPositions.end());

    return topkPositions;
}

double l2norm(const std::vector<double>& arr){
    double norm = 0.0;
    for(const double &val:arr){
        norm += val * val;
    }
    return sqrt(norm);
}

vector<vector<double>> read_exact_p(string filename){
    // 打开 HDF5 文件
    H5::H5File file(filename, H5F_ACC_RDONLY);

    // 打开数据集
    H5::DataSet dataset = file.openDataSet("P");

    // 读取数据集
    H5::DataSpace dataspace = dataset.getSpace();
    hsize_t dims_out[2];
    dataspace.getSimpleExtentDims(dims_out, NULL);
    int rows = dims_out[1];
    int cols = dims_out[0];

    // cout << rows << "  " << cols << endl;

    double* data = new double[rows * cols];
    dataset.read(data, H5::PredType::NATIVE_DOUBLE);

    // 将数据存储为 vector<vector<double>>
    vector<vector<double>> matrix;
    matrix.resize(rows, vector<double>(cols));

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = data[j * rows + i];
        }
    }
    delete[] data;

    return matrix;
}

pair<vector<pair<int,int>>,vector<double>> read_exact_singlepair(string exact_singlepair_dir){
    cout << "read from " << exact_singlepair_dir << endl;
    vector<pair<int,int>> vnodes= {};
    vector<double> vers = {};
    for(const auto &entry : fs::directory_iterator(exact_singlepair_dir)){
        if(fs::is_regular_file(entry.path())){
            string pairstr = entry.path().stem();
            size_t l = pairstr.length();
            size_t commaPos = pairstr.find(",");
            string firstNodestr = pairstr.substr(1,commaPos-1);
            string secondNodestr = pairstr.substr(commaPos+1,l-commaPos-2);
            int firstNode = stoi(firstNodestr);
            int secondNode = stoi(secondNodestr);
            vnodes.push_back(make_pair(firstNode,secondNode));
            ifstream f(exact_singlepair_dir+"/"+pairstr+".txt");
            string line;
            getline(f,line);
            f.close();
            double er = stod(line);
            // cout << setprecision(16) << er << endl;
            vers.push_back(er);
        }
    }
    return make_pair(vnodes,vers);
}

vector<int> read_vlseq_top_k(string filename,int k){
    vector<int> vl = {};
    ifstream file(filename);
    string line;
    for(int i=0;i<k;i++){
        getline(file,line);
        vl.push_back(stoi(line)-1);
    }
    file.close();
    return vl;
}


void singlapair_query_approx(EdgeGraph &G,string dataset,int selectNumMax,string vl_strategy,bool vl_rw,bool vl_push,bool vl_bipush){
    string exact_singlepair_dir = GROUNDTRUTH_DIR + "/exact_singlepair/" + dataset;
    cout << "exact_singlepair_dir: " << exact_singlepair_dir << endl;; 
    string exact_p_dir = GROUNDTRUTH_DIR + "/exact_p/" + vl_strategy + "/" + dataset;
    cout << "exact_p_dir: " << exact_p_dir << endl;
    string vlseq_path = VL_DIR + "/" + vl_strategy + "/" + dataset +"/vlseq.txt";
    cout << "vlseq_path: " << vlseq_path << endl;
    string output_dir = BASE_DIR + "/results/singlepair_query/" + dataset;
    cout << "output_dir: " << output_dir << endl;

    if (!fs::is_directory(output_dir)) {
        if (fs::create_directory(output_dir)) {
            std::cout << "Directory created: " << output_dir << std::endl;
        }
    }

    pair<vector<pair<int,int>>,vector<double>> EXT = read_exact_singlepair(exact_singlepair_dir);
    vector<pair<int,int>> vnodes = EXT.first;
    vector<double>vers = EXT.second;
    cout << "loaded exact singlepair, size:" << vnodes.size() << endl;

    std::ostringstream buffer;

    if(vl_rw){
        string output_filename = output_dir + "/" + vl_strategy + "_vl-rw.txt";
        int omega = 1000;

        for(int selectNum = 1; selectNum <= selectNumMax; selectNum++){

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            vector<int> vl = read_vlseq_top_k(vlseq_path,selectNum);
            cout << "loaded vl, length: " << vl.size() << endl;

            // preprocessing
            vector<int> index_vl(G.n,0);
            for(int i=1;i<=selectNum;i++){
                index_vl[vl[i-1]] = i;
            }
            int u_ind = 0;
            for(int i=0;i<G.n;i++){
                if(index_vl[i]==0){
                    index_vl[i] = u_ind;
                    u_ind -= 1;
                }
            }
            // finish preprocessing

            vector<vector<double>> exact_p = read_exact_p(exact_p_dir+"/"+to_string(selectNum)+".jld2");
            cout << "loaded exact_p, row= " << exact_p.size() << ", cols= " << exact_p[0].size() <<endl;

            Eigen::MatrixXd SCInverse = precompute_SchurComplementInverse(G, vl,index_vl, exact_p);
            cout << "precomputed SCInverse, row= " << SCInverse.rows() << ", cols= " << SCInverse.cols() <<endl;

            
            vector<vector<double>> Index = combine_P_SCInverse(exact_p,SCInverse,index_vl);

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i].first;
                int t = vnodes[i].second;
                double er_true = vers[i];
                cout << s << " " << t << endl;
                double start_time = get_current_time_sec_method();
                double er_hat = er_vl_rw(G,s,t,selectNum,index_vl,Index,SCInverse,omega);
                double elapsed_time = get_current_time_sec_method()-start_time;
                double y1 = abs(er_hat-er_true)/er_true;
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(abs(er_hat-er_true));
                cout << s << "," << t << "," << omega << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << selectNum << "\t" << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(vl_push){
        string output_filename = output_dir + "/" + vl_strategy + "_vl-push.txt";
        double rmax = 1e-4;
        

        for(int selectNum = 1; selectNum <= selectNumMax; selectNum++){

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            vector<int> vl = read_vlseq_top_k(vlseq_path,selectNum);
            cout << "loaded vl, length: " << vl.size() << endl;

            // preprocessing
            vector<int> index_vl(G.n,0);
            for(int i=1;i<=selectNum;i++){
                index_vl[vl[i-1]] = i;
            }
            int u_ind = 0;
            for(int i=0;i<G.n;i++){
                if(index_vl[i]==0){
                    index_vl[i] = u_ind;
                    u_ind -= 1;
                }
            }
            // finish preprocessing

            vector<vector<double>> exact_p = read_exact_p(exact_p_dir+"/"+to_string(selectNum)+".jld2");
            cout << "loaded exact_p, row= " << exact_p.size() << ", cols= " << exact_p[0].size() <<endl;

            Eigen::MatrixXd SCInverse = precompute_SchurComplementInverse(G, vl,index_vl, exact_p);
            cout << "precomputed SCInverse, row= " << SCInverse.rows() << ", cols= " << SCInverse.cols() <<endl;

            vector<vector<double>> Index = combine_P_SCInverse(exact_p,SCInverse,index_vl);

            cout << "after preprocessing" << endl;

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i].first;
                int t = vnodes[i].second;
                double er_true = vers[i];
                cout << s << " " << t << endl;
                double start_time = get_current_time_sec_method();
                double er_hat = er_vl_push(G,s,t,selectNum,index_vl,Index,SCInverse,rmax);
                double elapsed_time = get_current_time_sec_method()-start_time;
                double y1 = abs(er_hat-er_true)/er_true;
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(abs(er_hat-er_true));
                cout << s << "," << t << "," << rmax << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << selectNum << "\t" << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << "\t" << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }

        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(vl_bipush){
        string output_filename = output_dir + "/" + vl_strategy + "_vl-bipush.txt";
        double rmax = 1e-4;
        int omega = 100;


        for(int selectNum = 1; selectNum <= selectNumMax; selectNum++){

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            vector<int> vl = read_vlseq_top_k(vlseq_path,selectNum);
            cout << "loaded vl, length: " << vl.size() << endl;

            // preprocessing
            vector<int> index_vl(G.n,0);
            for(int i=1;i<=selectNum;i++){
                index_vl[vl[i-1]] = i;
            }
            int u_ind = 0;
            for(int i=0;i<G.n;i++){
                if(index_vl[i]==0){
                    index_vl[i] = u_ind;
                    u_ind -= 1;
                }
            }
            // finish preprocessing

            vector<vector<double>> exact_p = read_exact_p(exact_p_dir+"/"+to_string(selectNum)+".jld2");
            cout << "loaded exact_p, row= " << exact_p.size() << ", cols= " << exact_p[0].size() <<endl;

            Eigen::MatrixXd SCInverse = precompute_SchurComplementInverse(G, vl,index_vl, exact_p);
            cout << "precomputed SCInverse, row= " << SCInverse.rows() << ", cols= " << SCInverse.cols() <<endl;

            
            vector<vector<double>> Index = combine_P_SCInverse(exact_p,SCInverse,index_vl);

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i].first;
                int t = vnodes[i].second;
                double er_true = vers[i];
                cout << s << " " << t << endl;
                double start_time = get_current_time_sec_method();
                double er_hat = er_vl_bipush(G,s,t,selectNum,index_vl,Index,SCInverse,rmax,omega);
                double elapsed_time = get_current_time_sec_method()-start_time;
                double y1 = abs(er_hat-er_true)/er_true;
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(abs(er_hat-er_true));
                cout << s << "," << t << "," << rmax << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << selectNum << "\t" << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

}


int main(int argc,char** argv){
    srand(time(0));

    string dataset = argv[1];
    int selectNumMax = atoi(argv[2]);
    string vl_strategy = argv[3];

    vector<bool> params = {};
    string param;
    for (int i = 3; i < argc; ++i) {
        param = argv[i];
        if(param == "true"){
            params.push_back(true);
        } else if (param == "false"){
            params.push_back(false);
        } else{
            cout << "invalid param:" << param << endl;
        }
    }

    int skipstart=0;
    int beginnode = 1;
    bool appear_twice=true;
    if(dataset == "astro-ph" || dataset == "email-enron"){
        skipstart=0;appear_twice=true;beginnode = 0;
    } else if(dataset == "youtube" || dataset == "pokec" || dataset == "orkut"){
        skipstart=1;appear_twice=false;beginnode = 0;
    } else if(dataset == "com-hep-th1" || dataset.back() == '1'){
        skipstart=0;appear_twice=true;beginnode = 1;
    } else if(dataset == "road-powergrid"){
        skipstart=0;appear_twice=false;beginnode = 1;
    } else{
        throw "unknown dataset!!";
    }
    
    string filename = "datasets/"+dataset+".txt";
    cout << filename << endl;
    EdgeGraph G = read_edgegraph(filename,'\t',skipstart,beginnode,appear_twice);
    
    singlapair_query_approx(G,dataset,selectNumMax,vl_strategy, params[0],params[1],params[2]);

    return 0;
}


