# Multiple-Landmark Based Method of Computing Effective Resistance
> Note: This repository roles as of the code-support of submitted thesis named "Efficient and Provable Effective Resistance Computation on Large Graphs: an Index-based Approach"

## Environment
- System: Ubuntu 220.04.1 LTS
- gcc version: 11.2.0
- julia version: 1.8.5

## Dependencies
- C++
    - HDF5 C++ 1.13.2
- julia 
    - Arpack 0.5.4
    - Distributions 0.25.98
    - JLD2 0.4.35
    - Datastructures 0.18.14
    - 
  These libraries help organize experimental code structure and won't affect any performance of algorithms.
  
## Quick Start
Take dataset "road-powergrid" (which lies in directory `datasets/`) for example:
### Step0: Install all dependencies
### Step1: Generate ground truth
  1. run `cd {RepositoryDir}/SpectralLab/ ; ./generate_All_groundTruth.sh` , change `{RepositoryDir}` to your unzipped repository directory.

### Step2: Run experiments
  1. run `cd {RepositoryDir}/SpectralLabC++/ ; ./run_All_experiments.sh` , change `{RepositoryDir}` to your unzipped repository directory.

### Step3(Optional): Plot
  1. Install gnuplot via `sudo apt-get install gnuplot`.
  2. run `cd {RepositoryDir}/SpectralLab/ ; ./plot.sh` , change `{RepositoryDir}` to your unzipped repository directory.

## Detailed Args
Directory `bash/` offers various scripts for detailed experiments with different parameters, parameters' meanings are shown below:
  | Script      | Arg1      | Arg2      |
  | ----- | ----- | ----- |
  | get_various_vl.sh      |    dataset name   | (None)      |
  | vary_vl_strategy_exact_p      |   dataset name    | maximum #vl       |
  | vary_vl_strategy_exact_Luuinv      |   dataset name    | maximum #vl       |
  | (Others)      | dataset name      |  #vl     |

where #vl represents the landmark number.

If you want to apply algorithms to your own dataset, firstly you should preprocess your dataset and store it in `datasets` in both julia and cpp part, then follow the steps in Quick Start with parameters tuned to your own settings.  
  
## Code Instructions:
  - `datasets/`: storage for datasets files
  - `bash/`: experiment scripts
  - `bin/`: binary execuable
  - `logs`:storage for logs during experiments
  - `results`:storage for experiment results
  - `figures`:plotting codes and storage for plotted figures
