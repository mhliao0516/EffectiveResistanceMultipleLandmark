using SparseArrays
using LinearAlgebra

function lap(a::SparseMatrixCSC)
    return sparse(Diagonal(a*ones(size(a)[1]))) - a
end

function prop(a::SparseMatrixCSC)
    return sparse(Diagonal(1.0./(a*ones(size(a)[1])))) * a
end

function pseudo_inverse(L::SparseMatrixCSC)
    dense_L = Matrix(L)
    return pinv(dense_L,atol=sqrt(eps(real(float(oneunit(eltype(Float64)))))))
end


pseudo_inverse(M::Matrix{Float64}) = pinv(M,atol=sqrt(eps(real(float(oneunit(eltype(Float64)))))))

cholesky_solver(Lv::SparseMatrixCSC) = x->cholesky(Lv)\x

function product_graph(a0::SparseMatrixCSC, a1::SparseMatrixCSC)
    n0 = size(a0)[1]
    n1 = size(a1)[1]
    a = kron(sparse(I, n0, n0), a1) + kron(a0, sparse(I, n1, n1))
    return a
end

function join_graphs(a::SparseMatrixCSC{Tval,Tind}, b::SparseMatrixCSC{Tval,Tind}, k::Integer) where {Tval,Tind}
    na = size(a)[1]
    nb = size(b)[1]

    (ai,aj,av) = findnz(a)
    (bi,bj,bv) = findnz(b)
    bi = bi .+ na
    bj = bj .+ na

    ji = rand(1:na,k)
    jj = rand(1:nb,k) .+ na

    ab = sparse([ai;bi;ji;jj],[aj;bj;jj;ji],[av;bv;ones(Tval,2*k)],na+nb,na+nb)
end



function components(mat::SparseMatrixCSC{Tv,Ti}) where {Tv,Ti}
    n = mat.n
    temp = Array{Ti}(undef, n) # 存储同一连通分量的点
    comp = zeros(Ti, n) 
    c::Ti = 0

    colptr = mat.colptr
    rowval = mat.rowval

    @inbounds for x in 1:n
        if (comp[x] == 0)
            c = c + 1
            comp[x] = c

            if colptr[x+1] > colptr[x] # 这行不会出错的
                ptr::Ti = 1
                templen::Ti = 2
                temp[ptr] = x

                while ptr < templen
                    curNode = temp[ptr]
                    for ind in colptr[curNode]:(colptr[curNode+1]-1)
                        neighbor = rowval[ind]
                        if comp[neighbor] == 0
                            comp[neighbor] = c
                            temp[templen] = neighbor
                            templen += 1
                        end
                    end
                    ptr += 1
                end
            end
        end
    end
    return comp
end

function vecToComps(compvec::Vector{Ti}) where Ti
    nc = maximum(compvec)
    comps = Vector{Vector{Ti}}(undef, nc)

    sizes = zeros(Ti,nc)
    for i in compvec
        sizes[i] += 1
    end

     for i in 1:nc
         comps[i] = zeros(Ti,sizes[i])
     end

    ptrs = zeros(Ti,nc)
     for i in 1:length(compvec)
        c = compvec[i]
        ptrs[c] += 1
        comps[c][ptrs[c]] = i
    end
    return comps
end

function biggestComp(mat::SparseMatrixCSC)
    cv = components(mat)
    cs = vecToComps(cv)
    sizes = map(x->length(x), cs)
    jnk, ind = findmax(sizes)
    return mat[cs[ind],cs[ind]]
end

function delete_edge!(mat::SparseMatrixCSC,node1::Int,node2::Int) # 一定要和dropzeros!()连用啊！
    if mat[node1,node2] == 0.0
        return false
    else
        mat[node1,node2] = 0.0
        mat[node2,node1] = 0.0
        return true
    end
end

function delete_node!(mat::SparseMatrixCSC,node::Int)
    ind = [1:node-1;node+1:size(mat)[1]]
    return mat[ind,ind];
end
