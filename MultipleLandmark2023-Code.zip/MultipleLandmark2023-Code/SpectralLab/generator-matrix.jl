import Random.randperm
using SparseArrays
using LinearAlgebra
using DataStructures
using Random

include("tools-matrix.jl")

"""
只有节点没有边的空图
    n   节点数
"""
function empty_graph(n::Int)
    sparse(zeros(n,n))
end

"""
路径图
    n   节点数
"""
function path_graph(n::Int)
    sparse(
        [collect(1:(n-1)) ; collect(2:n)], 
        [collect(2:n); collect(1:(n-1))], 
        ones(2*(n-1))
    )
end

"""
星图
    n   节点数
"""
function star_graph(n::Int)
    sparse(
        [ones(Int, n-1) ; collect(2:n)], 
        [collect(2:n); ones(Int, n-1)], 
        ones(2*(n-1))
    )
end

"""
完全图
    n   节点数
"""
function complete_graph(n::Int)
    sparse(ones(n,n) - Matrix(I,n,n))
end

"""
完全二分图
    n   一边节点数
    m   另一边节点数
"""
function complete_bipartite_graph(n::Int,m::Int)
    sparse([zeros(n,n) ones(n,m);ones(m,n) zeros(m,m)])
end
complete_bipartite_graph(n::Int) = complete_bipartite_graph(n,n)

"""
环图
    n   节点数
"""
function ring_graph(n::Int)
    if n == 1
        return empty_graph(1)
    else
        return sparse(
            [collect(1:(n-1)) ; collect(2:n); 1; n], 
            [collect(2:n); collect(1:(n-1)); n; 1], 
            ones(2*n)
        )
    end
end

"""
完全二叉树
    n   节点数
"""
function complete_binary_tree(n::Integer)
    k = div(n-1,2)
    if 2*k+1 < n
        ii0 = Int[n-1]
        jj0 = Int[n]
    else
        ii0 = Int[]
        jj0 = Int[]
    end
    ii = [collect(1:k); collect(1:k); ii0]
    jj = [2*collect(1:k); 2*collect(1:k) .+ 1; jj0]
    return sparse([ii;jj], [jj;ii], ones(2*length(ii)))
end

function hypercube_ijv(d::Int)
    @assert d >= 2
    if d == 2
        return [1,1,2,2,3,3,4,4],[2,4,1,3,2,4,1,3],ones(Float64,8)  
    end
    ai,aj,av = hypercube_ijv(d-1)
    ai = [ai;ai.+2^(d-1); collect(1:2^(d-1)); 2^(d-1) .+ collect(1:2^(d-1))]
    aj = [aj;aj.+2^(d-1); 2^(d-1) .+ collect(1:2^(d-1)); collect(1:2^(d-1))]
    av = [av;av; ones(2^d)]
    return ai,aj,av
end

"""
正方体图
    d   维数
"""
function hypercube(d::Int)
    if d == 1
        return sparse([0])
    end
    ai,aj,av = hypercube_ijv(d)
    return sparse(ai,aj,av)
end

"""
二维网格图
    n   长节点数
    m   宽节点数
    isotropy    权重系数
"""
function grid2(n::Int,m::Int;isotropy=1.0)
    product_graph(isotropy*path_graph(n),path_graph(m))
end
grid2(n::Int) = grid2(n,n)

"""
三维
    n1,n2,n3   长宽高节点数
"""
function grid3(n1::Int,n2::Int,n3::Int)
    product_graph(path_graph(n1),product_graph(path_graph(n2),path_graph(n3)))
end
grid3(n::Int) = grid3(n,n,n)

"""
随机全匹配图
n为奇数时有一个孤立点
    n   节点数
"""
function random_matching_graph(n::Int)
    p = randperm(n)
    n1 = convert(Int,floor(n/2))
    n2 = 2*n1
    return sparse(
        [p[1:n1];p[(n1+1):n2]],
        [p[(n1+1):n2];p[1:n1]],
        ones(n2)
    )
end

"""
随机k-正则图
    n   节点数
    k   度数
"""
function random_regular_graph(n::Int,k::Int)
    n1 = convert(Int64,floor(n/2))
    n2 = 2*n1
    ii = Array{Int64}(undef, n1*k)
    jj = Array{Int64}(undef, n1*k)

    ind = 0
    for i in 1:k
        p = randperm(n)   
        for j in 1:n1
            ind += 1
            ii[ind] = p[j]
            jj[ind] = p[n1+j]
        end
    end
    return sparse([ii;jj], [jj;ii], ones(k*n2),n,n)
end

"""
Erdos-Renyi图
不保证连通性
    n   节点数
    m   边数
"""
function ErdosRenyi(n::Int,m::Int)
    ai = rand(1:n,m)
    aj = rand(1:n,m)
    ind = (ai .!= aj)
    mat = sparse(ai[ind],aj[ind],1.0,n,n)
    mat = mat + mat'
    return mat
end

"""
Erdos-Renyi图
是ErdosRenyi(n::Int,m::Int)的最大连通分量
    n   节点数
    m   边数
"""
function ErdosRenyiCluster(n::Int,k::Int)
    m = ceil(Integer,n*k/2)
    mat = ErdosRenyi(n,m)
    mat = biggestComp(mat)
    return mat
end

"""
Erdos-Renyi图
    n   节点数
    k   度数
"""
function ErdosRenyiClusterFix(n::Integer, k::Integer)
    m1 = ErdosRenyiCluster(n, k)
    n2 = n - size(m1)[1]
    if (n2 > 0)
        m2 = complete_binary_tree(n2)
        return join_graphs(m1,m2,1)
    else
        return m1
    end
end
