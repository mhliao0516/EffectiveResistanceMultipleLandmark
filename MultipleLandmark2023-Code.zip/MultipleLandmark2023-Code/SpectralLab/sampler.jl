using Random
include("datastructure.jl")

function rand_choose_by_weight(x::Vector{Tx},y::Vector{Ty}) where {Tx,Ty<:Real}
    r = rand(1) * sum(y)
    return x[findall(cumsum(y) .> r)[1]]
end

function choose_k_vertices(G::EdgeGraph,k::Int)
    return randperm(G.n)[1:k]
end

function choose_k_pairs(G::EdgeGraph,k::Int)
    p1 = randperm(G.n)[1:k]
    p2 = randperm(G.n)[1:k]
    return collect(zip(p1,p2))
end

function choose_k_edges(G::EdgeGraph,k::Int)
    return randperm(G.m)[1:k]
end