using LinearAlgebra
using SparseArrays

include("tools-matrix.jl")

function er_exact_singlepair(Linv::Matrix, s::Int, t::Int)
    return Linv[s, s] + Linv[t, t] - 2 * Linv[s, t]
end

function er_exact_singlepair(L::SparseMatrixCSC, solver::Function, s::Int, t::Int, v::Int)
    if s == t
        return 0.
    end
    n = size(L, 1)
    e_st = zeros(Int, n)
    e_st[s] = 1
    e_st[t] = -1
    ind = [1:v-1; v+1:n]
    # Lv = L[ind,ind]
    e_st_v = e_st[ind]
    # solver = chol_sddm(Lv)
    x = solver(e_st_v)
    return e_st_v' * x
end

function er_exact_singlesource(Linv::Matrix, s::Int)
    n = size(Linv, 1)
    er_s = zeros(Float64, n)
    for t in 1:n
        er_s[t] = Linv[s, s] + Linv[t, t] - 2 * Linv[s, t]
    end
    return er_s
end

function er_exact_singlesource(L::SparseMatrixCSC, solver::Function, s::Int, v::Int)
    n = size(L, 1)
    ind = [1:v-1; v+1:n]
    rsu = zeros(Float64,n)
    e_st = zeros(Float64, n)
    e_st[s] = 1.
    e_st[1] = -1.
    for t in 1:n
        if t > 1
            e_st[t-1] = 0.
            e_st[t] = -1.
        end
        if t == s
            e_st[s] = 1
            rsu[t] = 0
            continue
        end
        if t == s+1
            e_st[s] = 1
        end
        e_st_v = e_st[ind]
        x = solver(e_st_v)
        rsu[t] = e_st_v' * x
    end
    return rsu
end
