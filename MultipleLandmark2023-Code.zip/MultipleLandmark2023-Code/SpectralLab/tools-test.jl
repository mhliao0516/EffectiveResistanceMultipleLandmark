using Base.Threads
using Dates
using JLD


function wrapper_elapsed(f::Function)
    wraped_f = function(args...)
        t = @elapsed ret = f(args...)
        return t,ret
    end
    return wraped_f
end

function wrapper_maxtime(f::Function,maxtime::Real)
    wraped_f = function(args...)
        callback = function(task::Task,maxtime::Real)
            if !istaskdone(task)
                Base.throwto(task, MyRuntimeError(maxtime))
            end
        end
        task = @spawn global res = f(args...)
        Timer(_->callback(task,maxtime),maxtime)
        try
            wait(task)
            return res
        catch e
            if isa(e,TaskFailedException)
                nested_e = e.task.result
                if isa(nested_e,MyRuntimeError)            
                    showerror(stderr,nested_e)
                    return nothing
                else
                    throw(nested_e)
                end
            else
                throw(e)
            end
        end
    end
    return wraped_f
end

function wrapper_multitimes(f::Function,times::Int)
    wraped_f = function(args...)
        rets = []
        for _ in 1:times
            ret = f(args...)
            if ret !== nothing
                push!(rets,ret)
            end
        end
        return [i[1] for i in rets], [i[2] for i in rets]
    end
    return wraped_f
end

function wrapper(f::Function; maxtime::Real=3600.0,times::Int=5)
    return wrapper_multitimes(wrapper_maxtime(wrapper_elapsed(f),maxtime),times)
end

rerr(ytrue::Real,yhat::Real) = abs(yhat-ytrue)/(ytrue+eps(Float64))
rerr(ytrue::Real,yhat::Vector{Real}) = abs(mean(yhat)-ytrue)/(ytrue+eps(Float64))
rerr(ytrue::Vector,yhat::Vector) = norm(ytrue-yhat)/norm(ytrue)

function writeTestSet2txt(TestSetJldName::AbstractString;output_dir::AbstractString="results/groundTruth/")
    TestSet = load(TestSetJldName)
    for filename in keys(TestSet)
        datasetName = split(filename,'.')[1]
        println(datasetName)
        datasetDir = joinpath(output_dir,"$(datasetName)/")
        if !isdir(datasetDir)
            mkdir(datasetDir)
        end
        for fields in keys(TestSet[filename])
            datasetFieldsDir = joinpath(datasetDir,"$(fields)/")
            if !isdir(datasetFieldsDir)
                mkdir(datasetFieldsDir)
            end
            for node in keys(TestSet[filename][fields])
                data = TestSet[filename][fields][node]
                open(joinpath(datasetFieldsDir,"$(node).txt"),"w") do f
                    if isa(data,Float64)
                        write(f,"$(data)\n")
                    elseif isa(data,Vector{Float64})
                        for val in data
                            write(f,"$(val)\n")
                        end
                    else
                        throw(TypeError)
                    end
                end
                println("write to $(joinpath(datasetFieldsDir,"$(node).txt"))")
            end
        end 
    end
end

function writeTestSet2txt(TestSet::Map;output_dir::AbstractString="results/groundTruth/")
    for filename in keys(TestSet)
        datasetName = split(filename,'.')[1]
        println(datasetName)
        datasetDir = joinpath(output_dir,"$(datasetName)/")
        if !isdir(datasetDir)
            mkdir(datasetDir)
        end
        for fields in keys(TestSet[filename])
            datasetFieldsDir = joinpath(datasetDir,"$(fields)/")
            if !isdir(datasetFieldsDir)
                mkdir(datasetFieldsDir)
            end
            for node in keys(TestSet[filename][fields])
                data = TestSet[filename][fields][node]
                open(joinpath(datasetFieldsDir,"$(node).txt"),"w") do f
                    if isa(data,Float64)
                        write(f,"$(data)\n")
                    elseif isa(data,Vector{Float64})
                        for val in data
                            write(f,"$(val)\n")
                        end
                    else
                        throw(TypeError)
                    end
                end
                println("write to $(joinpath(datasetFieldsDir,"$(node).txt"))")
            end
        end 
    end
end

