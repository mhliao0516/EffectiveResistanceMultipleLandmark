using Distributions

include("datastructure.jl")
include("sampler.jl")

function choose_neighbor(G::EdgeGraph, node::Int)
    neighbor = rand(G.g[node]) # 查表大概4.5ns，rand函数大概4ns
    return neighbor
end

function choose_neighbor_weighted(G::EdgeGraph, node::Int, distribution::Distributions.Categorical)
    neighbor = G.g[node][rand(distribution)] # 查表大概4.5ns，rand函数大概4ns
    return neighbor
end

function v_absorbed_push(G::EdgeGraph, s::Int, v::Int, rmax::Float64)
    r = zeros(Float64, G.n)
    r[s] = 1.0
    q = zeros(Float64, G.n)
    if s == v
        return q, r
    end
    
    push_queue = [s]
    is_inQueue = zeros(Bool, G.n)
    is_inQueue[s] = true
    while !isempty(push_queue)
        u = pop!(push_queue)
        is_inQueue[u] = false
        q[u] += r[u]
        for neighbor in G.g[u]
            if neighbor != v
                r[neighbor] +=  r[u] / G.deg[u]
                if r[neighbor] >= G.deg[neighbor] * rmax && !is_inQueue[neighbor]
                    pushfirst!(push_queue, neighbor)
                    is_inQueue[neighbor] = true
                end
            end
        end
        r[u] = 0
    end
    return q, r
end

function v_absorbed_push(G::EdgeGraph, s::Vector, v::Int, rmax::Float64)
    r = copy(s)
    q = zeros(Float64, G.n)
    push_queue = collect(1:G.n)[r.>G.deg*rmax]
    is_inQueue = zeros(Bool, G.n)
    is_inQueue[push_queue] .= true
    while !isempty(push_queue)
        u = pop!(push_queue)
        is_inQueue[u] = false
        q[u] += r[u]
        for nw in zip(G.g[u],G.wts[u])
            neighbor,weight = nw
            if neighbor != v
                r[neighbor] += weight *  r[u] / G.deg[u]
                if r[neighbor] >= G.deg[neighbor] * rmax && !is_inQueue[neighbor]
                    pushfirst!(push_queue, neighbor)
                    is_inQueue[neighbor] = true
                end
            end
        end
        r[u] = 0
    end
    return q, r
end

function vl_absorbed_push(G::EdgeGraph,s::Int,vl::Vector{Int},rmax::Float64)
    r = zeros(Float64, G.n)
    q = zeros(Float64, G.n)
    r[s] = 1.0
    push_queue = [s]
    is_inQueue = zeros(Bool, G.n)
    is_inQueue[s] = true
    while !isempty(push_queue)
        u = pop!(push_queue)
        is_inQueue[u] = false
        q[u] += r[u]
        for nw in zip(G.g[u],G.wts[u])
            neighbor,weight = nw
            if neighbor ∉ vl
                r[neighbor] += weight *  r[u] / G.deg[u]
                if r[neighbor] >= G.deg[neighbor] * rmax && !is_inQueue[neighbor]
                    pushfirst!(push_queue, neighbor)
                    is_inQueue[neighbor] = true
                end
            end
        end
        r[u] = 0
    end
    return q, r
end


function wilson(G::EdgeGraph, r::Int)
    inTree = zeros(Bool, G.n)
    next = zeros(Int, G.n)
    inTree[r] = true
    for i in 1:G.n
        u = i
        while !inTree[u]
            next[u] = choose_neighbor(G, u)
            u = next[u]
        end
        u = i
        while !inTree[u]
            inTree[u] = true
            u = next[u]
        end
    end
    return next
end

function wilson(G::EdgeGraph,rl::Vector{Int})
    inTree = zeros(Bool, G.n)
    next = zeros(Int, G.n)
    inTree[rl] .= true
    for i in 1:G.n
        u = i
        while !inTree[u]
            next[u] = choose_neighbor(G, u)
            u = next[u]
        end
        u = i
        while !inTree[u]
            inTree[u] = true
            u = next[u]
        end
    end
    return next
end

function BFS(G::EdgeGraph, root::Int) 
    next = zeros(Int,G.n)
    next[root] = -1
    search_queue = Int[root]
    while !isempty(search_queue)
        current = pop!(search_queue)          
        for neighbor in G.g[current]
            if next[neighbor] == 0
                next[neighbor] = current
                prepend!(search_queue,neighbor)
            end
        end
    end
    return next
end

function BFS(G::EdgeGraph, roots::Vector{Int})
    next = zeros(Int,G.n)
    next[roots] .= -1
    search_queue = copy(roots)
    while !isempty(search_queue)
        current = pop!(search_queue)          
        for neighbor in G.g[current]
            if next[neighbor] == 0
                next[neighbor] = current
                prepend!(search_queue,neighbor)
            end
        end
    end
    return next
end

function find_path2root_in_spanning_tree(next::Vector{Int}, s::Int, r::Int)
    u = s
    path = []
    while u != r
        push!(path, (u, next[u]))
        u = next[u]
    end
    return path
end

function delete_edge!(G::EdgeGraph,node1::Int,node2::Int)
    ind1 = findfirst(x->x==node2,G.g[node1])
    if ind1 === nothing
        return false
    else
        G.g[node1] = G.g[node1][1:ind1-1;ind1+1:length(G.g[node1])]
        G.deg[node1] -= G.wts[node1][ind1]
        G.wts[node1][ind1] = G.wts[node1][1:ind1-1;ind1+1:length(G.g[node1])]
    end
    ind2 = findfirst(x->x==node1,G.g[node2])
    G.g[node2] = G.g[node2][1:ind2-1;ind2+1:length(G.g[node2])]
    G.deg[node2] -= G.wts[node2][ind2]
    G.wts[node2][ind2] = G.wts[node2][1:ind2-1;ind2+1:length(G.g[node2])]
    return true
end


