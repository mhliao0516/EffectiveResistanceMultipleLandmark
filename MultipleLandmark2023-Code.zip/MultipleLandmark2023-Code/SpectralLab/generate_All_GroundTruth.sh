BASE_DIR=./parameter-analysis-julia
$BASE_DIR/bash/get_various_vl.sh road-powergrid 
wait
$BASE_DIR/bash/vary_vl_strategy_exact_p.sh road-powergrid 500
$BASE_DIR/bash/vary_vl_strategy_exact_Luuinv.sh road-powergrid 500
wait
$BASE_DIR/bash/generate_singlepair_truth.sh road-powergrid 100
$BASE_DIR/bash/generate_singlesource_truth.sh road-powergrid 100
