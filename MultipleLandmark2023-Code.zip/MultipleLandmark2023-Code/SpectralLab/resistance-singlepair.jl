using LinearAlgebra

include("datastructure.jl")
include("tools-graph.jl")

function er_AbWalk(G::EdgeGraph,s::Int,t::Int,v::Int,T::Int)
    if s == t
        return 0.
    end
    rst = 0
    if t == v
        for i in 1:T
            τs = 0
            current = s
            while current != v
                if current == s
                    τs += 1
                end
                current = choose_neighbor(G,current)
            end
            rst += τs/(G.deg[s]*T)
        end
        return rst
    elseif s == v
        for i in 1:T
            τt = 0
            current = t
            while current != v
                if current == t
                    τt += 1
                end
                current = choose_neighbor(G,current)
            end
            rst += τt/(G.deg[t]*T)
        end
        return rst
    else
        for i in 1:T
            τss = 0; τst = 0
            current = s
            while current != v
                if current == s
                    τss += 1
                end
                if current == t
                    τst += 1
                end
                current = choose_neighbor(G,current)
            end
            τts = 0; τtt = 0
            current = t
            while current != v
                if current == s
                    τts += 1
                end
                if current == t
                    τtt += 1
                end
                current = choose_neighbor(G,current)
            end
            rst += τss/(G.deg[s]*T) + τtt/(G.deg[t]*T) - τst/(G.deg[t]*T) - τts/(G.deg[s]*T)
        end
        return rst
    end
end

function er_Push(G::EdgeGraph,s::Int,t::Int,v::Int,rmax::Float64)
    if s == t
        return 0.
    elseif t == v
        q,r = v_absorbed_push(G,s,v,rmax)
        return q[s]/G.deg[s]
    elseif s == v
        q,r = v_absorbed_push(G,t,v,rmax)
        return q[t]/G.deg[t]
    else
        q1,r1 = v_absorbed_push(G,s,v,rmax)
        q2,r2 = v_absorbed_push(G,t,v,rmax)
        return q1[s]/G.deg[s] + q2[t]/G.deg[t] - q1[t]/G.deg[t] - q2[s]/G.deg[s]
    end
end

function er_Bipush(G::EdgeGraph,s::Int,t::Int,v::Int,rmax::Float64,T::Int)
    if s == t
        return 0.
    elseif t == v
        q,r = v_absorbed_push(G,s,v,rmax)
        rst = q[s]/G.deg[s]
        for i in 1:T
            current = s
            while current != v
                rst += r[current]/(G.deg[current]*T)
                current = choose_neighbor(G,current)
            end
        end
        return rst
    elseif s == v
        q,r = v_absorbed_push(G,t,v,rmax)
        rst = q[t]/G.deg[t]
        for i in 1:T
            current = t
            while current != v
                rst += r[current]/(G.deg[current]*T)
                current = choose_neighbor(G,current)
            end
        end
        return rst
    else
        q1,r1 = v_absorbed_push(G,s,v,rmax)
        q2,r2 = v_absorbed_push(G,t,v,rmax)
        println("finished push")
        rst = q1[s]/G.deg[s] + q2[t]/G.deg[t] - q1[t]/G.deg[t] - q2[s]/G.deg[s]
        for i in 1:T
            println("in bipush rw,times:",i)
            current = s
            while current != v
                rst += (r1-r2)[current]/(G.deg[current]*T)
                current = choose_neighbor(G,current)
            end
            current = t
            while current != v
                rst += (r2-r1)[current]/(G.deg[current]*T)
                current = choose_neighbor(G,current)
            end
        end
        return rst
    end
end

function er_LocalTree(G::EdgeGraph,s::Int,t::Int,v::Int,bfs_v::Vector,T::Int)
    inTree = zeros(Bool,G.n)
    next = -ones(Int,G.n)
    Reverse = ones(Int,G.n)
    rst = 0
    for i in 1:T
        inTree .= false
        next .= -1
        Reverse .= 1
        inTree[v] = true
        if !inTree[s]
            u = s
            while !inTree[u]
                next[u] = choose_neighbor(G,u)
                u = next[u]
            end
            u = s
            while !inTree[u]
                inTree[u] = true
                u = next[u]
            end
        end
        if !inTree[t]
            u = t
            while !inTree[u]
                next[u] = choose_neighbor(G,u)
                u = next[u]
            end
            u = t
            while !inTree[u]
                inTree[u] = true
                Reverse[u] = -1
                u = next[u]
            end
        end
        u = s
        while u!=v
            if next[u] == bfs_v[u] && inTree[u] && inTree[next[u]]
                rst += Reverse[u]/T
            elseif u==bfs_v[next[u]] && inTree[u] && inTree[next[u]]
                rst -= Reverse[u]/T
            end
            u = bfs_v[u]
        end
        u = t
        while u!=v
            if next[u] == bfs_v[u] && inTree[u] && inTree[next[u]]
                rst -= Reverse[u]/T
            elseif u==bfs_v[next[u]] && inTree[u] && inTree[next[u]]
                rst += Reverse[u]/T
            end
            u = bfs_v[u]
        end
    end
    return rst
end

function precompute_Pr(G::EdgeGraph,vl::Vector{Int},ω::Int)
    U = filter(!in(vl),1:G.n)
    Pr = zeros(Float64,length(U),length(vl))
    for times in 1:ω
        for i in eachindex(U)
            current = U[i]
            while current ∉ vl
                current = choose_neighbor(G,current)
            end
            j = findfirst(isequal(current),vl)
            Pr[i,j] += 1/ω
        end
    end
    return Pr
end

function precompute_Pf(G::EdgeGraph,vl::Vector{Int},ω::Int)
    U = filter(!in(vl),1:G.n)
    Pf = zeros(Float64,length(U),length(vl))
    for times in 1:ω
        println("in precomputePf, times:",times)
        next = wilson(G,vl)
        for i in eachindex(U)
            current = U[i]
            while next[current] != 0
                current = next[current]
            end
            j = findfirst(isequal(current),vl)
            Pf[i,j] += 1/ω
        end
    end
    return Pf
end

function precompute_SchurComplementInverse(G::EdgeGraph,vl::Vector{Int},P::Matrix{Float64})
    U = filter(!in(vl),1:G.n)
    SC = zeros(Float64,length(vl),length(vl))
    for i in eachindex(vl)
        v = vl[i]
        for neighbor in G.g[v]
            if neighbor in U
                iu = findfirst(isequal(neighbor),U)
                SC[i,:] -= P[iu,:]
            else
                iv = findfirst(isequal(neighbor),vl)
                SC[i,iv] += -1
            end
        end
        SC[i,i] += G.deg[v]
    end
    return pseudo_inverse(SC)
end

function er_SCbased(G::EdgeGraph,s::Int,t::Int,vl::Vector{Int},P::Matrix{Float64},SCInverse::Matrix{Float64},rmax::Float64)
    U = filter(!in(vl),1:G.n)
    println("finished stupid filter")
    if s in vl && t in vl
        is = findfirst(isequal(s),vl)
        it = findfirst(isequal(t),vl)
        return SCInverse[is,is] + SCInverse[it,it] - 2*SCInverse[is,it]
    elseif s in U && t in vl
        is = findfirst(isequal(s),U)
        it = findfirst(isequal(t),vl)
        qs,rs = vl_absorbed_push(G,s,vl,rmax)
        return qs[s]/G.deg[s] + P[is,:]'*SCInverse*P[is,:] + SCInverse[it,it] - 2*P[is,:]'*SCInverse[:,it]
    elseif s in vl && t in U
        is = findfirst(isequal(s),vl)
        it = findfirst(isequal(t),U)
        qt,rt = vl_absorbed_push(G,t,vl,rmax)
        return qt[t]/G.deg[t] + P[it,:]'*SCInverse*P[it,:] + SCInverse[is,is] - 2*P[it,:]'*SCInverse[:,is]
    elseif s in U && t in U
        println("start to stupid find")
        is = findfirst(isequal(s),U)
        it = findfirst(isequal(t),U)
        println("start pushing")
        qs,rs = vl_absorbed_push(G,s,vl,rmax)
        qt,rt = vl_absorbed_push(G,t,vl,rmax)
        println("end pushing")
        Ps_SCI = P[is,:]'*SCInverse
        Pt_SCI = P[it,:]'*SCInverse
        return qs[s]/G.deg[s] + qt[t]/G.deg[t] - 2*qs[t]/G.deg[t] + Ps_SCI*P[is,:] + Pt_SCI*P[it,:] - 2*Ps_SCI*P[it,:]
    end
end

function er_SCbased_Bipush(G::EdgeGraph,s::Int,t::Int,vl::Vector{Int},P::Matrix{Float64},SCInverse::Matrix{Float64},rmax::Float64,omega::Int)
    U = filter(!in(vl),1:G.n)
    println("finished stupid filter")
    if s in vl && t in vl
        is = findfirst(isequal(s),vl)
        it = findfirst(isequal(t),vl)
        return SCInverse[is,is] + SCInverse[it,it] - 2*SCInverse[is,it]
    elseif s in U && t in vl
        is = findfirst(isequal(s),U)
        it = findfirst(isequal(t),vl)
        qs,rs = vl_absorbed_push(G,s,vl,rmax)
        return qs[s]/G.deg[s] + P[is,:]'*SCInverse*P[is,:] + SCInverse[it,it] - 2*P[is,:]'*SCInverse[:,it]
    elseif s in vl && t in U
        is = findfirst(isequal(s),vl)
        it = findfirst(isequal(t),U)
        qt,rt = vl_absorbed_push(G,t,vl,rmax)
        return qt[t]/G.deg[t] + P[it,:]'*SCInverse*P[it,:] + SCInverse[is,is] - 2*P[it,:]'*SCInverse[:,is]
    elseif s in U && t in U
        println("start to stupid find")
        is = findfirst(isequal(s),U)
        it = findfirst(isequal(t),U)
        println("start pushing")
        qs,rs = vl_absorbed_push(G,s,vl,rmax)
        qt,rt = vl_absorbed_push(G,t,vl,rmax)
        println("end pushing")
        
        Ps_SCI = P[is,:]'*SCInverse
        Pt_SCI = P[it,:]'*SCInverse
        rst =  qs[s]/G.deg[s] + qt[t]/G.deg[t] - 2*qs[t]/G.deg[t] + Ps_SCI*P[is,:] + Pt_SCI*P[it,:] - 2*Ps_SCI*P[it,:]
        for i in 1:omega
            current = s;
            while current ∉ vl
                rst += (rs[current]-rt[current]) / (G.deg[current] * omega);
                current = choose_neighbor(G,current);
            end
        end
        for i in 1:omega
            current = t;
            while current ∉ vl
                rst += (rt[current]-rs[current]) / (G.deg[current] * omega);
                current = choose_neighbor(G,current);
            end
        end
        return rst
    end

    

end


function er_p_trun(G::EdgeGraph,s::Int,t::Int,p::Int,omega::Int)
    rst = 1.0/G.deg[s] + 1.0/G.deg[t]
    for i in 1:p
        piss = 0.
        pist = 0.
        pits = 0.
        pitt = 0.
        for k in 1:omega
            current_s = s
            current_t = t
            current_step = 0
            while current_step < omega
                current_s = choose_neighbor(G,current_s)
                current_t = choose_neighbor(G,current_t)
                current_step += 1
            end
            if current_s == s
                piss += 1.0/omega
            end
            if current_s == t
                pist += 1.0/omega
            end
            if current_t == s
                pits += 1.0/omega
            end
            if current_t == t
                pitt += 1.0/omega
            end
        end
        rst += piss/G.deg[s] + pitt/G.deg[t] - pist/G.deg[t] - pits/G.deg[s]
    end
    return rst
end


# include("IO.jl")
# include("generator-matrix.jl")
# G = read_edgegraph("demo.txt")
# prepcompute_Pf(G,[2,3],10000)
# A = read_adjacent("datasets/caida.txt",beginnode=0)
# G = convert_adjacent2edgegraph(A)
# k = 10
# vl = sortperm(G.deg,rev=true)[1:k]
# G.deg[vl]
# @time P = prepcompute_Pr(G,vl,1000)
# @time SCInverse = precompute_SchurComplementInverse(G,vl,P)
# @time er_SCbased(G,1,4,vl,P,SCInverse,1e-6)
# @time er_Push(G,1,4,vl[1],1e-6)