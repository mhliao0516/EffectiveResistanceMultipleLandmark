"""
用于定义项目所需的数据结构
"""

"""
传统的(V,E,W)图结构
    g   邻边
    wts 权重
    deg 度
    n   节点数
    m   边数
    weighted    是否带权
"""

mutable struct EdgeGraph{T<:Number} 
    g::Vector{Vector{Int}}
    wts::Vector{Vector{T}}
    deg::Vector{T}
    n::Int
    m::T
    weighted::Bool
end

"""
自定义的类似Vector{Vector{T}}的数据结构，可以自动初始化每个分量的向量为[],其余使用与Vector{Vector{T}}相同
"""
struct VectorArray{T} <: AbstractVector{Vector{T}}
    data::Vector{Vector{T}}
    VectorArray{T}() where T = new{T}(Vector{T}[])
    VectorArray{T}(n::Int) where T = new{T}([T[] for _ in 1:n])
end

Base.size(va::VectorArray) = (length(va.data),)
Base.getindex(va::VectorArray, i::Int) = va.data[i]
Base.setindex!(va::VectorArray, v, i::Int) = (va.data[i] = v)
Base.push!(va::VectorArray, v::Vector) = push!(va.data, v)
Base.length(va::VectorArray) = length(va.data)
Base.IteratorSize(::Type{<:VectorArray}) = Base.HasShape{1}()
Base.eltype(::Type{<:VectorArray{T}}) where T = Vector{T}
Base.iterate(va::VectorArray, state=1) = state > length(va) ? nothing : (va[state], state+1)
Base.getindex(va::VectorArray, r::UnitRange{Int}) = [va[i] for i in r]
Base.setindex!(va::VectorArray, v::Vector, r::UnitRange{Int}) = (va.data[r] .= Ref(v))
