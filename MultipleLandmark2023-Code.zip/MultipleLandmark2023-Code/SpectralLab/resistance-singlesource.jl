include("datastructure.jl")
include("tools-graph.jl")

include("resistance-singlepair.jl")

function er_LEwalk_singlesource(G::EdgeGraph,s::Int,T::Int,verbose::Bool=false)
    rsu = zeros(Float64,G.n)
    inTree = zeros(Bool,G.n)
    next = -ones(Int,G.n)
    ind = [1:s-1;s+1:G.n]
    for i in 1:T
        if verbose && i%100==0
            println("in er_LEwalk_singlesource,times: ",i)
        end
        inTree .= false
        next .= -1
        inTree[s] = true
        for j in ind
            u = j
            rsu[u] += 1/(G.deg[u]*T)
            while !inTree[u]
                next[u] = choose_neighbor(G,u)
                u = next[u]
                rsu[u] += 1/(G.deg[u]*T)
            end
            rsu[u] -= 1/(G.deg[u]*T)
            u = j
            while !inTree[u]
                inTree[u] = true
                u = next[u]
            end
        end
    end
    return rsu
end

function er_AbWalkstar_singlesource(G::Int,s::Int,v::Int,T::Int,RV::Vector)
    rsu = zeros(Float64,G.n)
    τs = zeros(Float64,G.n)
    for i in 1:T
        u = s
        while u != v
            τs[u] += 1/T
            u = choose_neighbor(G,u)
        end
    end
    for u in 1:G.n
        rsu[u] = RV[s] + RV[u] - 2*τs[u]/G.deg[u]
    end
    return rsu
end

function er_Pushstar_singlesource(G::EdgeGraph,s::Int,v::Int,rmax::Float64,RV::Vector)
    rsu = zeros(Float64,G.n)
    τs,r = v_absorbed_push(G,s,v,rmax)
    for u in 1:G.n
        rsu[u] = RV[s] + RV[u] - 2*τs[u]/G.deg[u]
    end
    return rsu
end

function precompute_Luuinv(G::EdgeGraph,vl::Vector{Int},ω::Int,verbose::Bool=false)
    U = filter(!in(vl),1:G.n)
    Luuinv = zeros(Float64,G.n)
    inTree = zeros(Bool, G.n)
    next = -ones(Int,G.n)
    
    for times in 1:ω
        inTree .= false
        next .= -1
        inTree[vl] .= true

        if verbose && times%100==0
            println("in precompute_Luuinv,times:",times)
        end

        for i in U
            u = i
            while !inTree[u]
                next[u] = choose_neighbor(G, u)
                Luuinv[u] += 1.0/(G.deg[u]*ω)
                u = next[u]
            end
            u = i
            while !inTree[u]
                inTree[u] = true
                u = next[u]
            end
        end
    end
    return Luuinv[U]
end

function  er_SCbased_singlesource(G::EdgeGraph,s::Int,Luuinv::Vector,P::Matrix,SCInverse::Matrix,pushrmax::Float64)
    U = filter(!in(vl),1:G.n)
    rsu = zeros(Float64,G.n)
    if s in vl
        is = findfirst(isequal(s),vl)
        for u in 1:G.n
            if u in vl
                iu = findfirst(isequal(u),vl)
                rsu[u] = SCInverse[is,is] + SCInverse[iu,iu] - 2*SCInverse[is,iu]
            else
                iu = findfirst(isequal(u),U)
                rsu[u] = SCInverse[is,is] + Luuinv[iu] + P[iu,:]'*SCInverse*P[iu,:] - 2*P[iu,:]'*SCInverse[:,is]
            end
        end
        return rsu
    else
        is = findfirst(isequal(s),U)
        println("start push")
        tpush = @elapsed qs,rs = vl_absorbed_push(G,s,vl,pushrmax)
        println("pushtime:",tpush)
        Ps_SCI = P[is,:]'*SCInverse
        for u in 1:G.n
            if u in vl
                iu = findfirst(isequal(u),vl)
                rsu[u] = SCInverse[iu,iu] + Luuinv[is] + P[is,:]'*SCInverse*P[is,:] - 2*P[is,:]'*SCInverse[:,iu]
            else
                iu = findfirst(isequal(u),U)
                rsu[u] = Luuinv[is] + Luuinv[iu] - 2*qs[u]/G.deg[u] + Ps_SCI*P[is,:] + P[iu,:]'*SCInverse*P[iu,:] - 2*Ps_SCI*P[iu,:]
            end
        end
        return rsu
    end
end