using SparseArrays
using LinearAlgebra
using Arpack
using JLD2

include("../IO.jl")
include("../sampler.jl")
include("../tools-graph.jl")
include("../tools-matrix.jl")


BASE_DIR = "parameter-analysis-julia/"

dataset = ARGS[1]
# selectNumMax = parse(Int,ARGS[2])

println("dataset:$(dataset)")
filename = "datasets/$(dataset).txt"

if dataset in ["astro-ph","email-enron"]
    skipstart,beginnode,appear_twice = 0,0,true
elseif dataset in ["youtube","pokec","orkut"]
    skipstart,beginnode,appear_twice = 1,0,false
elseif dataset in ["web-Stanford","road-bay","road-powergrid"]
    skipstart,beginnode,appear_twice = 0,1,false
elseif dataset in ["web-Stanford1","road-bay1","com-dblp1","com-hep-th1","road-CA1","road-PA1"]
    skipstart,beginnode,appear_twice = 0,1,true
elseif dataset in ["com-dblp","road-CA","road-PA"] 
    skipstart,beginnode,appear_twice = 0,0,false
elseif  dataset in ["com-hep-th"]
    skipstart,beginnode,appear_twice = 0,1,false
else
    throw(UndefKeywordError)
end

a = read_adjacent(filename,skipstart=skipstart,beginnode=beginnode,appear_twice=appear_twice)
ga = convert_adjacent2edgegraph(a)
# ca = biggestComp(a)
# gca = convert_adjacent2edgegraph(ca)
# write_edgegraph("datasets/$(dataset)1.txt",gca)

function pagerank_rank(G::EdgeGraph,alpha=0.15)
    pageranks = zeros(Int,G.n)
    for i in 1:100000
        temp = rand(1:G.n)
        while rand() > alpha
            temp = choose_neighbor(G,temp)
        end
        pageranks[temp] += 1
    end
    parerank_rank = sortperm(pageranks,rev=true)
    return parerank_rank
end

function degree_plus_rank(G::EdgeGraph,cut_length::Int=1001)
    deg_copy = copy(G.deg)
    deg_plus_rank = zeros(Int,cut_length)
    for i in 1:cut_length
        println("i=",i)
        v = argmax(deg_copy)
        if deg_copy[v] < 0
            println("degree_plus_rank is over when i = ",i)
            break
        end
        deg_copy[v] = -1
        for neighbor in G.g[v]
            deg_copy[neighbor] = -1
        end
        deg_plus_rank[i] = v
    end
    return deg_plus_rank
end/SpectralLab/
    for i in 1:100000
        temp = rand(1:G.n)
        while rand() > alpha
            temp = choose_neighbor(G,temp)
        end
        pageranks[temp] += 1
    end
    pgrank_plus_rank = zeros(Int,G.n)
    for i in 1:G.n
        v = argmax(pageranks)
        if pageranks[v] < 0
            println("pagerank_plus_rank is over when i = ",i)
            break
        end
        pageranks[v] = -1
        for neighbor in G.g[v]
            pageranks[neighbor] = -1
        end
        pgrank_plus_rank[i] = v
    end
    return pgrank_plus_rank
end

for vl_strategy in ["degree","pagerank","random","degree+","pagerank+"]
# for vl_strategy in ["degree+"]
    if vl_strategy == "degree"
        deg_rank = sortperm(ga.deg,rev=true)
        vlseq = deg_rank
    elseif vl_strategy == "pagerank"
        vlseq = pagerank_rank(ga)
    elseif vl_strategy == "random"
        vlseq = randperm(ga.n)
    elseif vl_strategy == "degree+"
        vlseq = degree_plus_rank(ga)
    elseif vl_strategy == "pagerank+"
        vlseq = pagerank_plus_rank(ga)
    else 
        throw(UndefKeywordError)
    end
    save_dir = BASE_DIR * "vl/$(vl_strategy)/$(dataset)/"
    if !isdir(save_dir)
        mkdir(save_dir)
    end
    open(BASE_DIR * "vl/$(vl_strategy)/$(dataset)/vlseq.txt","w") do f
        writedlm(f,vlseq)
    end
    println("$(dataset) $(vl_strategy) vlseq written")
end
