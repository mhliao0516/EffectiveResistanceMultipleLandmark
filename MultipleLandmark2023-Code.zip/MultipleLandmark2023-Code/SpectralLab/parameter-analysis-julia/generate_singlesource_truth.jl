using SparseArrays
using LinearAlgebra
using Arpack
using JLD2

include("../IO.jl")
include("../sampler.jl")
include("../tools-graph.jl")
include("../tools-matrix.jl")
include("../resistance-exact.jl")
include("../resistance-singlesource.jl")

BASE_DIR = "parameter-analysis-julia/"

dataset = ARGS[1]
selectNum = parse(Int,ARGS[2])

println("dataset:$(dataset)")
filename = "datasets/$(dataset).txt"

if dataset in ["astro-ph","email-enron"]
    skipstart,beginnode,appear_twice = 0,0,true
elseif dataset in ["youtube","pokec","orkut"]
    skipstart,beginnode,appear_twice = 1,0,false
elseif dataset in ["web-Stanford","road-bay","road-powergrid"]
    skipstart,beginnode,appear_twice = 0,1,false
elseif dataset[end] == '1'
    skipstart,beginnode,appear_twice = 0,1,true
elseif dataset in ["com-dblp"] 
    skipstart,beginnode,appear_twice = 0,0,false
elseif  dataset in ["com-hep-th"]
    skipstart,beginnode,appear_twice = 0,1,false
else
    throw(UndefKeywordError)
end

function read_vlseq(dataset,vl_strategy)
    vlseq = readdlm(BASE_DIR * "vl/$(vl_strategy)/$(dataset)/vlseq.txt",Int)
    return vlseq
end

G = read_edgegraph(filename,skipstart=skipstart,beginnode=beginnode,appear_twice=appear_twice)
v = argmax(G.deg)
vl_strategy = "degree+"
vlseq = read_vlseq(dataset,vl_strategy)[:,1]
vl = vlseq[1:selectNum]
# singlesource
save_dir = BASE_DIR * "groundTruth/exact_singlesource/$(dataset)/"
if !isdir(save_dir)
    mkdir(save_dir)
end

if G.n < 100000
    println("using small graph($(dataset)) exact algorithm")
    a = read_adjacent(filename,skipstart=skipstart,beginnode=beginnode,appear_twice=appear_twice)
    L = lap(a)
    ind = [1:v-1;v+1:G.n]
    Lv = L[ind,ind]
    solver = cholesky_solver(Lv)
    println("Starting")

    for s in choose_k_vertices(G,10)
        rsu = er_exact_singlesource(L,solver,s,v)
        println(s,rsu[1:10])
        open(save_dir * "$(s-1).txt","w") do f
            writedlm(f,rsu)   
        end
    end
    println("ended")
else
    println("using large graph($(dataset)) approximate algorithm")
    println("Starting")
    Luuinv = load("/home/mhliao/SpectralLab/parameter-analysis-julia/groundTruth/exact_Luuinv/$vl_strategy/$dataset/$selectNum.jld2","Luuinv")
    P = load("/home/mhliao/SpectralLab/parameter-analysis-julia/groundTruth/exact_p/$vl_strategy/$dataset/$selectNum.jld2","P")
    SCInverse = precompute_SchurComplementInverse(G,vl,P)
    for s in choose_k_vertices(G,10)
        ti = @elapsed rsu = er_SCbased_singlesource(G,s,Luuinv,P,SCInverse,1e-5)
        println(s,rsu[1:10],", time:",ti)
        open(save_dir * "$(s-1).txt","w") do f
            writedlm(f,rsu)   
        end
    end
    println("ended")
end

