BASE_DIR=./parameter-analysis-julia
BASE_LOG_DIR=$BASE_DIR/logs
nohup julia $BASE_DIR/get_various_vl.jl $1 > $BASE_LOG_DIR/get_various_vl/$1.log 2>&1 &