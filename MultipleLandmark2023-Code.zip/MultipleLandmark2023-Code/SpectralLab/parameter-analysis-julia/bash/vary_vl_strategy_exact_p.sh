BASE_DIR=./parameter-analysis-julia
BASE_LOG_DIR=$BASE_DIR/logs
nohup julia $BASE_DIR/vary_vl_strategy_exact_p.jl $1 $2 > $BASE_LOG_DIR/vary_vl_strategy_exact_p/$1.log 2>&1 &