using SparseArrays
using LinearAlgebra
using Arpack
using JLD2

include("../IO.jl")
include("../sampler.jl")
include("../tools-graph.jl")
include("../tools-matrix.jl")
include("../resistance-singlepair.jl")

BASE_DIR = "parameter-analysis-julia/"

dataset = ARGS[1]
selectNum = parse(Int,ARGS[2])

println("dataset:$(dataset), selectNum:$(selectNum)")
filename = "datasets/$(dataset).txt"

if dataset in ["astro-ph","email-enron"]
    skipstart,beginnode,appear_twice = 0,0,true
elseif dataset in ["youtube","pokec","orkut"]
    skipstart,beginnode,appear_twice = 1,0,false
elseif dataset in ["web-Stanford","road-bay","road-powergrid"]
    skipstart,beginnode,appear_twice = 0,1,false
elseif dataset[end] == '1'
    skipstart,beginnode,appear_twice = 0,1,true
elseif dataset in ["com-dblp"] 
    skipstart,beginnode,appear_twice = 0,0,false
elseif  dataset in ["com-hep-th"]
    skipstart,beginnode,appear_twice = 0,1,false
else
    throw(UndefKeywordError)
end

ga = read_edgegraph(filename,skipstart=skipstart,beginnode=beginnode,appear_twice=appear_twice)

function read_vlseq(dataset,vl_strategy)
    vlseq = readdlm(BASE_DIR * "vl/$(vl_strategy)/$(dataset)/vlseq.txt",Int)
    return vlseq
end


vl_strategy = "degree+"
vlseq = read_vlseq(dataset,vl_strategy)[:,1]
save_dir = BASE_DIR * "groundTruth/exact_p/$(vl_strategy)/$(dataset)/"
if !isdir(save_dir)
    mkdir(save_dir)
end

vl = vlseq[1:selectNum]
println("vl:",vl)
P = precompute_Pf(ga,vl,500)
save(save_dir * "$(selectNum).jld2", "P", P)
println("successfully saved to $(save_dir)$(selectNum).jld2")