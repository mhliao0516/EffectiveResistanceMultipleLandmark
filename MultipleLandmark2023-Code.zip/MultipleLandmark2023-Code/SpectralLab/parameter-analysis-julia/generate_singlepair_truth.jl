using SparseArrays
using LinearAlgebra
using Arpack
using JLD2

include("../IO.jl")
include("../sampler.jl")
include("../tools-graph.jl")
include("../tools-matrix.jl")
include("../resistance-exact.jl")
include("../resistance-singlepair.jl")

BASE_DIR = "parameter-analysis-julia/"

dataset = ARGS[1]
selectNum = parse(Int, ARGS[2])

println("dataset:$(dataset)")
filename = "datasets/$(dataset).txt"

if dataset in ["astro-ph","email-enron"]
    skipstart,beginnode,appear_twice = 0,0,true
elseif dataset in ["youtube","pokec","orkut"]
    skipstart,beginnode,appear_twice = 1,0,false
elseif dataset in ["web-Stanford","road-bay","road-powergrid"]
    skipstart,beginnode,appear_twice = 0,1,false
elseif dataset[end] == '1'
    skipstart,beginnode,appear_twice = 0,1,true
elseif dataset in ["com-dblp"] 
    skipstart,beginnode,appear_twice = 0,0,false
elseif  dataset in ["com-hep-th"]
    skipstart,beginnode,appear_twice = 0,1,false
else
    throw(UndefKeywordError)
end


G = read_edgegraph(filename,skipstart=skipstart,beginnode=beginnode,appear_twice=appear_twice)
v = argmax(G.deg)

function read_vlseq(dataset,vl_strategy)
    vlseq = readdlm(BASE_DIR * "vl/$(vl_strategy)/$(dataset)/vlseq.txt",Int)
    return vlseq
end

# singlepair
save_dir = BASE_DIR * "groundTruth/exact_singlepair/$(dataset)/"
if !isdir(save_dir)
    mkdir(save_dir)
end

if G.n < 100000
    println("using small graph($(dataset)) exact algorithm")
    a = read_adjacent(filename,skipstart=skipstart,beginnode=beginnode,appear_twice=appear_twice)
    L = lap(a)
    ind = [1:v-1;v+1:G.n]
    Lv = L[ind,ind]
    solver = cholesky_solver(Lv)
    println("Starting")

    for pair in choose_k_pairs(G,100)
        s,t = pair
        rst = er_exact_singlepair(L,solver,s,t,v)
        println((s,t),rst)
        open(save_dir * "($(s-1),$(t-1)).txt","w") do f
            write(f,"$(rst)\n")        
        end
    end
    println("ended")
else
    if dataset[1:4]  == "road"
        println("using large graph($(dataset)) approximate algorithm")
        vl_strategy = "degree+"
        vlseq = read_vlseq(dataset,vl_strategy)[:,1]
        vl = vlseq[1:selectNum]
        P = load(BASE_DIR * "groundTruth/exact_p/$(vl_strategy)/$(dataset)/$(selectNum).jld2","P")
        println("loaded P from:",BASE_DIR * "groundTruth/exact_p/$(vl_strategy)/$(dataset)/$(selectNum).jld2")
        SCInverse = precompute_SchurComplementInverse(G,vl,P)
        println("vl:",vl)
        println("Starting")
        for pair in choose_k_pairs(G,100)
            s,t = pair
            ti = @elapsed rst = er_SCbased_Bipush(G,s,t,vl,P,SCInverse,1e-5,5000)
            println((s,t),rst,", time:",ti)
            open(save_dir * "($(s-1),$(t-1)).txt","w") do f
                write(f,"$(rst)\n")        
            end
        end
        println("ended")
    else
        println("Starting")
        for pair in choose_k_pairs(G,100)
            s,t = pair
            ti = @elapsed rst = er_Bipush(G,s,t,v,1e-5,5000)
            println((s,t),rst,", time:",ti)
            open(save_dir * "($(s-1),$(t-1)).txt","w") do f
                write(f,"$(rst)\n")        
            end
        end
        println("ended")
    end
end

