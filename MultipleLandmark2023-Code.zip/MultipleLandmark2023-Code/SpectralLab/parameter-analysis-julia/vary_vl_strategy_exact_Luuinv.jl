using SparseArrays
using LinearAlgebra
using Arpack
using JLD2

include("../IO.jl")
include("../sampler.jl")
include("../tools-graph.jl")
include("../tools-matrix.jl")
include("../resistance-singlesource.jl")

BASE_DIR = "parameter-analysis-julia/"

dataset = ARGS[1]
selectNumMax = parse(Int,ARGS[2])

println("dataset:$(dataset), selectNumMax:$(selectNumMax)")
filename = "datasets/$(dataset).txt"

if dataset in ["astro-ph","email-enron"]
    skipstart,beginnode,appear_twice = 0,0,true
elseif dataset in ["youtube","pokec","orkut"]
    skipstart,beginnode,appear_twice = 1,0,false
elseif dataset in ["web-Stanford","road-bay","road-powergrid"]
    skipstart,beginnode,appear_twice = 0,1,false
elseif dataset in ["web-Stanford1","road-bay1","com-dblp1","com-hep-th1"]
    skipstart,beginnode,appear_twice = 0,1,true
elseif dataset in ["com-dblp"] 
    skipstart,beginnode,appear_twice = 0,0,false
elseif  dataset in ["com-hep-th"]
    skipstart,beginnode,appear_twice = 0,1,false
else
    throw(UndefKeywordError)
end

a = read_adjacent(filename,skipstart=skipstart,beginnode=beginnode,appear_twice=appear_twice)
ga = convert_adjacent2edgegraph(a)
L = lap(a)

function read_vlseq(dataset,vl_strategy)
    vlseq = readdlm(BASE_DIR * "vl/$(vl_strategy)/$(dataset)/vlseq.txt",Int)
    return vlseq
end

for vl_strategy in ["degree","pagerank","random","degree+","pagerank+"]
# for vl_strategy in ["degree+"]
    vlseq = read_vlseq(dataset,vl_strategy)[:,1]
    save_dir = BASE_DIR * "groundTruth/exact_Luuinv/$(vl_strategy)/$(dataset)/"
    if !isdir(save_dir)
        mkdir(save_dir)
    end

    for selectNum in 1:selectNumMax
        if dataset in ["email-enron", "com-hep-th1"]
            vl = vlseq[1:selectNum]
            println("vl:",vl)
            U = [i for i in 1:ga.n if i ∉ vl]
            Luuinv = precompute_Luuinv(ga,vl,20000,false)
            save(save_dir * "$(selectNum).jld2", "Luuinv", Luuinv)
            println("successfully saved to $(save_dir)$(selectNum).jld2")
        else
            vl = vlseq[1:selectNum]
            println("vl:",vl)
            U = [i for i in 1:ga.n if i ∉ vl]
            Luu = L[U,U]
            Luvl = L[U,vl]
            solver = cholesky_solver(Luu)
            Luuinv = zeros(Float64,length(U))
            ei = zeros(Float64,length(U))
            ei[1] = 1.
            for i in 1:length(U)
                if i > 1
                    ei[i-1] = 0.
                    ei[i] = 1.
                end
                Luuinv[i] = solver(ei)[i]
            end
            save(save_dir * "$(selectNum).jld2", "Luuinv", Luuinv)
            println("successfully saved to $(save_dir)$(selectNum).jld2")
        end
    end
end
