using SparseArrays
using DelimitedFiles

include("datastructure.jl")

function read_adjacent(fn::AbstractString;delimiter::AbstractChar='\t',skipstart::Int=0,beginnode::Int=1,appear_twice=false)
    # first, detect the delimiter type
    fh = open(fn)
    ln = readline(fh)
    close(fh)

    if occursin(delimiter, ln)
        data = readdlm(fn,delimiter,skipstart=skipstart)
    else
        data = readdlm(fn,skipstart=skipstart)
    end

    if beginnode != 1
        data .+= 1-beginnode
    end

    n = maximum(data[:,1:2])

    edlist = convert(Array{Int64,2}, data[:,1:2])

    if size(data,2) == 3
        wts = convert(Array{Float64,1},data[:,3])
    else
        wts = convert(Array{Int,1},ones(size(data,1)))
    end

    a = sparse(edlist[:,1],edlist[:,2],wts,n,n)
    if !appear_twice
        if size(data,2) == 2
            a = a .| a'
        else
            a = a + a'
        end
    end

    return a
end


function read_edgegraph(fn::AbstractString;delimiter::AbstractChar='\t',skipstart::Int=0,beginnode::Int=1,appear_twice=false)
    # first, detect the delimiter type
    fh = open(fn)
    ln = readline(fh)
    close(fh)

    if occursin(delimiter, ln)
        data = readdlm(fn,delimiter,skipstart=skipstart)
    else
        data = readdlm(fn,skipstart=skipstart)
    end

    if beginnode != 1
        data .+= 1-beginnode
    end

    edlist = convert(Array{Int64,2}, data[:,1:2])
    n = maximum(edlist)
    m = size(edlist,1)
    if appear_twice
        m = m / 2
    end

    g = VectorArray{Int}(n)
    wts = VectorArray{Float64}(n)

    weighted = false
    if size(data,2) == 3
        weighted = true
        wlist = data[:,3]
        for edge in zip(edlist,wlist) 
            push!(g[edge[1][1]],edge[1][2])
            push!(wts[edge[1][1]],edge[2])
            if !appear_twice
                push!(g[edge[1][2]],edge[1][1])     
                push!(wts[edge[1][2]],edge[2])
            end
        end
    else
        for edge in eachrow(edlist)
            
            push!(g[edge[1]],edge[2])
            push!(wts[edge[1]],1.0)
            if !appear_twice
                push!(g[edge[2]],edge[1])        
                push!(wts[edge[2]],1.0)
            end
        end
    end

    deg = sum.(wts)

    G = EdgeGraph{Float64}(g,wts,deg,n,m,weighted)
    return G
end

function convert_adjacent2edgegraph(A::SparseMatrixCSC)
    ai,aj,av = findnz(A)
    m = convert(Int,length(ai)/2)
    n = size(A,1)
    g = VectorArray{Int}(n)
    wts = VectorArray{Float64}(n)
    for i in 1:2*m
        push!(g[ai[i]],aj[i])
        push!(wts[ai[i]],av[i])
    end
    deg = sum.(wts)
    G = EdgeGraph{Float64}(g,wts,deg,n,m,false)
    return G
end

function convert_edgegraph2adjacent(G::EdgeGraph)
    ai = Int[]
    aj = Int[]
    av = Float64[]
    for u in 1:G.n
        append!(ai,ones(Int,length(G.g[u]))*u)
        append!(aj,G.g[u])
        append!(av,G.wts[u])
    end
    return sparse(ai,aj,av,G.n,G.n)
end

function write_edgegraph(fn::AbstractString,G::EdgeGraph)
    if G.weighted
        open(fn,"w") do f
            for node in 1:G.n
                for edge in zip(G.g[node],G.wts[node])
                    p1 = edge[1]
                    w = edge[2]
                    write(f,"$(node)\t$(p1)\t$(w)\n")
                end
            end
        end
    else
        open(fn,"w") do f
            for node in 1:G.n
                for edge in G.g[node]
                    write(f,"$(node)\t$(edge)\n")
                end
            end
        end
    end 
    return fn    
end
