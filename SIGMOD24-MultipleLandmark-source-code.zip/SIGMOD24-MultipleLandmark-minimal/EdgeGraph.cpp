#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <random>
#include <queue>
#include <algorithm>
#include <sys/time.h>
#include "Eigen/Dense"
#include "EdgeGraph.h"
#include "alias.h"

using namespace std;

int weighted_rand(const vector<double> weight, double randomNum)
{
    int size = weight.size();
    double tempSum = 0;
    for (int j = 0; j < size; j++)
    {
        tempSum += weight[j];
        if (randomNum <= tempSum)
        {
            return j;
        }
    }
    return size;
}

double get_current_time_sec_method()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}

EdgeGraph read_edgegraph(const std::string &fn, char delimiter, int skipstart, int beginnode, bool appear_twice)
{
    typedef double T;
    std::ifstream file(fn);
    std::string line;
    getline(file, line);

    char detected_delimiter = delimiter;
    if (std::count(line.begin(), line.end(), delimiter) == 0)
    {
        detected_delimiter = ' ';
    }

    file.clear();
    file.seekg(0);
    for (int i = 0; i < skipstart; ++i)
    {
        getline(file, line);
    }
    std::vector<std::vector<T>> data;
    std::string cell;
    while (getline(file, line))
    {
        std::vector<T> row;
        std::stringstream lineStream(line);
        while (getline(lineStream, cell, detected_delimiter))
        {
            row.push_back(static_cast<T>(std::stod(cell)));
        }
        data.push_back(row);
    }
    file.close();

    if (beginnode != 0)
    {
        for (auto &row : data)
        {
            row[0] += 0 - beginnode;
            row[1] += 0 - beginnode;
        }
    }

    std::vector<std::vector<int>> edlist;
    for (const auto &row : data)
    {
        edlist.push_back({static_cast<int>(row[0]), static_cast<int>(row[1])});
    }

    int n = 0;
    for (const auto &edge : edlist)
    {
        n = std::max({n, edge[0], edge[1]});
    }
    n += 1;

    int m = appear_twice ? edlist.size() / 2 : edlist.size();

    std::vector<std::vector<int>> g(n);
    std::vector<std::vector<T>> wts(n);

    bool weighted = data[0].size() == 3;

    if (weighted)
    {
        for (const auto &row : data)
        {
            int from = static_cast<int>(row[0]);
            int to = static_cast<int>(row[1]);
            T weight = row[2];
            g[from].push_back(to);
            wts[from].push_back(weight);
            if (!appear_twice)
            {
                g[to].push_back(from);
                wts[to].push_back(weight);
            }
        }
    }
    else
    {
        for (const auto &edge : edlist)
        {
            int from = edge[0];
            int to = edge[1];
            g[from].push_back(to);
            wts[from].push_back(1.0);
            if (!appear_twice)
            {
                g[to].push_back(from);
                wts[to].push_back(1.0);
            }
        }
    }

    std::vector<T> deg(n);
    for (int i = 0; i <= n - 1; ++i)
    {
        for (const auto &weight : wts[i])
        {
            deg[i] += weight;
        }
    }

    EdgeGraph G;
    G.g = g;
    G.wts = wts;
    G.deg = deg;
    G.n = n;
    G.m = m;
    G.weighted = weighted;
    
    G.show(); // 展示图信息

    return G;
}

int EdgeGraph::choose_neighbor(int node)
{
    int random_index = rand() % g[node].size();
    return g[node][random_index];
}

pair<vector<double>, vector<double>> EdgeGraph::v_absorbed_push(int s, int v, double rmax)
{
    vector<double> r(n, 0.0); // Residual probabilities initialized to 0
    r[s] = 1.0;
    vector<double> q(n, 0.0); // Absorption probabilities initialized to 0

    if (s == v)
    {
        return make_pair(q, r);
    }

    
    queue<int> push_queue;
    push_queue.push(s);
    vector<bool> is_inQueue(n, false);
    is_inQueue[s] = true;

    int pushcnt = 0;

    while (!push_queue.empty())
    {
        int u = push_queue.front();
        push_queue.pop();
        is_inQueue[u] = false;
        q[u] += r[u];

        for (size_t i = 0; i < g[u].size(); ++i)
        {
            int neighbor = g[u][i];

            if (neighbor != v)
            {
                r[neighbor] +=  r[u] / deg[u];
                if (r[neighbor] >= deg[neighbor] * rmax && !is_inQueue[neighbor])
                {
                    push_queue.push(neighbor);
                    is_inQueue[neighbor] = true;
                    pushcnt++;
                }
            }
        }

        r[u] = 0.0;

    }

    // cout << "in s=" << s << ",push cnt:" << pushcnt << endl;
    return make_pair(q, r);
}

pair<vector<double>, vector<double>> EdgeGraph::v_absorbed_push(vector<double> s, int v, double rmax)
{
    vector<double> r(n, 0.0); // Residual probabilities initialized to 0
    vector<double> q(n, 0.0); // Absorption probabilities initialized to 0

    if (s.size() != static_cast<size_t>(n))
    {
        throw invalid_argument("Size of input vector 's' must be equal to the number of nodes in the graph.");
    }

    r = s; // Copy the initial probabilities to the 'r' vector

    queue<int> push_queue;
    vector<bool> is_inQueue(n, false);
    for (int i = 0; i < n; ++i)
    {
        if (r[i] > deg[i] * rmax)
        {
            push_queue.push(i);
            is_inQueue[i] = true;
        }
    }

    
    while (!push_queue.empty())
    {
        int u = push_queue.front();
        push_queue.pop();
        is_inQueue[u] = false;
        q[u] += r[u];

        for (size_t i = 0; i < g[u].size(); ++i)
        {
            int neighbor = g[u][i];

            if (neighbor != v)
            {
                r[neighbor] += r[u] / deg[u];
                if (r[neighbor] >= deg[neighbor] * rmax && !is_inQueue[neighbor])
                {
                    push_queue.push(neighbor);
                    is_inQueue[neighbor] = true;
                }
            }
        }

        r[u] = 0.0;
    }

    return make_pair(q, r);
}

pair<vector<double>, vector<double>> EdgeGraph::vl_absorbed_push(int s, const vector<int> &in_vl, double rmax) // in_vl可以是index_vl (见 resistance-singlepair.cpp)
{
    std::vector<double> r(n, 0.0);
    std::vector<double> q(n, 0.0);
    r[s] = 1.0;
    std::vector<int> push_queue = {s};
    std::vector<bool> is_inQueue(n, false);
    is_inQueue[s] = true;

    while (!push_queue.empty())
    {
        int u = push_queue.back();
        push_queue.pop_back();
        is_inQueue[u] = false;
        q[u] += r[u];

        for (size_t i = 0; i < g[u].size(); ++i)
        {
            int neighbor = g[u][i];
            if (!(in_vl[neighbor]>0))
            {
                r[neighbor] += r[u] / deg[u];
                if (r[neighbor] >= deg[neighbor] * rmax && !is_inQueue[neighbor])
                {
                    push_queue.push_back(neighbor);
                    is_inQueue[neighbor] = true;
                }
            }
        }

        r[u] = 0;
    }

    return std::make_pair(q, r);
}

vector<int> EdgeGraph::BFS(int root)
{
    vector<int> bfsnext(n, -2);
    bfsnext[root] = -1;
    queue<int> search_queue;
    search_queue.push(root);
    while (!search_queue.empty())
    {
        int current = search_queue.front();
        search_queue.pop();
        for (int neighbor : g[current])
        {
            if (bfsnext[neighbor] == -2)
            {
                bfsnext[neighbor] = current;
                search_queue.push(neighbor);
            }
        }
    }
    return bfsnext;
}

vector<int> EdgeGraph::BFS(const vector<int> &roots)
{
    vector<int> next(n, -2);
    queue<int> search_queue;

    for (int root : roots)
    {
        next[root] = -1;
        search_queue.push(root);
    }

    while (!search_queue.empty())
    {
        int current = search_queue.front();
        search_queue.pop();

        for (int neighbor : g[current])
        {
            if (next[neighbor] == -2)
            {
                next[neighbor] = current;
                search_queue.push(neighbor);
            }
        }
    }

    return next;
}

vector<int> EdgeGraph::wilson(int r)
{
    vector<bool> inTree(n, false);
    vector<int> next(n, -1);
    inTree[r] = true;

    for (int i = 0; i < n; ++i)
    {
        int u = i;
        while (!inTree[u])
        {
            next[u] = choose_neighbor(u);
            u = next[u];
        }

        u = i;
        while (!inTree[u])
        {
            inTree[u] = true;
            u = next[u];
        }
    }
    return next;
}

vector<int> EdgeGraph::wilson(vector<int> rl)
{
    vector<bool> inTree(n, false);
    vector<int> next(n, -1);

    for (size_t i = 0; i < rl.size(); ++i)
    {
        inTree[rl[i]] = true;
    }

    for (int i = 0; i < n; ++i)
    {
        int u = i;
        while (!inTree[u])
        {
            next[u] = choose_neighbor(u);
            u = next[u];
        }

        u = i;
        while (!inTree[u])
        {
            inTree[u] = true;
            u = next[u];
        }
    }

    return next;
}
