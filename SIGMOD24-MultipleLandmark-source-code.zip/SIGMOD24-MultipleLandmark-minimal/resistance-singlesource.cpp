#include <iostream>
#include <vector>
#include <tuple>
#include <algorithm>
#include <stack>
#include "Eigen/Dense"

#include "EdgeGraph.h"
#include "tools-matrix.h"
#include "resistance-singlepair.h"

using namespace std;

std::vector<double> er_LEwalk_singlesource(EdgeGraph &G, int s, int T)
{
    std::vector<double> rsu(G.n, 0.0);
    std::vector<bool> inTree(G.n, false);
    std::vector<int> next(G.n, -1);
    std::vector<int> ind = {};
    for (int i = 0; i < G.n; i++)
    {
        if (i != s)
        {
            ind.push_back(i);
        }
    }

    for (int i = 0; i < T; i++)
    {
        inTree.assign(G.n, false);
        next.assign(G.n, -1);
        inTree[s] = true;

        for (int j : ind)
        {
            int u = j;
            rsu[u] += 1.0 / (G.deg[u] * T);
            while (!inTree[u])
            {
                next[u] = G.choose_neighbor(u);
                u = next[u];
                rsu[u] += 1.0 / (G.deg[u] * T);
            }
            rsu[u] -= 1.0 / (G.deg[u] * T);
            u = j;
            while (!inTree[u])
            {
                inTree[u] = true;
                u = next[u];
            }
        }
    }

    return rsu;
}

vector<double> er_ST_singlesource(EdgeGraph &G, int s, int N) {
    int n = G.n;
    vector<int> bfs_parent = G.BFS(s);
    vector<double> rsu(n, 0);
    for(size_t i = 0; i < N; i++) {
        vector<int> next = G.wilson(s);

        // build childPtr and siblingPtr of Wilson's Spanning tree
        vector<int> childPtr(n, -1);
        vector<int> siblingPtr(n,-1);

        int visitNodes = 0;
        vector<bool> visited(n, false);
        for(int k=0; k<n; k++) {
            int u = k;
            while(!visited[u]) {
                visited[u] = true;
                ++visitNodes;
                int parentU = next[u];
                if(next[u] != -1) {
                    assert(siblingPtr[u] == -1);
                    if(childPtr[parentU] != -1) {
                        siblingPtr[u] = childPtr[parentU];
                    }
                    childPtr[parentU] = u;
                    u = parentU;
                } else {
                    break;
                }
            }
            if(visitNodes == n) break; 
        }

        // do DFS on the sampled tree
        vector<int> tVisit(n, 0);
        vector<int> tFinish(n, 0);

        std::stack<std::pair<int, int>> stack;
        stack.push({s, childPtr[s]});
        
        int timestamp = 0;
        do {
            int nodeu = stack.top().first;
            int nodev = stack.top().second;

            if(nodev == -1) {
                stack.pop();
                tFinish[nodeu] = ++timestamp;
            } else {
                stack.top().second = siblingPtr[nodev];
                tVisit[nodev] = ++timestamp;
                stack.push({nodev, childPtr[nodev]});
            }
        } while (!stack.empty());

        // compare BFS tree with sampled tree and aggragate
        for(int k=0; k<n; k++) {
            if(k != s){
                int u = k;

                int p = bfs_parent[u];
                int c = u;

                while (p != -1) {
                    int e1 = p, e2 = c;
                    bool reverse = false;
                    if(e1 != next[e2]) {
                        if(e2 != next[e1]) {
                            c = p;
                            p = bfs_parent[p];
                            continue;
                        }
                        std::swap(e1, e2);
                        reverse = true;
                    }

                    if(tVisit[u] >= tVisit[e2] && tFinish[u] <= tFinish[e2]) {
                        rsu[u] += reverse ? -1./N : 1./N;
                    }
                    c = p;
                    p = bfs_parent[p];
                }
            }
            
        }
    }
    return rsu;
}

std::vector<double> er_AbWalkstar_singlesource(EdgeGraph &G, int s, int v, int T, const std::vector<double> &RV)
{
    std::vector<double> rsu(G.n, 0.0);
    std::vector<double> tao_s(G.n, 0.0);

    for (int i = 0; i < T; i++)
    {
        int u = s;
        while (u != v)
        {
            tao_s[u] += 1.0 / T;
            u = G.choose_neighbor(u);
        }
    }

    for (int u = 0; u < G.n; u++)
    {
        rsu[u] = RV[s] + RV[u] - 2 * tao_s[u] / G.deg[u];
    }
    return rsu;
}

pair<int,double> argmaxx(const std::vector<double>& arr){
    int maxIndex = 0; 
    double maxx = -1;
    for (int i = 1; i < arr.size(); ++i) {
        if (arr[i] > arr[maxIndex]) {
            maxIndex = i;
            maxx = arr[i];
        }
    }
    return {maxIndex,maxx};
}
std::vector<double> er_Pushstar_singlesource(EdgeGraph &G, int s, int v, double rmax, const std::vector<double> &RV)
{
    std::vector<double> rsu(G.n, 0.0);
    std::vector<double> tao_s, r;
    tie(tao_s, r) = G.v_absorbed_push(s, v, rmax);

    cout << "RV[s]: " << RV[s] << endl;
    cout << "RV[0]: " << RV[0] << endl;
    cout << "s: " << s << ", tao_s[0] / G.deg[0] = "  << tao_s[0] / G.deg[0] << endl;
    cout << "r[0]: " << r[0] << ", r[1]: " << r[1] <<", r[s]: " << r[s] <<", ......" <<", argmaxx(r): " << argmaxx(r).first << "," << argmaxx(r).second << endl;

    for (int u = 0; u < G.n; u++)
    {
        rsu[u] = RV[s] + RV[u] - 2 * tao_s[u] / G.deg[u];
    }

    return rsu;
}

std::vector<double> precompute_Luuinv(EdgeGraph &G, const std::vector<int> &vl, const std::vector<int> &index_vl, int omega)
{

    std::vector<double> Luuinv(G.n - vl.size(), 0.0);
    std::vector<int> pathnext = G.BFS(vl);
    std::vector<bool> inTree(G.n, false);
    std::vector<int> next(G.n, -1);

    for (int iter = 0; iter < omega; iter++)
    {
        if(iter%100==0){
            cout << "in precompute_Luuinv: times: " << iter << endl;
        }
        inTree.assign(G.n, false);
        next.assign(G.n, -1);
        for(auto v:vl){
            inTree[v] = true; 
        }

        for(size_t i=0;i<G.n;i++){
            if(!(index_vl[i]>0)){
                int u = i;
                while (!inTree[u]){
                    next[u] = G.choose_neighbor(u);
                    int iu = -index_vl[u];
                    Luuinv[iu] += 1.0/(G.deg[u]*omega);
                    u = next[u];
                }
                u = i;
                while (!inTree[u]){
                    inTree[u] = true;
                    u = next[u];
                }
            }
        }
    }

    return Luuinv;
}

vector<double> precompute_Luuinv_ST(EdgeGraph &G, vector<int> vl,vector<int> index_vl, int N) {
    int n = G.n;
    vector<int> bfs_parent = G.BFS(vl);
    vector<double> Luuinv(n-vl.size(), 0);
    for(size_t i = 0; i < N; i++) {
        vector<int> next = G.wilson(vl);

        // build childPtr and siblingPtr of Wilson's Spanning tree
        vector<int> childPtr(n, -1);
        vector<int> siblingPtr(n,-1);

        int visitNodes = 0;
        vector<bool> visited(n, false);
        for(int k=0; k<n; k++) {
            int u = k;
            while(!visited[u]) {
                visited[u] = true;
                ++visitNodes;
                int parentU = next[u];
                if(next[u] != -1) {
                    assert(siblingPtr[u] == -1);
                    if(childPtr[parentU] != -1) {
                        siblingPtr[u] = childPtr[parentU];
                    }
                    childPtr[parentU] = u;
                    u = parentU;
                } else {
                    break;
                }
            }
            if(visitNodes == n) break; 
        }

        // do DFS on the sampled tree
        vector<int> tVisit(n, 0);
        vector<int> tFinish(n, 0);

        std::stack<std::pair<int, int>> stack;
        for(int i=vl.size()-1;i>=0;i--){
            stack.push({vl[i], childPtr[vl[i]]});
        }
        
        int timestamp = 0;
        do {
            int nodeu = stack.top().first;
            int nodev = stack.top().second;

            if(nodev == -1) {
                stack.pop();
                tFinish[nodeu] = ++timestamp;
            } else {
                stack.top().second = siblingPtr[nodev];
                tVisit[nodev] = ++timestamp;
                stack.push({nodev, childPtr[nodev]});
            }
        } while (!stack.empty());

        // compare BFS tree with sampled tree and aggragate
        for(int k=0; k<n; k++) {
            if(!(index_vl[k]>0)){
                int u = k;
                int iu = -index_vl[u];

                int p = bfs_parent[u];
                int c = u;

                while (p != -1) {
                    int e1 = p, e2 = c;
                    bool reverse = false;
                    if(e1 != next[e2]) {
                        if(e2 != next[e1]) {
                            c = p;
                            p = bfs_parent[p];
                            continue;
                        }
                        std::swap(e1, e2);
                        reverse = true;
                    }

                    if(tVisit[u] >= tVisit[e2] && tFinish[u] <= tFinish[e2]) {
                        Luuinv[iu] += reverse ? -1./N : 1./N;
                    }
                    c = p;
                    p = bfs_parent[p];
                }
            }
            
        }
    }
    return Luuinv;
}

std::vector<double> er_vl_rw_singlesource(EdgeGraph &G, int s,
                                          const std::vector<int> &vl, const std::vector<int> &index_vl,
                                          const vector<double> &Luuinv, const vector<vector<double>> &P, const Eigen::MatrixXd &SCInverse ,const vector<double> &Pu_SCI_Pu,
                                          int omega)
{

    std::vector<double> rsu(G.n);

    if (index_vl[s] > 0)
    {
        int is = index_vl[s] - 1;
        for (int u = 0; u < G.n; u++)
        {
            if (index_vl[u] > 0)
            {
                int iu = index_vl[u] - 1;
                rsu[u] = SCInverse(is, is) + SCInverse(iu, iu) - 2 * SCInverse(is, iu);
            }
            else
            {
                int iu = -index_vl[u];
                double item1 = Pu_SCI_Pu[iu];
                double item2 = 0.0;
                for(int i=0;i<vl.size();i++){
                    item2 += 2 * P[iu][i] * SCInverse(i,is);
                }
                // rsu[u] = SCInverse(is, is) + Luuinv[iu] + P.row(iu).dot(SCInverse * P.row(iu).transpose()) - 2 * P.row(iu).dot(SCInverse.col(is));
                rsu[u] = SCInverse(is, is) + Luuinv[iu] + item1 - item2;
            }
        }
    }
    else
    {
        int is = -index_vl[s];
        std::vector<double> qs(G.n,0);
        double currentTime = get_current_time_sec_method();
        for (int i = 0; i < omega; i++)
        {
            int current = s;
            while (!(index_vl[current] > 0))
            {
                qs[current] += 1.0 / omega;
                current = G.choose_neighbor(current);
            }
        }
        cout << "time for rw: " << get_current_time_sec_method()-currentTime << endl;

        // Eigen::VectorXd Ps_SCI = P.row(is) * SCInverse;
        vector<double> Ps_SCI(vl.size(),0.0);
        for(int i=0;i<vl.size();i++){
            for(int j=0;j<vl.size();j++){
                Ps_SCI[i] += P[is][j]*SCInverse(j,i);
            }
        }

        double Ps_SCI_Ps = 0.0;
        for(int i=0;i<vl.size();i++){
            Ps_SCI_Ps += Ps_SCI[i] * P[is][i];
        }


        cout << "time for Ps_SCI and Ps_SCI_Ps: " << get_current_time_sec_method()-currentTime << endl;

        for (int u = 0; u < G.n; u++)
        {
            if (index_vl[u] > 0)
            {
                int iu = index_vl[u] - 1;
                double item1 = Ps_SCI_Ps;
                double item2 = 0.0;
                for(int i=0;i<vl.size();i++){
                    item2 += 2 * P[is][i] * SCInverse(i,iu);
                }
                // rsu[u] = SCInverse(iu, iu) + Luuinv[is] + P.row(is).dot(SCInverse * P.row(is).transpose()) - 2 * P.row(is).dot(SCInverse.col(iu));
                rsu[u] = SCInverse(iu, iu) + Luuinv[is] + item1 - item2;
            }
            else
            {
                int iu = -index_vl[u];
                double item1 = Ps_SCI_Ps;
                double item2 = Pu_SCI_Pu[iu];
                double item3 = 0.0;
                for(int i=0;i<vl.size();i++){
                    item3 += 2 * Ps_SCI[i]*P[iu][i];
                }
                
                // rsu[u] = Luuinv[is] + Luuinv[iu] - 2 * qs[u] / G.g[u].size() + Ps_SCI.transpose() * P.row(is).transpose() + P.row(iu).dot(SCInverse * P.row(iu).transpose()) - 2 * Ps_SCI.dot(P.row(iu).transpose());
                rsu[u] = Luuinv[is] + Luuinv[iu] - 2 * qs[u] / G.g[u].size() + item1 + item2 - item3;
            }
        }
    }

    return rsu;
}

std::vector<double> er_vl_push_singlesource(EdgeGraph &G, int s,
                                            const std::vector<int> &vl, const std::vector<int> &index_vl,
                                            const vector<double> &Luuinv, const vector<vector<double>> &P, const Eigen::MatrixXd &SCInverse, const vector<double> &Pu_SCI_Pu,
                                            double pushrmax)
{
    std::vector<double> rsu(G.n);
    if (index_vl[s] > 0)
    {
        int is = index_vl[s] - 1;
        for (int u = 0; u < G.n; u++)
        {
            if (index_vl[u] > 0)
            {
                int iu = index_vl[u] - 1;
                rsu[u] = SCInverse(is, is) + SCInverse(iu, iu) - 2 * SCInverse(is, iu);
            }
            else
            {
                int iu = -index_vl[u];
                double item1 = Pu_SCI_Pu[iu];
                double item2 = 0.0;
                for(int i=0;i<vl.size();i++){
                    item2 += 2 * P[iu][i] * SCInverse(i,is);
                }
                // rsu[u] = SCInverse(is, is) + Luuinv[iu] + P.row(iu).dot(SCInverse * P.row(iu).transpose()) - 2 * P.row(iu).dot(SCInverse.col(is));
                rsu[u] = SCInverse(is, is) + Luuinv[iu] + item1 - item2;
            }
        }
    }
    else
    {
        int is = -index_vl[s];
        std::vector<double> qs, rs;
        tie(qs, rs) = G.vl_absorbed_push(s, index_vl, pushrmax);

        // Eigen::VectorXd Ps_SCI = P.row(is) * SCInverse;
        vector<double> Ps_SCI(vl.size(),0.0);
        for(int i=0;i<vl.size();i++){
            for(int j=0;j<vl.size();j++){
                Ps_SCI[i] += P[is][j]*SCInverse(j,i);
            }
        }

        double Ps_SCI_Ps = 0.0;
        for(int i=0;i<vl.size();i++){
            Ps_SCI_Ps += Ps_SCI[i] * P[is][i];
        }


        for (int u = 0; u < G.n; u++)
        {
            if (index_vl[u] > 0)
            {
                int iu = index_vl[u] - 1;
                double item1 = Ps_SCI_Ps;
                double item2 = 0.0;
                for(int i=0;i<vl.size();i++){
                    item2 += 2 * P[is][i] * SCInverse(i,iu);
                }
                
                // rsu[u] = SCInverse(iu, iu) + Luuinv[is] + P.row(is).dot(SCInverse * P.row(is).transpose()) - 2 * P.row(is).dot(SCInverse.col(iu));
                rsu[u] = SCInverse(iu, iu) + Luuinv[is] + item1 - item2;
            }
            else
            {
                int iu = -index_vl[u];
                double item1 = Ps_SCI_Ps;
                double item2 = Pu_SCI_Pu[iu];
                double item3 = 0.0;
                for(int i=0;i<vl.size();i++){
                    item3 += 2 * Ps_SCI[i]*P[iu][i];
                }
                
                // rsu[u] = Luuinv[is] + Luuinv[iu] - 2 * qs[u] / G.g[u].size() + Ps_SCI.transpose() * P.row(is).transpose() + P.row(iu).dot(SCInverse * P.row(iu).transpose()) - 2 * Ps_SCI.dot(P.row(iu).transpose());
                if(u==0){
                    cout << "s = " << s << ", calculating rsu[0]:" << endl;
                    cout << "   Luuinv[is] + Luuinv[iu] = " << Luuinv[is] + Luuinv[iu] << endl;
                    cout << "   - 2 * qs[u] / G.g[u].size():" << - 2 * qs[u] / G.g[u].size() << endl;
                    cout << "   Ps_SCI_Ps = " << Ps_SCI_Ps << endl;
                    cout << "   Pu_SCI_Pu[iu] = " << Pu_SCI_Pu[iu] << endl;
                    cout << "   Ps_SCI.dot(P.row(iu).transpose()) = " << item3/2 << endl;
                    cout << "   Ps_SCI_Ps + Pu_SCI_Pu[iu] - 2 * Ps_SCI.dot(P.row(iu).transpose()) = " << item1 + item2 - item3 << endl;
                    cout << "   rsu[0] = " << Luuinv[is] + Luuinv[iu] - 2 * qs[u] / G.g[u].size() + item1 + item2 - item3 << endl;
                }
                rsu[u] = Luuinv[is] + Luuinv[iu] - 2 * qs[u] / G.g[u].size() + item1 + item2 - item3;
            }
        }
    }
    return rsu;
}

// int main(int argc, char **argv)
// {
//     srand(1);
//     EdgeGraph G = read_edgegraph("demo.txt");
//     cout << "EdgeGraph inited" << endl;
//     vector<double> rsu, RV, Luuinv;
//     rsu = er_LEwalk_singlesource(G, 1, 100000);
//     cout << "er_LEwalk_singlesource" << endl;
//     cout << rsu << endl;
//     RV = rsu;
//     rsu = er_AbWalkstar_singlesource(G, 0, 1, 100000, RV);
//     cout << "er_AbWalkstar_singlesource" << endl;
//     cout << rsu << endl;
//     rsu = er_Pushstar_singlesource(G, 0, 1, 1e-4, RV);
//     cout << "er_Pushstar_singlesource" << endl;
//     cout << rsu << endl;
//     vector<int> vl = {1,2};
//     Luuinv = precompute_Luuinv(G, vl, 10000);
//     cout << "precompute_Luuinv" << endl;
//     cout << Luuinv << endl;
//     vector<vector<double>> Pr = prepcompute_Pr(G,vl,100000);
//     Eigen::MatrixXd P = vectorOfVectorsToEigenMatrix(Pr);
//     Eigen::MatrixXd SCInverse = precompute_SchurComplementInverse(G,vl,Pr);
//     rsu = er_SCbased_singlesource(G, 0, vl, Luuinv, P, SCInverse, 1e-5);
//     cout << "er_SCbased_singlesource" << endl;
//     cout << rsu << endl;

//     return 0;
// }