#include <iostream>
#include "Eigen/Dense"
#include <vector>
#include "tools-matrix.h"
#include "EdgeGraph.h"


Eigen::MatrixXd vectorOfVectorsToEigenMatrix(const std::vector<std::vector<double>> &data)
{
    // 获取数据的行数和列数
    int rows = data.size();
    int cols = data[0].size();

    // 创建Eigen::MatrixXd对象，并将数据从std::vector<std::vector<double>>拷贝到其中
    Eigen::MatrixXd matrix(rows, cols);
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            matrix(i, j) = data[i][j];
        }
    }
    return matrix;
}

// 利用Eigen库，采用SVD分解的方法求解矩阵伪逆，默认误差er为0
Eigen::MatrixXd pinv_eigen_based(Eigen::MatrixXd & origin, const float er) {
    Eigen::JacobiSVD<Eigen::MatrixXd> svd_holder(origin,
                                                 Eigen::ComputeThinU |
                                                 Eigen::ComputeThinV);
    Eigen::MatrixXd U = svd_holder.matrixU();
    Eigen::MatrixXd V = svd_holder.matrixV();
    Eigen::MatrixXd D = svd_holder.singularValues();

    // 构建S矩阵
    Eigen::MatrixXd S(V.cols(), U.cols());
    S.setZero();

    for (unsigned int i = 0; i < D.size(); ++i) {
        if (D(i, 0) > er) {
            S(i, i) = 1 / D(i, 0);
        } else {
            S(i, i) = 0;
        }
    }

    // pinv_matrix = V * S * U^T
    return V * S * U.transpose();
}


Eigen::MatrixXd pseudo_inverse(const std::vector<std::vector<double>> &data)
{
    Eigen::MatrixXd matrix = vectorOfVectorsToEigenMatrix(data);
    Eigen::MatrixXd pseudoInv = pinv_eigen_based(matrix,1e-7);
    return pseudoInv;
}

// int main()
// {
//     std::vector<std::vector<double>> data = {{1,2},{3,4}};
//     Eigen::MatrixXd matrix = vectorOfVectorsToEigenMatrix(data);

//     Eigen::MatrixXd pseudoInv = pinv_eigen_based(matrix);
//     std::cout << "Pseudo Inverse:\n" << pseudoInv << std::endl;

//     return 0;
// }
