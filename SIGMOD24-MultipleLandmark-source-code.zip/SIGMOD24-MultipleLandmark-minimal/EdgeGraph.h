#pragma once

#include <vector>
#include <string>
#include <iostream>
#include <ctime>
#include <random>
#include "Eigen/Dense"

using namespace std;

template <typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<T>& vec) {
    os << "[ ";
    for (size_t i = 0; i < vec.size(); ++i) {
        os << vec[i];
        if (i < vec.size() - 1) {
            os << ", ";
        }
    }
    os << " ]";
    return os;
}


class EdgeGraph
{
private:
public:
    typedef double T;
    std::vector<std::vector<int>> g;
    std::vector<std::vector<double>> wts;
    std::vector<double> deg;
    int n;
    int m;
    bool weighted;
    // EdgeGraph();
    // ~EdgeGraph();
    int choose_neighbor(int node);
    pair<vector<double>,vector<double>> v_absorbed_push(int s,int v,double rmax);
    pair<vector<double>,vector<double>> v_absorbed_push(vector<double> s,int v,double rmax);
    pair<std::vector<double>, vector<double>> vl_absorbed_push(int s, const std::vector<int>& in_vl, double rmax);
    vector<int> BFS(int root);
    vector<int> BFS(const vector<int>& roots);
    vector<int> wilson(int r);
    vector<int> wilson(vector<int> rl);
    void show() const {
        std::cout << "EdgeGraph Details:" << std::endl;
        std::cout << "n: " << n << std::endl;
        std::cout << "m: " << m << std::endl;
        std::cout << "weighted: " << (weighted ? "true" : "false") << std::endl;
        if(n < 1000){
            std::cout << "g: " << g << endl;
            std::cout << "wts: " << wts << endl;
            std::cout << "deg: " << deg << endl;
        }
    }
};

int weighted_rand(vector<double> weight,double randNum);
double get_current_time_sec_method();
EdgeGraph read_edgegraph(const std::string& fn, char delimiter = '\t', int skipstart = 0, int beginnode = 1, bool appear_twice = false);
// EdgeGraph read_from_matrix(Eigen::SparseMatrix<double>* GM);


