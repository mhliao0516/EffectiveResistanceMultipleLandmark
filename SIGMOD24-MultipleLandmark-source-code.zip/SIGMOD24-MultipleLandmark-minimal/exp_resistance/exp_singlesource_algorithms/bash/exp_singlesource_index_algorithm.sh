BASE_DIR=./exp_resistance/exp_singlesource_algorithms
BASE_BIN_DIR=$BASE_DIR/bin
BASE_LOG_DIR=$BASE_DIR/logs

if [ ! -d $BASE_LOG_DIR/exp_singlesource_index_algorithm/$1 ]; then
    mkdir -p $BASE_LOG_DIR/exp_singlesource_index_algorithm/$1
fi

nohup $BASE_BIN_DIR/exp_singlesource_index_algorithm $1 $2 degree+ true false false false > $BASE_LOG_DIR/exp_singlesource_index_algorithm/$1/LeWalk.log 2>&1 &
nohup $BASE_BIN_DIR/exp_singlesource_index_algorithm $1 $2 degree+ false true false false > $BASE_LOG_DIR/exp_singlesource_index_algorithm/$1/ST.log 2>&1 &
nohup $BASE_BIN_DIR/exp_singlesource_index_algorithm $1 $2 degree+ false false true false > $BASE_LOG_DIR/exp_singlesource_index_algorithm/$1/v-LeWalk.log 2>&1 &
nohup $BASE_BIN_DIR/exp_singlesource_index_algorithm $1 $2 degree+ false false false true > $BASE_LOG_DIR/exp_singlesource_index_algorithm/$1/v-ST.log 2>&1 &

