#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <sys/time.h>
#include <numeric>
#include <vector>
#include <cmath>
#include <H5Cpp.h>
#include <queue>
#include <random>
#include <filesystem>
#include <map>
#include "Eigen/Dense"

#include "../../EdgeGraph.h"
#include "../../resistance-singlepair.h"
#include "../../resistance-singlesource.h"
#include "../../tools-matrix.h"

using namespace std;
namespace fs = std::filesystem;

string BASE_DIR = "exp_resistance/exp_singlesource_algorithms";
string GROUNDTRUTH_DIR = "exp_resistance/groundTruth";
string VL_DIR = "exp_resistance/vl";

map<string,vector<int>> ssrw_omegas_dict;
map<string,vector<double>> sspush_rmaxs_dict;
map<string,vector<int>> lewalk_omegas_dict;


int argmax(const std::vector<double>& arr){
    int maxIndex = 0; 
    for (int i = 1; i < arr.size(); ++i) {
        if (arr[i] > arr[maxIndex]) {
            maxIndex = i;
        }
    }
    return maxIndex;
}

vector<int> find_k_max_index(const vector<double> &arr,int k){
    struct ElementWithIndex {
        double value;
        int index;

        // 比较运算符，用于堆排序
        bool operator<(const ElementWithIndex& other) const {
            return value > other.value;
        }
    };
    priority_queue<ElementWithIndex> maxHeap;  // 最大堆
    vector<int> topkPositions;

    // 遍历数组，将元素值和索引存储到最大堆中
    for (int i = 0; i < arr.size(); ++i) {
        maxHeap.push({arr[i], i});

        // 如果堆的大小超过 10，弹出堆顶元素
        if (maxHeap.size() > k) {
            maxHeap.pop();
        }
    }

    // 从最大堆中获取前 10 大元素的位置
    while (!maxHeap.empty()) {
        topkPositions.push_back(maxHeap.top().index);
        maxHeap.pop();
    }

    // 对结果进行反转，使其按照原数组的顺序
    reverse(topkPositions.begin(), topkPositions.end());

    return topkPositions;
}

double l2norm(const std::vector<double>& arr){
    double norm = 0.0;
    for(const double &val:arr){
        norm += val * val;
    }
    return sqrt(norm);
}

vector<double> vector_minus(const vector<double> &vec1,const vector<double> &vec2){
    if(!vec1.size()==vec2.size()){
        throw runtime_error("vector dimension cannot match!!");
    }
    vector<double> temp = vec1;
    for(size_t i=0;i<vec1.size();i++){
        temp[i] -= vec2[i];
    }
    return temp;
}

vector<vector<double>> matrix_minus(const vector<vector<double>> &mat1, const vector<vector<double>> &mat2){
    if(!mat1.size()==mat2.size() || !mat1[0].size()==mat2[0].size()){
        throw runtime_error("matrix dimension cannot match!!");
    }
    vector<vector<double>> temp = mat1;
    for(size_t i=0;i<mat1.size();i++){
        for(size_t j=0;j<mat1[0].size();j++){
            temp[i][j] -= mat2[i][j];
        }
    }
    return temp;
}

vector<double> get_column(vector<vector<double>> &mat,int k){
    vector<double> temp = {};
    for(size_t i=0;i<mat.size();i++){
        temp.push_back(mat[i][k]);
    } 
    return temp;
}

vector<double> head_k(vector<double> &vec,int k){
    vector<double> temp = {};
    for(int i=0;i<k;i++){
        temp.push_back(vec[i]);
    }
    return temp;
}

vector<vector<double>> read_exact_p(string filename){
    // 打开 HDF5 文件
    H5::H5File file(filename, H5F_ACC_RDONLY);

    // 打开数据集
    H5::DataSet dataset = file.openDataSet("P");

    // 读取数据集
    H5::DataSpace dataspace = dataset.getSpace();
    hsize_t dims_out[2];
    dataspace.getSimpleExtentDims(dims_out, NULL);
    int rows = dims_out[1];
    int cols = dims_out[0];

    // cout << rows << "  " << cols << endl;

    double* data = new double[rows * cols];
    dataset.read(data, H5::PredType::NATIVE_DOUBLE);

    // 将数据存储为 vector<vector<double>>
    vector<vector<double>> matrix;
    matrix.resize(rows, vector<double>(cols));

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = data[j * rows + i];
        }
    }
    delete[] data;

    return matrix;
}

vector<double> read_exact_Luuinv(string filename){
    // 打开 HDF5 文件
    H5::H5File file(filename, H5F_ACC_RDONLY);

    // 打开数据集
    H5::DataSet dataset = file.openDataSet("Luuinv");

    // 读取数据集
    H5::DataSpace dataspace = dataset.getSpace();
    hsize_t dims[1];
    dataspace.getSimpleExtentDims(dims, NULL);

    vector<double> data(dims[0]);
    dataset.read(&data[0], H5::PredType::NATIVE_DOUBLE);

    return data;
}



vector<int> read_vlseq_top_k(string filename,int k){
    vector<int> vl = {};
    ifstream file(filename);
    string line;
    for(int i=0;i<k;i++){
        getline(file,line);
        vl.push_back(stoi(line)-1);
    }
    file.close();
    return vl;
}

vector<int> generate_index_vl(int n,vector<int> vl){
    vector<int> index_vl(n,0);
    for(int i=1;i<=vl.size();i++){
        index_vl[vl[i-1]] = i;
    }
    int u_ind = 0;
    for(int i=0;i<n;i++){
        if(index_vl[i]==0){
            index_vl[i] = u_ind;
            u_ind -= 1;
        }
    }
    return index_vl;
}

pair<vector<int>,vector<vector<double>>> read_exact_singlesource(string exact_singlesource_dir,int maxNum=100){
    cout << "read from " << exact_singlesource_dir << endl;
    vector<int> vnodes= {};
    vector<vector<double>> vers = {};
    int cnt = 0;
    for(const auto &entry : fs::directory_iterator(exact_singlesource_dir)){
        if(fs::is_regular_file(entry.path())){
            if(cnt < maxNum) cnt++;
            else break;
            string nodestr = entry.path().stem();
            int node = stoi(nodestr);
            vnodes.push_back(node);
            vector<double> ss_er = {};
            ifstream f(exact_singlesource_dir+"/"+nodestr+".txt");
            string line;
            while(getline(f,line)){
                ss_er.push_back(stod(line));
            }
            f.close();
            // cout << setprecision(16) << ss_er << endl;
            vers.push_back(ss_er);
        }
    }
    return make_pair(vnodes,vers);
}

vector<double> generate_Pu_SCI_Pu(vector<vector<double>> exact_p, Eigen::MatrixXd SCInverse){
    int nk = exact_p[0].size();
    int nu = exact_p.size();
    vector<double> Pu_SCI_Pu(nu,0.0);
    for(int u=0;u<nu;u++){
        for(int i=0;i<nk;i++){
            for(int j=0;j<nk;j++){
                Pu_SCI_Pu[u] += exact_p[u][i]*SCInverse(i,j)*exact_p[u][j];
            } 
        }
    }
    return Pu_SCI_Pu;
}

void write_Luuinv_cache(string dataset,int omega,vector<double> Luuinv){
    string cache_dir = BASE_DIR + "/cache/" + dataset;
    if (!fs::is_directory(cache_dir)) {
        if (fs::create_directory(cache_dir)) {
            std::cout << "Directory created: " << cache_dir << std::endl;
        }
    }
    string cache_filename = cache_dir + "/Luuinv_" + to_string(omega) + ".txt";
    ofstream resultf(cache_filename);
    for(auto val:Luuinv){
        resultf << setprecision(16) << val << endl;
    }
    cout << "omega: " << omega << ", written cache to " << cache_filename << endl;
}

vector<double> read_Luuinv_cache(string cache_filename){
    vector<double> Luuinv = {};
    ifstream f(cache_filename);
    string line;
    while(getline(f,line)){
        Luuinv.push_back(stod(line));
    }
    cout << "read from " << cache_filename << endl;
    return Luuinv;
}

void write_RV_cache(string dataset,int omega,vector<double> RV){
    string cache_dir = BASE_DIR + "/cache/" + dataset;
    if (!fs::is_directory(cache_dir)) {
        if (fs::create_directory(cache_dir)) {
            std::cout << "Directory created: " << cache_dir << std::endl;
        }
    }
    string cache_filename = cache_dir + "/RV" + to_string(omega) + ".txt";
    ofstream resultf(cache_filename);
    for(auto val:RV){
        resultf << setprecision(16) << val << endl;
    }
    cout << "omega: " << omega << ", written cache to " << cache_filename << endl;
}

vector<double> read_RV_cache(string cache_filename){
    vector<double> RV = {};
    ifstream f(cache_filename);
    string line;
    while(getline(f,line)){
        RV.push_back(stod(line));
    }
    cout << "read from " << cache_filename << endl;
    return RV;
}

void write_Pu_SCI_Pu_cache(string dataset,vector<double> Pu_SCI_Pu){
    string cache_dir = BASE_DIR + "/cache/" + dataset;
    if (!fs::is_directory(cache_dir)) {
        if (fs::create_directory(cache_dir)) {
            std::cout << "Directory created: " << cache_dir << std::endl;
        }
    }
    string cache_filename = cache_dir + "/Pu_SCI_Pu" + ".txt";
    ofstream resultf(cache_filename);
    for(auto val:Pu_SCI_Pu){
        resultf << setprecision(16) << val << endl;
    }
    cout << "written cache to " << cache_filename << endl;
}

vector<double> read_Pu_SCI_Pu_cache(string cache_filename){
    vector<double> Pu_SCI_Pu = {};
    ifstream f(cache_filename);
    string line;
    while(getline(f,line)){
        Pu_SCI_Pu.push_back(stod(line));
    }
    cout << "read from " << cache_filename << endl;
    return Pu_SCI_Pu;
}


void exp_singlesource_algorithms(EdgeGraph &G,string dataset,int selectNum,string vl_strategy,  bool ssrw,bool sspush,bool v_ssrw,bool v_sspush){

    string exact_singlesource_dir = GROUNDTRUTH_DIR + "/exact_singlesource/" + dataset;
    cout << "exact_singlesource_dir: " << exact_singlesource_dir << endl;; 
    string exact_p_dir = GROUNDTRUTH_DIR + "/exact_p/" + vl_strategy + "/" + dataset;
    cout << "exact_p_dir: " << exact_p_dir << endl;
    // string exact_Luuinv_dir = GROUNDTRUTH_DIR + "/exact_Luuinv/" + vl_strategy + "/" + dataset;
    // cout << "exact_Luuinv_dir: " << exact_Luuinv_dir << endl;
    string vlseq_path = VL_DIR + "/" + vl_strategy + "/" + dataset +"/vlseq.txt";
    cout << "vlseq_path: " << vlseq_path << endl;
    string output_dir = BASE_DIR + "/results/exp_singlesource_algorithm/" + dataset;
    cout << "output_dir: " << output_dir << endl;

    if (!fs::is_directory(output_dir)) {
        if (fs::create_directory(output_dir)) {
            std::cout << "Directory created: " << output_dir << std::endl;
        }
    }

    vector<int> vl = read_vlseq_top_k(vlseq_path,selectNum);
    cout << "loaded vl, length: " << vl.size() << endl;
    vector<int> index_vl = generate_index_vl(G.n,vl);
    int v = vl[0];

    pair<vector<int>,vector<vector<double>>> EXT = read_exact_singlesource(exact_singlesource_dir,10);
    vector<int> vnodes = EXT.first;
    vector<vector<double>> vers = EXT.second;
    cout << "loaded exact singlesource, size:" << vnodes.size() << endl;

    vector<vector<double>> exact_p = read_exact_p(exact_p_dir+"/"+to_string(selectNum)+".jld2");
    cout << "loaded exact_p, row= " << exact_p.size() << ", cols= " << exact_p[0].size() <<endl;
    Eigen::MatrixXd SCInverse = precompute_SchurComplementInverse(G, vl,index_vl, exact_p);
    cout << "precomputed SCInverse, row= " << SCInverse.rows() << ", cols= " << SCInverse.cols() <<endl;
    vector<vector<double>> Index = combine_P_SCInverse(exact_p,SCInverse,index_vl);
    double starttime = get_current_time_sec_method();

    vector<double> Pu_SCI_Pu;
    string Pu_SCI_Pu_cache_filename = BASE_DIR + "/cache/" + dataset + "/Pu_SCI_Pu"+ ".txt";
    if(fs::exists(Pu_SCI_Pu_cache_filename)){
        Pu_SCI_Pu = read_Pu_SCI_Pu_cache(Pu_SCI_Pu_cache_filename);
    } else{
        cout << "start computing Pu_SCI_Pu "<< endl;
        Pu_SCI_Pu = generate_Pu_SCI_Pu(exact_p,SCInverse);
        cout << "time for computing Pu_SCI_Pu: " << get_current_time_sec_method() - starttime << "s." << endl;
        write_Pu_SCI_Pu_cache(dataset,Pu_SCI_Pu);
    }


    // vector<double> exact_Luuinv = read_exact_Luuinv(exact_Luuinv_dir+"/"+to_string(selectNum)+".jld2");
    // cout << "loaded exact_Luuinv, row= " << exact_Luuinv.size() << endl;
    // vector<double> RV = read_exact_Luuinv(exact_Luuinv_dir+"/"+to_string(1)+".jld2");
    // RV.emplace(RV.begin()+v,0.0);

    cout << " we are not using exact_Luuinv or RV!" << endl;
    vector<vector<double>> Luuinv_vector = {};
    vector<vector<double>> RV_vector = {};
    for(int omega:lewalk_omegas_dict[dataset]){
        vector<double> Luuinv,RV;
        string Luuinv_cache_filename = BASE_DIR + "/cache/" + dataset + "/Luuinv_" + to_string(omega) + ".txt";
        cout << "Luuinv_cache_filename: " << Luuinv_cache_filename << endl;
        if(fs::exists(Luuinv_cache_filename)){
            Luuinv = read_Luuinv_cache(Luuinv_cache_filename);
        } else{
            cout << "start computing Luuinv, omega: " << omega << endl;
            Luuinv = precompute_Luuinv(G,vl,index_vl,omega);
            write_Luuinv_cache(dataset,omega,Luuinv);
        }
        Luuinv_vector.push_back(Luuinv);

        if(dataset[0]=='r') omega = omega * 2;
        string RV_cache_filename = BASE_DIR + "/cache/" + dataset + "/RV" + to_string(omega) + ".txt";
        cout << "RV_cache_filename: " << RV_cache_filename << endl; 
        if(fs::exists(RV_cache_filename)){
            RV = read_RV_cache(RV_cache_filename);
        } else{
            cout << "start computing RV, omega: " << omega << endl;
            RV = er_LEwalk_singlesource(G,v,omega);
            write_RV_cache(dataset,omega,RV);
        }
        RV_vector.push_back(RV);

    }

    cout << "-----------------" << endl;
    cout << "Index precomputed" << endl;
    cout << "-----------------" << endl;

    std::ostringstream buffer;

    if(ssrw){
        vector<int> omegas = ssrw_omegas_dict[dataset];

        string output_filename = output_dir + "/" + "ssrw.txt";

        for(int pind=0;pind<omegas.size();pind++){
            int omega = omegas[pind];
            vector<double> Luuinv = Luuinv_vector[pind];

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i];
                vector<double> er_true = vers[i];
                cout << s << endl;
                double start_time = get_current_time_sec_method();
                vector<double> er_hat = er_vl_rw_singlesource(G,s,vl,index_vl,Luuinv,exact_p,SCInverse,Pu_SCI_Pu,omega);
                double elapsed_time = get_current_time_sec_method()-start_time;

                vector<double> err = vector_minus(er_true,er_hat);
                cout << "er_true: " << head_k(er_true,10) << "......" << endl;
                cout << "er_hat: " << head_k(er_hat,10) << "......" << endl;
                cout << "err: " << head_k(err,10) << "......" << endl;
                double y1 = l2norm(err)/l2norm(er_true);
                double y2 = l2norm(err);
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(y2);
                cout << s << ","  << omega << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(sspush){
        vector<double> rmaxs = sspush_rmaxs_dict[dataset];

        string output_filename = output_dir + "/" + "sspush.txt";

        for(int pind=0;pind<rmaxs.size();pind++){
            double rmax = rmaxs[pind];
            vector<double> Luuinv = Luuinv_vector[pind];

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i];
                vector<double> er_true = vers[i];
                cout << s << endl;
                double start_time = get_current_time_sec_method();
                vector<double> er_hat = er_vl_push_singlesource(G,s,vl,index_vl,Luuinv,exact_p,SCInverse,Pu_SCI_Pu,rmax);
                double elapsed_time = get_current_time_sec_method()-start_time;

                vector<double> err = vector_minus(er_true,er_hat);
                cout << "er_true: " << head_k(er_true,10) << "......" << endl;
                cout << "er_hat: " << head_k(er_hat,10) << "......" << endl;
                cout << "err: " << head_k(err,10) << "......" << endl;
                double y1 = l2norm(err)/l2norm(er_true);
                double y2 = l2norm(err);
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(y2);
                cout << s << ","  << rmax << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(v_ssrw){
        vector<int> omegas = ssrw_omegas_dict[dataset];

        string output_filename = output_dir + "/" + "v-ssrw.txt";

        for(int pind=0;pind<omegas.size();pind++){
            double omega = omegas[pind];
            vector<double> RV = RV_vector[pind];

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i];
                vector<double> er_true = vers[i];
                cout << s << endl;
                double start_time = get_current_time_sec_method();
                vector<double> er_hat = er_AbWalkstar_singlesource(G,s,v,omega,RV);
                double elapsed_time = get_current_time_sec_method()-start_time;

                vector<double> err = vector_minus(er_true,er_hat);
                cout << "er_true: " << head_k(er_true,10) << "......" << endl;
                cout << "er_hat: " << head_k(er_hat,10) << "......" << endl;
                cout << "err: " << head_k(err,10) << "......" << endl;
                double y1 = l2norm(err)/l2norm(er_true);
                double y2 = l2norm(err);
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(y2);
                cout << s << ","  << omega << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(v_sspush){
        vector<double> rmaxs = sspush_rmaxs_dict[dataset];

        string output_filename = output_dir + "/" + "v-sspush.txt";

        for(int pind=0;pind<rmaxs.size();pind++){
            double rmax = rmaxs[pind];
            vector<double> RV = RV_vector[pind];
            vector<double> exact_RV = read_exact_Luuinv(GROUNDTRUTH_DIR + "/exact_Luuinv/" + vl_strategy + "/" + dataset + "/1" + ".jld2");
            exact_RV.emplace(exact_RV.begin()+v,0.0);
            cout << "evaluating RV with exact_RV: " << endl;
            cout << "   v: " << v << endl;
            cout << "   RV[v]: " << RV[v] << endl;
            cout << "   exact_RV: " << head_k(exact_RV,10) << "......" << endl;
            cout << "   RV: " << head_k(RV,10) << "......" << endl;
            cout << "   rerr: " << l2norm(vector_minus(exact_RV,RV))/l2norm(exact_RV) << endl;


            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i];
                vector<double> er_true = vers[i];
                cout << s << endl;
                double start_time = get_current_time_sec_method();
                vector<double> er_hat = er_Pushstar_singlesource(G,s,v,rmax,RV);
                double elapsed_time = get_current_time_sec_method()-start_time;

                vector<double> err = vector_minus(er_true,er_hat);
                cout << "er_true: " << head_k(er_true,10) << "......" << endl;
                cout << "er_hat: " << head_k(er_hat,10) << "......" << endl;
                cout << "err: " << head_k(err,10) << "......" << endl;
                double y1 = l2norm(err)/l2norm(er_true);
                double y2 = l2norm(err);
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(y2);
                cout << s << ","  << rmax << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }
}


int main(int argc,char** argv){
    srand(time(0));

    string dataset = argv[1];
    int selectNum = atoi(argv[2]);
    string vl_strategy = argv[3];

    vector<bool> params = {};
    string param;
    for (int i = 4; i < argc; ++i) {
        param = argv[i];
        if(param == "true"){
            params.push_back(true);
        } else if (param == "false"){
            params.push_back(false);
        } else{
            cout << "invalid param:" << param << endl;
        }
    }

    int skipstart=0;
    int beginnode = 1;
    bool appear_twice=true;
    if(dataset == "astro-ph" || dataset == "email-enron"){
        skipstart=0;appear_twice=true;beginnode = 0;
    } else if(dataset == "youtube" || dataset == "pokec" || dataset == "orkut"){
        skipstart=1;appear_twice=false;beginnode = 0;
    } else if(dataset.back() == '1'){
        skipstart=0;appear_twice=true;beginnode = 1;
    } else if(dataset == "road-powergrid"){
        skipstart=0;appear_twice=false;beginnode = 1;
    } else{
        throw "unknown dataset!!";
    }
    
    string filename = "datasets/"+dataset+".txt";
    cout << filename << endl;
    EdgeGraph G = read_edgegraph(filename,'\t',skipstart,beginnode,appear_twice);

    ssrw_omegas_dict["email-enron"] = {100,1000,10000,100000,1000000};
    sspush_rmaxs_dict["email-enron"] = {1e-3,3e-4,1e-4,1e-5,1e-6};
    lewalk_omegas_dict["email-enron"] = {400,1000,2000,5000,10000};

    ssrw_omegas_dict["road-powergrid"] = {100,1000,10000,100000,1000000};
    sspush_rmaxs_dict["road-powergrid"] = {1e-2,1e-3,3e-4,1e-4,1e-5};
    lewalk_omegas_dict["road-powergrid"] = {400,1000,2000,5000,10000};

    ssrw_omegas_dict["orkut"] = {100,1000,10000,100000};
    sspush_rmaxs_dict["orkut"] = {1e-7,3e-8,2e-8,1e-8};
    lewalk_omegas_dict["orkut"] = {10,50,250,1250};

    ssrw_omegas_dict["road-CA1"] = {100,1000,10000,100000};
    sspush_rmaxs_dict["road-CA1"] = {1e-4,1e-5,3e-6,1e-6};
    lewalk_omegas_dict["road-CA1"] = {10,50,250,1250};

    ssrw_omegas_dict["road-PA1"] = {100,1000,10000,100000};
    sspush_rmaxs_dict["road-PA1"] = {1e-4,1e-5,3e-6,1e-6};
    lewalk_omegas_dict["road-PA1"] = {10,50,250,1250};
    
    exp_singlesource_algorithms(G,dataset,selectNum,vl_strategy, params[0],params[1],params[2],params[3]);

    return 0;
}


