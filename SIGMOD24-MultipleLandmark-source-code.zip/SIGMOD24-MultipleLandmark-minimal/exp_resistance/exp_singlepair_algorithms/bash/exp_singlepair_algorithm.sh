BASE_DIR=./exp_resistance/exp_singlepair_algorithms
BASE_BIN_DIR=$BASE_DIR/bin
BASE_LOG_DIR=$BASE_DIR/logs

if [ ! -d $BASE_LOG_DIR/exp_singlepair_algorithm/$1 ]; then
    mkdir -p $BASE_LOG_DIR/exp_singlepair_algorithm/$1
fi

nohup $BASE_BIN_DIR/exp_singlepair_algorithm $1 $2 degree+ true false false false false false false > $BASE_LOG_DIR/exp_singlepair_algorithm/$1/rw.log 2>&1 &
nohup $BASE_BIN_DIR/exp_singlepair_algorithm $1 $2 degree+ false true false false false false false > $BASE_LOG_DIR/exp_singlepair_algorithm/$1/vl-rw.log 2>&1 &
nohup $BASE_BIN_DIR/exp_singlepair_algorithm $1 $2 degree+ false false true false false false false > $BASE_LOG_DIR/exp_singlepair_algorithm/$1/push.log 2>&1 &
nohup $BASE_BIN_DIR/exp_singlepair_algorithm $1 $2 degree+ false false false true false false false > $BASE_LOG_DIR/exp_singlepair_algorithm/$1/vl-push.log 2>&1 &
nohup $BASE_BIN_DIR/exp_singlepair_algorithm $1 $2 degree+ false false false false true false false > $BASE_LOG_DIR/exp_singlepair_algorithm/$1/bipush.log 2>&1 &
nohup $BASE_BIN_DIR/exp_singlepair_algorithm $1 $2 degree+ false false false false false true false > $BASE_LOG_DIR/exp_singlepair_algorithm/$1/vl-bipush.log 2>&1 &
nohup $BASE_BIN_DIR/exp_singlepair_algorithm $1 $2 degree+ false false false false false false true > $BASE_LOG_DIR/exp_singlepair_algorithm/$1/p-trun.log 2>&1 &

