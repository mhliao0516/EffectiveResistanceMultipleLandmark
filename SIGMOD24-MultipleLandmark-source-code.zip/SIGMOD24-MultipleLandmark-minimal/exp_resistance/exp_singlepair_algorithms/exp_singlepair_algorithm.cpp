#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <sys/time.h>
#include <numeric>
#include <vector>
#include <cmath>
#include <H5Cpp.h>
#include <queue>
#include <random>
#include <filesystem>
#include <map>
#include "Eigen/Dense"

#include "../../EdgeGraph.h"
#include "../../resistance-singlepair.h"

using namespace std;
namespace fs = std::filesystem;

string BASE_DIR = "exp_resistance/exp_singlepair_algorithms";
extern string GROUNDTRUTH_DIR = "exp_resistance/groundTruth";
extern string VL_DIR = "exp_resistance/vl";

map<string,vector<int>> rw_omegas_dict;
map<string,vector<int>> vl_rw_omegas_dict;
map<string,vector<double>> push_rmaxs_dict;
map<string,vector<double>> vl_push_rmaxs_dict;
map<string,vector<pair<double,int>>> bipush_rmaxs_dict;
map<string,vector<pair<double,int>>> vl_bipush_rmaxs_dict;
map<string,vector<pair<int,int>>> p_trun_omegas_dict;


int argmax(const std::vector<double>& arr){
    int maxIndex = 0; 
    for (int i = 1; i < arr.size(); ++i) {
        if (arr[i] > arr[maxIndex]) {
            maxIndex = i;
        }
    }
    return maxIndex;
}

vector<int> find_k_max_index(const vector<double> &arr,int k){
    struct ElementWithIndex {
        double value;
        int index;

        // 比较运算符，用于堆排序
        bool operator<(const ElementWithIndex& other) const {
            return value > other.value;
        }
    };
    priority_queue<ElementWithIndex> maxHeap;  // 最大堆
    vector<int> topkPositions;

    // 遍历数组，将元素值和索引存储到最大堆中
    for (int i = 0; i < arr.size(); ++i) {
        maxHeap.push({arr[i], i});

        // 如果堆的大小超过 10，弹出堆顶元素
        if (maxHeap.size() > k) {
            maxHeap.pop();
        }
    }

    // 从最大堆中获取前 10 大元素的位置
    while (!maxHeap.empty()) {
        topkPositions.push_back(maxHeap.top().index);
        maxHeap.pop();
    }

    // 对结果进行反转，使其按照原数组的顺序
    reverse(topkPositions.begin(), topkPositions.end());

    return topkPositions;
}

double l2norm(const std::vector<double>& arr){
    double norm = 0.0;
    for(const double &val:arr){
        norm += val * val;
    }
    return sqrt(norm);
}

vector<vector<double>> read_exact_p(string filename){
    // 打开 HDF5 文件
    H5::H5File file(filename, H5F_ACC_RDONLY);

    // 打开数据集
    H5::DataSet dataset = file.openDataSet("P");

    // 读取数据集
    H5::DataSpace dataspace = dataset.getSpace();
    hsize_t dims_out[2];
    dataspace.getSimpleExtentDims(dims_out, NULL);
    int rows = dims_out[1];
    int cols = dims_out[0];

    // cout << rows << "  " << cols << endl;

    double* data = new double[rows * cols];
    dataset.read(data, H5::PredType::NATIVE_DOUBLE);

    // 将数据存储为 vector<vector<double>>
    vector<vector<double>> matrix;
    matrix.resize(rows, vector<double>(cols));

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = data[j * rows + i];
        }
    }
    delete[] data;

    return matrix;
}

pair<vector<pair<int,int>>,vector<double>> read_exact_singlepair(string exact_singlepair_dir){
    cout << "read from " << exact_singlepair_dir << endl;
    vector<pair<int,int>> vnodes= {};
    vector<double> vers = {};
    for(const auto &entry : fs::directory_iterator(exact_singlepair_dir)){
        if(fs::is_regular_file(entry.path())){
            string pairstr = entry.path().stem();
            size_t l = pairstr.length();
            size_t commaPos = pairstr.find(",");
            string firstNodestr = pairstr.substr(1,commaPos-1);
            string secondNodestr = pairstr.substr(commaPos+1,l-commaPos-2);
            int firstNode = stoi(firstNodestr);
            int secondNode = stoi(secondNodestr);
            vnodes.push_back(make_pair(firstNode,secondNode));
            ifstream f(exact_singlepair_dir+"/"+pairstr+".txt");
            string line;
            getline(f,line);
            f.close();
            double er = stod(line);
            // cout << setprecision(16) << er << endl;
            vers.push_back(er);
        }
    }
    return make_pair(vnodes,vers);
}

vector<int> read_vlseq_top_k(string filename,int k){
    vector<int> vl = {};
    ifstream file(filename);
    string line;
    for(int i=0;i<k;i++){
        getline(file,line);
        vl.push_back(stoi(line)-1);
    }
    file.close();
    return vl;
}

vector<int> generate_index_vl(int n,vector<int> vl){
    vector<int> index_vl(n,0);
    for(int i=1;i<=vl.size();i++){
        index_vl[vl[i-1]] = i;
    }
    int u_ind = 0;
    for(int i=0;i<n;i++){
        if(index_vl[i]==0){
            index_vl[i] = u_ind;
            u_ind -= 1;
        }
    }
    return index_vl;
}

void exp_singlepair_algorithms(EdgeGraph &G,string dataset,int selectNum,string vl_strategy,  bool rw,bool vl_rw,bool push,bool vl_push,bool bipush,bool vl_bipush,bool p_trun){

    string exact_singlepair_dir = GROUNDTRUTH_DIR + "/exact_singlepair/" + dataset;
    cout << "exact_singlepair_dir: " << exact_singlepair_dir << endl;
    string exact_p_dir = GROUNDTRUTH_DIR + "/exact_p/" + vl_strategy + "/" + dataset;
    cout << "exact_p_dir: " << exact_p_dir << endl;
    string vlseq_path = VL_DIR + "/" + vl_strategy + "/" + dataset +"/vlseq.txt";
    cout << "vlseq_path: " << vlseq_path << endl;
    string output_dir = BASE_DIR + "/results/exp_singlepair_algorithm/" + dataset;
    cout << "output_dir: " << output_dir << endl;

    if (!fs::is_directory(output_dir)) {
        if (fs::create_directory(output_dir)) {
            std::cout << "Directory created: " << output_dir << std::endl;
        }
    }

    vector<int> vl = read_vlseq_top_k(vlseq_path,selectNum);
    cout << "loaded vl, length: " << vl.size() << endl;
    vector<int> index_vl = generate_index_vl(G.n,vl);
    int v = vl[0];

    pair<vector<pair<int,int>>,vector<double>> EXT = read_exact_singlepair(exact_singlepair_dir);
    vector<pair<int,int>> vnodes = EXT.first;
    vector<double>vers = EXT.second;
    cout << "loaded exact singlepair, size:" << vnodes.size() << endl;

    vector<vector<double>> exact_p = read_exact_p(exact_p_dir+"/"+to_string(selectNum)+".jld2");
    cout << "loaded exact_p, row= " << exact_p.size() << ", cols= " << exact_p[0].size() <<endl;
    Eigen::MatrixXd SCInverse = precompute_SchurComplementInverse(G, vl,index_vl, exact_p);
    cout << "precomputed SCInverse, row= " << SCInverse.rows() << ", cols= " << SCInverse.cols() <<endl;
    vector<vector<double>> Index = combine_P_SCInverse(exact_p,SCInverse,index_vl);

    std::ostringstream buffer;

    if(rw){
        vector<int> omegas = rw_omegas_dict[dataset];

        string output_filename = output_dir + "/" + "rw.txt";

        for(auto omega:omegas){

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i].first;
                int t = vnodes[i].second;
                double er_true = vers[i];
                cout << s << " " << t << endl;
                double start_time = get_current_time_sec_method();
                double er_hat = er_AbWalk(G,s,t,v,omega);
                double elapsed_time = get_current_time_sec_method()-start_time;
                double y1 = abs(er_hat-er_true)/er_true;
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(abs(er_hat-er_true));
                cout << s << "," << t << "," << omega << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(vl_rw){
        vector<int> omegas = vl_rw_omegas_dict[dataset];

        string output_filename = output_dir + "/" + "vl_rw.txt";

        for(auto omega:omegas){

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i].first;
                int t = vnodes[i].second;
                double er_true = vers[i];
                cout << s << " " << t << endl;
                double start_time = get_current_time_sec_method();
                double er_hat = er_vl_rw(G,s,t,selectNum,index_vl,Index,SCInverse,omega);
                double elapsed_time = get_current_time_sec_method()-start_time;
                double y1 = abs(er_hat-er_true)/er_true;
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(abs(er_hat-er_true));
                cout << s << "," << t << "," << omega << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(push){
        vector<double> rmaxs = push_rmaxs_dict[dataset];

        string output_filename = output_dir + "/" + "push.txt";

        for(auto rmax:rmaxs){

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i].first;
                int t = vnodes[i].second;
                double er_true = vers[i];
                cout << s << " " << t << endl;
                double start_time = get_current_time_sec_method();
                double er_hat = er_Push(G,s,t,v,rmax);
                double elapsed_time = get_current_time_sec_method()-start_time;
                double y1 = abs(er_hat-er_true)/er_true;
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(abs(er_hat-er_true));
                cout << s << "," << t << "," << rmax << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(vl_push){
        vector<double> rmaxs = vl_push_rmaxs_dict[dataset];

        string output_filename = output_dir + "/" + "vl_push.txt";

        for(auto rmax:rmaxs){

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i].first;
                int t = vnodes[i].second;
                double er_true = vers[i];
                cout << s << " " << t << endl;
                double start_time = get_current_time_sec_method();
                double er_hat = er_vl_push(G,s,t,selectNum,index_vl,Index,SCInverse,rmax);
                double elapsed_time = get_current_time_sec_method()-start_time;
                double y1 = abs(er_hat-er_true)/er_true;
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(abs(er_hat-er_true));
                cout << s << "," << t << "," << rmax << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(bipush){
        vector<pair<double,int>> params = bipush_rmaxs_dict[dataset];

        string output_filename = output_dir + "/" + "bipush.txt";

        for(auto param:params){

            double rmax = param.first;
            int omega = param.second;

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i].first;
                int t = vnodes[i].second;
                double er_true = vers[i];
                cout << s << " " << t << endl;
                double start_time = get_current_time_sec_method();
                double er_hat = er_Bipush(G,s,t,v,rmax,omega);
                double elapsed_time = get_current_time_sec_method()-start_time;
                double y1 = abs(er_hat-er_true)/er_true;
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(abs(er_hat-er_true));
                cout << s << "," << t << "," << rmax << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(vl_bipush){
        vector<pair<double,int>> params = vl_bipush_rmaxs_dict[dataset];

        string output_filename = output_dir + "/" + "vl_bipush.txt";

        for(auto param:params){

            double rmax = param.first;
            int omega = param.second;

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i].first;
                int t = vnodes[i].second;
                double er_true = vers[i];
                cout << s << " " << t << endl;
                double start_time = get_current_time_sec_method();
                double er_hat = er_vl_bipush(G,s,t,selectNum,index_vl,Index,SCInverse,rmax,omega);
                double elapsed_time = get_current_time_sec_method()-start_time;
                double y1 = abs(er_hat-er_true)/er_true;
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(abs(er_hat-er_true));
                cout << s << "," << t << "," << rmax << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }
        
        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }

    if(p_trun){
        vector<pair<int,int>> params = p_trun_omegas_dict[dataset];

        string output_filename = output_dir + "/" + "p_trun.txt";

        for(auto param:params){
            int p = param.first;
            int omega = param.second;

            vector<double> ts = {};
            vector<double> y1s = {};
            vector<double> y2s = {};

            for(size_t i=0;i<vnodes.size();i++){
                int s = vnodes[i].first;
                int t = vnodes[i].second;
                double er_true = vers[i];
                cout << s << " " << t << endl;
                double start_time = get_current_time_sec_method();
                double er_hat = er_p_trun(G,s,t,p,omega);
                double elapsed_time = get_current_time_sec_method()-start_time;
                double y1 = abs(er_hat-er_true)/er_true;
                ts.push_back(elapsed_time);
                y1s.push_back(y1);
                y2s.push_back(abs(er_hat-er_true));
                cout << s << "," << t << "," << p << "," << omega << " elapsed_time:" << elapsed_time << " y1:" << y1 << endl;
            }
            double avg_t = accumulate(ts.begin(),ts.end(),0.0)/ts.size();
            double avg_y1 = accumulate(y1s.begin(),y1s.end(),0.0)/ts.size();
            double avg_y2 = accumulate(y2s.begin(),y2s.end(),0.0)/ts.size();
            buffer << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
            cout << setprecision(16) << avg_t << "\t" << avg_y1 << "\t" << avg_y2 << endl;
        }

        ofstream resultf(output_filename);
        resultf << buffer.str();
        buffer.str("");
        cout << "written to " << output_filename << endl;
    }
}


int main(int argc,char** argv){
    srand(time(0));

    string dataset = argv[1];
    int selectNum = atoi(argv[2]);
    string vl_strategy = argv[3];

    vector<bool> params = {};
    string param;
    for (int i = 4; i < argc; ++i) {
        param = argv[i];
        if(param == "true"){
            params.push_back(true);
        } else if (param == "false"){
            params.push_back(false);
        } else{
            cout << "invalid param:" << param << endl;
        }
    }

    int skipstart=0;
    int beginnode = 1;
    bool appear_twice=true;
    if(dataset == "astro-ph" || dataset == "email-enron"){
        skipstart=0;appear_twice=true;beginnode = 0;
    } else if(dataset == "youtube" || dataset == "pokec" || dataset == "orkut"){
        skipstart=1;appear_twice=false;beginnode = 0;
    } else if(dataset.back() == '1'){
        skipstart=0;appear_twice=true;beginnode = 1;
    } else if(dataset == "road-powergrid"){
        skipstart=0;appear_twice=false;beginnode = 1;
    } else{
        throw "unknown dataset!!";
    }
    
    string filename = "datasets/"+dataset+".txt";
    cout << filename << endl;
    EdgeGraph G = read_edgegraph(filename,'\t',skipstart,beginnode,appear_twice);

    rw_omegas_dict["email-enron"] = {80,400,2000,10000};
    vl_rw_omegas_dict["email-enron"] = {80,400,2000,10000};
    push_rmaxs_dict["email-enron"] = {3e-2,3e-3,3e-4,3e-5,1e-6};
    vl_push_rmaxs_dict["email-enron"] = {3e-2,3e-3,3e-4,3e-5,1e-6};
    bipush_rmaxs_dict["email-enron"] = { {3e-2,10},{1e-3,100},{1e-4,500},{1e-5,1000},{1e-6,1000} };
    vl_bipush_rmaxs_dict["email-enron"] = { {3e-2,10},{1e-3,100},{1e-4,500},{1e-5,1000},{1e-6,1000} };
    p_trun_omegas_dict["email-enron"] = { {500,100},{500,200},{500,1000},{500,2000},{500,5000} };

    rw_omegas_dict["road-powergrid"] = {80,400,2000,10000};
    vl_rw_omegas_dict["road-powergrid"] = {80,400,2000,10000};
    push_rmaxs_dict["road-powergrid"] = {3e-2,3e-3,3e-4,3e-5};
    vl_push_rmaxs_dict["road-powergrid"] = {3e-2,3e-3,3e-4,3e-5};
    bipush_rmaxs_dict["road-powergrid"] = { {1e-2,10},{1e-3,20},{1e-3,50},{1e-4,100},{1e-4,200} };
    vl_bipush_rmaxs_dict["road-powergrid"] = {{1e-2,50},{1e-3,100},{1e-3,250},{1e-4,500},{1e-4,1000}};
    p_trun_omegas_dict["road-powergrid"] = { {5000,100},{5000,200},{5000,1000},{5000,2000},{5000,5000}};

    rw_omegas_dict["orkut"] = {10,100,1000,10000,100000};
    vl_rw_omegas_dict["orkut"] = {100,1000,10000,100000,1000000};
    push_rmaxs_dict["orkut"] = {1e-3,1e-4,1e-5,1e-6,1e-7};
    vl_push_rmaxs_dict["orkut"] = {1e-3,1e-4,1e-5,1e-6,1e-7};
    bipush_rmaxs_dict["orkut"] = { {1e-3,10},{1e-4,20},{1e-4,50},{1e-5,100},{1e-6,200} };
    vl_bipush_rmaxs_dict["orkut"] = { {1e-3,10},{1e-4,20},{1e-4,50},{1e-5,100},{1e-6,200} };
    p_trun_omegas_dict["orkut"] = { {500,100},{500,200},{500,1000},{500,2000},{500,5000}};

    rw_omegas_dict["road-CA1"] = {10,50,100,150,200};
    vl_rw_omegas_dict["road-CA1"] = {50,200,1000,2000,4000};
    push_rmaxs_dict["road-CA1"] = {1e-2,1e-3,3e-4,1e-4,5e-5,1e-5};
    vl_push_rmaxs_dict["road-CA1"] = {1e-2,1e-3,3e-4,1e-4,5e-5,1e-5};
    bipush_rmaxs_dict["road-CA1"] = {{1e-3,10},{1e-4,20},{1e-4,50},{1e-5,100}};
    vl_bipush_rmaxs_dict["road-CA1"] = {{1e-3,50},{1e-4,100},{3e-5,250},{1e-5,500}};
    p_trun_omegas_dict["road-CA1"] = { 
        {5000,100},{5000,200},{5000,1000},{5000,2000},{5000,5000}
         };

    rw_omegas_dict["road-PA1"] = {10,50,100,150,200};
    vl_rw_omegas_dict["road-PA1"] = {50,200,1000,2000,4000};
    push_rmaxs_dict["road-PA1"] = {1e-2,1e-3,3e-4,1e-4,5e-5,1e-5};
    vl_push_rmaxs_dict["road-PA1"] = {1e-2,1e-3,3e-4,1e-4,5e-5,1e-5};
    bipush_rmaxs_dict["road-PA1"] = {{1e-3,10},{1e-4,20},{1e-4,50},{1e-5,100}};
    vl_bipush_rmaxs_dict["road-PA1"] = {{1e-3,10},{1e-4,20},{1e-4,50},{1e-5,100}};
    p_trun_omegas_dict["road-PA1"] = { 
        {5000,100},{5000,200},{5000,1000},{5000,2000},{5000,5000}
        };
    
    exp_singlepair_algorithms(G,dataset,selectNum,vl_strategy, params[0],params[1],params[2],params[3],params[4],params[5],params[6]);

    return 0;
}


