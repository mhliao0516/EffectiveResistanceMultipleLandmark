#pragma once

#include "Eigen/Dense"
#include "EdgeGraph.h"

std::vector<double> er_LEwalk_singlesource(EdgeGraph &G, int s, int T);
vector<double> er_ST_singlesource(EdgeGraph &G, int s, int N);
std::vector<double> er_AbWalkstar_singlesource(EdgeGraph &G, int s, int v, int T, const std::vector<double> &RV);
std::vector<double> er_Pushstar_singlesource(EdgeGraph &G, int s, int v, double rmax, const std::vector<double> &RV);
std::vector<double> precompute_Luuinv(EdgeGraph &G, const std::vector<int>& vl,const std::vector<int> &index_vl, int omega);
vector<double> precompute_Luuinv_ST(EdgeGraph &G, vector<int> vl,vector<int> index_vl, int N);
std::vector<double> er_vl_rw_singlesource(EdgeGraph &G, int s,
                                            const std::vector<int> &vl,const std::vector<int> &index_vl,
                                            const vector<double> &Luuinv, const vector<vector<double>> &P, const Eigen::MatrixXd &SCInverse,const vector<double> &Pu_SCI_Pu,
                                            int omega);
std::vector<double> er_vl_push_singlesource(EdgeGraph &G, int s,
                                            const std::vector<int> &vl,const std::vector<int> &index_vl,
                                            const vector<double> &Luuinv, const vector<vector<double>> &P, const Eigen::MatrixXd &SCInverse,const vector<double> &Pu_SCI_Pu,
                                            double pushrmax);

