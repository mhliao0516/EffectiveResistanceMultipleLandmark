
#include <iostream>
#include <vector>
#include <tuple>
#include <algorithm>
#include "Eigen/Dense"

#include "EdgeGraph.h"
#include "tools-matrix.h"

using namespace std;

double er_AbWalk(EdgeGraph &G, int s, int t, int v, int T)
{
    if (s == t)
    {
        return 0.0;
    }
    double rst = 0.0;
    if (t == v)
    {
        for (int i = 0; i < T; ++i)
        {
            double tao_s = 0.0;
            int current = s;
            while (current != v)
            {
                if (current == s)
                {
                    tao_s += 1.0;
                }
                current = G.choose_neighbor(current);
            }
            rst += tao_s / (G.deg[s] * T);
        }
        return rst;
    }
    else if (s == v)
    {
        for (int i = 0; i < T; ++i)
        {
            double tao_t = 0.0;
            int current = t;
            while (current != v)
            {
                if (current == t)
                {
                    tao_t += 1.0;
                }
                current = G.choose_neighbor(current);
            }
            rst += tao_t / (G.deg[t] * T);
        }
        return rst;
    }
    else
    {
        for (int i = 0; i < T; ++i)
        {
            double tao_ss = 0.0;
            double tao_st = 0.0;
            int current = s;
            while (current != v)
            {
                if (current == s)
                {
                    tao_ss += 1.0;
                }
                if (current == t)
                {
                    tao_st += 1.0;
                }
                current = G.choose_neighbor(current);
            }
            double tao_ts = 0.0;
            double tao_tt = 0.0;
            current = t;
            while (current != v)
            {
                if (current == s)
                {
                    tao_ts += 1.0;
                }
                if (current == t)
                {
                    tao_tt += 1.0;
                }
                current = G.choose_neighbor(current);
            }
            rst += (tao_ss / (G.deg[s] * T)) + (tao_tt / (G.deg[t] * T)) - (tao_st / (G.deg[t] * T)) - (tao_ts / (G.deg[s] * T));
        }
        return rst;
    }
}

double er_Push(EdgeGraph &G, int s, int t, int v, double rmax)
{
    if (s == t)
    {
        return 0.0;
    }
    else if (t == v)
    {
        std::vector<double> q, r;
        std::tie(q, r) = G.v_absorbed_push(s, v, rmax);
        return q[s] / G.deg[s];
    }
    else if (s == v)
    {
        std::vector<double> q, r;
        std::tie(q, r) = G.v_absorbed_push(t, v, rmax);
        return q[t] / G.deg[t];
    }
    else
    {
        std::vector<double> q1, r1, q2, r2;
        std::tie(q1, r1) = G.v_absorbed_push(s, v, rmax);
        std::tie(q2, r2) = G.v_absorbed_push(t, v, rmax);
        return (q1[s] / G.deg[s]) + (q2[t] / G.deg[t]) - (q1[t] / G.deg[t]) - (q2[s] / G.deg[s]);
    }
}

double er_Bipush(EdgeGraph &G, int s, int t, int v, double rmax, int T)
{
    if (s == t)
    {
        return 0.0;
    }
    else if (t == v)
    {
        std::vector<double> q, r;
        std::tie(q, r) = G.v_absorbed_push(s, v, rmax);
        double rst = q[s] / G.deg[s];
        for (int i = 0; i < T; ++i)
        {
            int current = s;
            while (current != v)
            {
                rst += r[current] / (G.deg[current] * T);
                current = G.choose_neighbor(current);
            }
        }
        return rst;
    }
    else if (s == v)
    {
        std::vector<double> q, r;
        std::tie(q, r) = G.v_absorbed_push(t, v, rmax);
        double rst = q[t] / G.deg[t];
        for (int i = 0; i < T; ++i)
        {
            int current = t;
            while (current != v)
            {
                rst += r[current] / (G.deg[current] * T);
                current = G.choose_neighbor(current);
            }
        }
        return rst;
    }
    else
    {
        std::vector<double> q1, r1, q2, r2;
        std::tie(q1, r1) = G.v_absorbed_push(s, v, rmax);
        std::tie(q2, r2) = G.v_absorbed_push(t, v, rmax);
        double rst = (q1[s] / G.deg[s]) + (q2[t] / G.deg[t]) - (q1[t] / G.deg[t]) - (q2[s] / G.deg[s]);
        for (int i = 0; i < T; ++i)
        {
            int current = s;
            while (current != v)
            {
                rst += (r1[current] - r2[current]) / (G.deg[current] * T);
                current = G.choose_neighbor(current);
            }
            current = t;
            while (current != v)
            {
                rst += (r2[current] - r1[current]) / (G.deg[current] * T);
                current = G.choose_neighbor(current);
            }
        }
        return rst;
    }
}

double er_LocalTree(EdgeGraph &G, int s, int t, int v, std::vector<int> &bfs_v, int T)
{
    std::vector<bool> inTree(G.n, false);
    std::vector<int> next(G.n, -2);
    std::vector<int> reverse(G.n, 1);
    double rst = 0.0;

    for (int i = 0; i < T; ++i)
    {
        fill(inTree.begin(),inTree.end(),false);
        fill(next.begin(),next.end(),-2);
        fill(reverse.begin(),reverse.end(),1);

        inTree[v] = true;
        next[v] = -1;
        if (!inTree[s])
        {
            int u = s;
            while (!inTree[u])
            {
                next[u] = G.choose_neighbor(u);
                u = next[u];
            }
            u = s;
            while (!inTree[u])
            {
                inTree[u] = true;
                u = next[u];
            }
        }
        if (!inTree[t])
        {
            int u = t;
            while (!inTree[u])
            {
                next[u] = G.choose_neighbor(u);
                u = next[u];
            }
            u = t;
            while (!inTree[u])
            {
                inTree[u] = true;
                // reverse[u] = -1;
                u = next[u];
            }
        }

        int u = s;
        while (u != v)
        {
            if (next[u] == bfs_v[u] && inTree[u] && inTree[next[u]])
            {
                rst += static_cast<double>(reverse[u]) / T;
            }
            else if (u == next[bfs_v[u]] && inTree[u] && inTree[bfs_v[u]])
            {
                rst -= static_cast<double>(reverse[u]) / T;
            }
            u = bfs_v[u];
        }

        u = t;
        while (u != v)
        {
            if (next[u] == bfs_v[u] && inTree[u] && inTree[next[u]])
            {
                rst += static_cast<double>(reverse[u]) / T;
            }
            else if (u == next[bfs_v[u]] && inTree[u] && inTree[bfs_v[u]])
            {
                rst -= static_cast<double>(reverse[u]) / T;
            }
            u = bfs_v[u];
        }
    }
    return rst;
}

double er_p_trun(EdgeGraph &G, int s, int t, int p, int omega) {
    if(s==t){
        return 0.0;
    }
    double rst = 1.0 / G.deg[s] + 1.0 / G.deg[t];
    for (int i = 1; i <= p; i++) {
        double piss = 0.0;
        double pist = 0.0;
        double pits = 0.0;
        double pitt = 0.0;
        for (int k = 1; k <= omega; k++) {
            int current_s = s;
            int current_t = t;
            int current_step = 0;
            while (current_step < i) {
                current_s = G.choose_neighbor(current_s);
                current_t = G.choose_neighbor(current_t);
                current_step++;
            }
            if (current_s == s) {
                piss += 1.0 / omega;
            }
            if (current_s == t) {
                pist += 1.0 / omega;
            }
            if (current_t == s) {
                pits += 1.0 / omega;
            }
            if (current_t == t) {
                pitt += 1.0 / omega;
            }
        }
        rst += piss / G.deg[s] + pitt / G.deg[t] - pist / G.deg[t] - pits / G.deg[s];
    }
    return rst;
}

std::vector<std::vector<double>> precompute_Pr(EdgeGraph &G, std::vector<int> &vl,std::vector<int> &index_vl, int omega)
{
    std::vector<std::vector<double>> Pr(G.n-vl.size(), std::vector<double>(vl.size(), 0.0));

    for (int times = 1; times <= omega; ++times)
    {
        for (int i = 0; i < G.n; ++i)
        {
            if(!(index_vl[i]>0)){
                int current = i;
                while (!(index_vl[current]>0))
                {
                    current = G.choose_neighbor(current);
                }
                int ij = index_vl[current]-1;
                int ii = -index_vl[i];
                Pr[ii][ij] += 1.0 / omega;
            }            
        }
    }

    return Pr;
}

std::vector<std::vector<double>> precompute_Pf(EdgeGraph &G, std::vector<int> &vl,std::vector<int> &index_vl, int omega)
{
    std::vector<std::vector<double>> Pf(G.n-vl.size(), std::vector<double>(vl.size(), 0.0));

    for (int times = 1; times <= omega; ++times)
    {
        std::vector<int> next = G.wilson(vl);
        for (int i = 0; i < G.n; ++i)
        {
            if(!(index_vl[i]>0)){
                int current = i;
                while (next[current] != -1)
                {
                    current = next[current];
                }
                int ij = index_vl[current]-1;
                int ii = -index_vl[i];
                Pf[ii][ij] += 1.0 / omega;
            }            
        }
    }

    return Pf;
}

Eigen::MatrixXd precompute_SchurComplementInverse(EdgeGraph &G, std::vector<int> &vl,std::vector<int> &index_vl, std::vector<std::vector<double>> &P)
{

    std::vector<std::vector<double>> SC(vl.size(), std::vector<double>(vl.size(), 0.0));

    for (size_t i = 0; i < vl.size(); ++i)
    {
        int v = vl[i];
        for (int neighbor : G.g[v])
        {
            if (!(index_vl[neighbor]>0))
            {
                int iu = -index_vl[neighbor];
                for (size_t j = 0; j < vl.size(); ++j)
                {
                    SC[i][j] -= P[iu][j];
                }
            }
            else
            {
                int iv = index_vl[neighbor]-1;
                SC[i][iv] += -1.0;
            }
        }
        SC[i][i] += G.deg[v];
    }

    return pseudo_inverse(SC);
}

std::vector<std::vector<double>> combine_P_SCInverse(std::vector<std::vector<double>> &P,Eigen::MatrixXd SCInverse,vector<int> index_vl){
    if(!SCInverse.rows()==P[0].size()){
        throw runtime_error("combining error!!");
    }
    int selectNum = SCInverse.rows();
    int n = P.size() + selectNum;
    vector<vector<double>> Index(n,vector<double>(selectNum,0.0));
    int v_offset = 0;
    for(int i=0;i<n;i++){
        if(index_vl[i]>0){
            for(int j=0;j<selectNum;j++){
                Index[i][j] = SCInverse(index_vl[i]-1,j);
            }
            v_offset += 1;
        } else{
            Index[i] = P[i-v_offset];
        }
    }
    return Index;
}

double er_vl_rw(EdgeGraph &G, int s, int t, int selectNum, vector<int> &index_vl,vector<std::vector<double>> &Index, Eigen::MatrixXd &SCInverse, int omega)
{
    if (index_vl[s]>0 && index_vl[t]>0)
    {
        int is = index_vl[s]-1;
        int it = index_vl[t]-1;
        return SCInverse(is, is) + SCInverse(it, it) - 2 * SCInverse(is, it);
    }
    else if (!(index_vl[s]>0) && index_vl[t]>0)
    {
        int it = index_vl[t]-1;

        double qs_s = 0;
        for(int i=0;i<omega;i++){
            int current = s;
            while(!(index_vl[current]>0)){
                if(current == s){
                    qs_s += 1.0/omega;
                }
                current = G.choose_neighbor(current);
            }
        }

        vector<double> ps_sci(selectNum,0.0);
        for (int i=0;i<selectNum;++i){
            for(int j=0;j<selectNum;j++){
                ps_sci[i] += Index[s][j]*SCInverse(j,i);
            }
        }
        double ps_sci_ps = 0.0, ps_scit = 0.0;
        for (int j = 0; j < selectNum; ++j){
            ps_sci_ps += ps_sci[j]*Index[s][j];
            ps_scit += Index[s][j]*SCInverse(j,it);
        }
        return qs_s / G.deg[s] + ps_sci_ps + SCInverse(it, it) - 2 * ps_scit;
    }
    else if (index_vl[s]>0 && !(index_vl[t]>0))
    {
        int is = index_vl[s]-1;
        
        double qt_t = 0;
        for(int i=0;i<omega;i++){
            int current = t;
            while(!(index_vl[current]>0)){
                if(current == t){
                    qt_t += 1.0/omega;
                }
                current = G.choose_neighbor(current);
            }
        }

        vector<double> pt_sci(selectNum,0.0);
        for (int i=0;i<selectNum;++i){
            for(int j=0;j<selectNum;j++){
                pt_sci[i] += Index[t][j]*SCInverse(j,i);
            }
        }
        double pt_sci_pt = 0.0, pt_scis = 0.0;
        for (int j = 0; j < selectNum; ++j){
            pt_sci_pt += pt_sci[j]*Index[t][j];
            pt_scis += Index[t][j]*SCInverse(j,is);
        }
        return qt_t / G.deg[t] + pt_sci_pt + SCInverse(is, is) - 2 * pt_scis;
    }
    else if (!(index_vl[s]>0) && !(index_vl[t]>0))
    {
        double qs_s = 0;
        double qs_t = 0;
        for(int i=0;i<omega;i++){
            int current = s;
            while(!(index_vl[current]>0)){
                if(current == s){
                    qs_s += 1.0/omega;
                }
                if(current == t){
                    qs_t += 1.0/omega;
                }
                current = G.choose_neighbor(current);
            }
        }

        double qt_t = 0;
        double qt_s = 0;
        for(int i=0;i<omega;i++){
            int current = t;
            while(!(index_vl[current]>0)){
                if(current == t){
                    qt_t += 1.0/omega;
                }
                if(current == s){
                    qt_s += 1.0/omega;
                }
                current = G.choose_neighbor(current);
            }
        }

        vector<double> ps_sci(selectNum,0.0);
        vector<double> pt_sci(selectNum,0.0);
        for (int i=0;i<selectNum;++i){
            for(int j=0;j<selectNum;j++){
                ps_sci[i] += Index[s][j]*SCInverse(j,i);
                pt_sci[i] += Index[t][j]*SCInverse(j,i);
            }
        }
        double ps_sci_ps = 0.0,pt_sci_pt = 0.0,ps_sci_pt = 0.0;
        for (int j = 0; j < selectNum; ++j){
            ps_sci_ps += ps_sci[j]*Index[s][j];
            pt_sci_pt += pt_sci[j]*Index[t][j];
            ps_sci_pt += ps_sci[j]*Index[t][j];
        }
        return qs_s / G.deg[s] + qt_t / G.deg[t] -  qs_t / G.deg[t] - qt_s / G.deg[s] + ps_sci_ps + pt_sci_pt - 2 * ps_sci_pt;
    }
    cout << "unexpected return!!" << endl;
    return 0.0;
}

double er_vl_push(EdgeGraph &G, int s, int t, int selectNum, vector<int> &index_vl,vector<std::vector<double>> &Index, Eigen::MatrixXd &SCInverse, double rmax)
{
    if (index_vl[s]>0 && index_vl[t]>0)
    {
        int is = index_vl[s]-1;
        int it = index_vl[t]-1;
        return SCInverse(is, is) + SCInverse(it, it) - 2 * SCInverse(is, it);
    }
    else if (!(index_vl[s]>0) && index_vl[t]>0)
    {
        int it = index_vl[t]-1;
        std::vector<double> qs, rs;
        tie(qs, rs) = G.vl_absorbed_push(s, index_vl, rmax);
        vector<double> ps_sci(selectNum,0.0);
        for (int i=0;i<selectNum;++i){
            for(int j=0;j<selectNum;j++){
                ps_sci[i] += Index[s][j]*SCInverse(j,i);
            }
        }
        double ps_sci_ps = 0.0, ps_scit = 0.0;
        for (int j = 0; j < selectNum; ++j){
            ps_sci_ps += ps_sci[j]*Index[s][j];
            ps_scit += Index[s][j]*SCInverse(j,it);
        }
        return qs[s] / G.deg[s] + ps_sci_ps + SCInverse(it, it) - 2 * ps_scit;
    }
    else if (index_vl[s]>0 && !(index_vl[t]>0))
    {
        int is = index_vl[s]-1;
        std::vector<double> qt, rt;
        tie(qt, rt) = G.vl_absorbed_push(t, index_vl, rmax);
        vector<double> pt_sci(selectNum,0.0);
        for (int i=0;i<selectNum;++i){
            for(int j=0;j<selectNum;j++){
                pt_sci[i] += Index[t][j]*SCInverse(j,i);
            }
        }
        double pt_sci_pt = 0.0, pt_scis = 0.0;
        for (int j = 0; j < selectNum; ++j){
            pt_sci_pt += pt_sci[j]*Index[t][j];
            pt_scis += Index[t][j]*SCInverse(j,is);
        }
        return qt[t] / G.deg[t] + pt_sci_pt + SCInverse(is, is) - 2 * pt_scis;
    }
    else if (!(index_vl[s]>0) && !(index_vl[t]>0))
    {
        std::vector<double> qs, rs;
        tie(qs, rs) = G.vl_absorbed_push(s, index_vl, rmax);
        std::vector<double> qt, rt;
        tie(qt, rt) = G.vl_absorbed_push(t, index_vl, rmax);
        vector<double> ps_sci(selectNum,0.0);
        vector<double> pt_sci(selectNum,0.0);
        for (int i=0;i<selectNum;++i){
            for(int j=0;j<selectNum;j++){
                ps_sci[i] += Index[s][j]*SCInverse(j,i);
                pt_sci[i] += Index[t][j]*SCInverse(j,i);
            }
        }
        double ps_sci_ps = 0.0,pt_sci_pt = 0.0,ps_sci_pt = 0.0;
        for (int j = 0; j < selectNum; ++j){
            ps_sci_ps += ps_sci[j]*Index[s][j];
            pt_sci_pt += pt_sci[j]*Index[t][j];
            ps_sci_pt += ps_sci[j]*Index[t][j];
        }
        return qs[s] / G.deg[s] + qt[t] / G.deg[t] - qs[t] / G.deg[t] - qt[s] / G.deg[s] + ps_sci_ps + pt_sci_pt - 2 * ps_sci_pt;
    }
    cout << "unexpected return!!" << endl;
    return 0.0;
}

double er_vl_bipush(EdgeGraph &G, int s, int t, int selectNum, vector<int> &index_vl,vector<std::vector<double>> &Index, Eigen::MatrixXd &SCInverse, double rmax, int omega)
{
    if (index_vl[s]>0 && index_vl[t]>0)
    {
        int is = index_vl[s]-1;
        int it = index_vl[t]-1;
        return SCInverse(is, is) + SCInverse(it, it) - 2 * SCInverse(is, it);
    }
    else if (!(index_vl[s]) && index_vl[t])
    {
        int it = index_vl[t]-1;
        std::vector<double> qs, rs;
        tie(qs, rs) = G.vl_absorbed_push(s, index_vl, rmax);
        vector<double> ps_sci(selectNum,0.0);
        for (int i=0;i<selectNum;++i){
            for(int j=0;j<selectNum;j++){
                ps_sci[i] += Index[s][j]*SCInverse(j,i);
            }
        }
        double ps_sci_ps = 0.0, ps_scit = 0.0;
        for (int j = 0; j < selectNum; ++j){
            ps_sci_ps += ps_sci[j]*Index[s][j];
            ps_scit += Index[s][j]*SCInverse(j,it);
        }
        double rst =  qs[s] / G.deg[s] + ps_sci_ps + SCInverse(it, it) - 2 * ps_scit;

        for (int i = 0; i < omega; ++i)
        {
            int current = s;
            while (!(index_vl[current]>0))
            {
                rst += rs[current] / (G.deg[current] * omega);
                current = G.choose_neighbor(current);
            }
        }
        return rst;
    }
    else if (index_vl[s]>0 && !(index_vl[t]>0))
    {
        int is = index_vl[s]-1;
        std::vector<double> qt, rt;
        tie(qt, rt) = G.vl_absorbed_push(t, index_vl, rmax);
        vector<double> pt_sci(selectNum,0.0);
        for (int i=0;i<selectNum;++i){
            for(int j=0;j<selectNum;j++){
                pt_sci[i] += Index[t][j]*SCInverse(j,i);
            }
        }
        double pt_sci_pt = 0.0, pt_scis = 0.0;
        for (int j = 0; j < selectNum; ++j){
            pt_sci_pt += pt_sci[j]*Index[t][j];
            pt_scis += Index[t][j]*SCInverse(j,is);
        }
        double rst = qt[t] / G.deg[t] + pt_sci_pt + SCInverse(is, is) - 2 * pt_scis;

        for (int i = 0; i < omega; ++i)
        {
            int current = t;
            while (!(index_vl[current]>0))
            {
                rst += rt[current] / (G.deg[current] * omega);
                current = G.choose_neighbor(current);
            }
        }
        return rst;
    }
    else if (!(index_vl[s]>0) && !(index_vl[t]>0))
    {
        std::vector<double> qs, rs;
        tie(qs, rs) = G.vl_absorbed_push(s, index_vl, rmax);
        std::vector<double> qt, rt;
        tie(qt, rt) = G.vl_absorbed_push(t, index_vl, rmax);
        vector<double> ps_sci(selectNum,0.0);
        vector<double> pt_sci(selectNum,0.0);
        for (int i=0;i<selectNum;++i){
            for(int j=0;j<selectNum;j++){
                ps_sci[i] += Index[s][j]*SCInverse(j,i);
                pt_sci[i] += Index[t][j]*SCInverse(j,i);
            }
        }
        double ps_sci_ps = 0.0,pt_sci_pt = 0.0,ps_sci_pt = 0.0;
        for (int j = 0; j < selectNum; ++j){
            ps_sci_ps += ps_sci[j]*Index[s][j];
            pt_sci_pt += pt_sci[j]*Index[t][j];
            ps_sci_pt += ps_sci[j]*Index[t][j];
        }
        double rst = qs[s] / G.deg[s] + qt[t] / G.deg[t] - qs[t] / G.deg[t] - qt[s] / G.deg[s] + ps_sci_ps + pt_sci_pt - 2 * ps_sci_pt;

        double current_time = get_current_time_sec_method();
        for (int i = 0; i < omega; ++i)
        {
            int current = s;
            while (!(index_vl[current]>0))
            {
                rst += (rs[current]-rt[current]) / (G.deg[current] * omega);
                current = G.choose_neighbor(current);
            }
        }
        for (int i = 0; i < omega; ++i)
        {
            int current = t;
            while (!(index_vl[current]>0))
            {
                rst += (rt[current]-rs[current]) / (G.deg[current] * omega);
                current = G.choose_neighbor(current);
            }
        }
        cout << "rw elapsed time: " << get_current_time_sec_method() - current_time << endl;
        return rst;
    }
    cout << "unexpected return!!" << endl;
    return 0.0;
}




// int main(int argc, char **argv)
// {
//     srand(1);
//     EdgeGraph G = read_edgegraph("demo.txt");
//     cout << "EdgeGraph inited" << endl;
//     double rst;
//     rst = er_AbWalk(G, 1, 2, 1, 1000000);
//     cout << "er_Abwalk" << endl;
//     cout << rst << endl;
//     rst = er_Push(G, 1, 2, 1, 1e-4);
//     cout << "er_Push" << endl;
//     cout << rst << endl;
//     rst = er_Bipush(G, 1, 2, 1, 1e-4, 10000);
//     cout << "er_Bipush" << endl;
//     cout << rst << endl;
//     vector<int> bfs_v = G.BFS(1);
//     rst = er_LocalTree(G, 3, 2, 1, bfs_v, 1000000);
//     cout << "er_LocalTree" << endl;
//     cout << rst << endl;
//     vector<int> vl = {1, 2};
//     vector<std::vector<double>> Pr = prepcompute_Pr(G, vl, 10000);
//     cout << "precompute_Pr" << endl;
//     cout << Pr << endl;
//     vector<int> wilsonnext = G.wilson(vl);
//     cout << "wilson" << endl;
//     cout << wilsonnext << endl;
//     vector<std::vector<double>> Pf = prepcompute_Pf(G, vl, 10000);
//     cout << "precompute_Pf" << endl;
//     cout << Pf << endl;
//     Eigen::MatrixXd SCInverse = precompute_SchurComplementInverse(G, vl, Pr);
//     cout << "precompute_SchurComplementInverse" << endl;
//     cout << SCInverse << endl;
//     rst = er_SCbased(G, 3, 2, vl, Pr, SCInverse, 1e-4);
//     cout << "er_SCbase" << endl;
//     cout << rst << endl;

//     return 0;
// }